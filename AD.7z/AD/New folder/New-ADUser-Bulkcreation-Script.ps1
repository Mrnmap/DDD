﻿# Import Active Directory module for running AD cmdlets
Import-Module ActiveDirectory

# Store the data from ADUsers.csv in the $ADUsers variable
$ADUsers = Import-Csv C:\SW\AD\AD-Template.csv

# Loop through each row containing user details in the CSV file 
foreach ($user in $ADUsers) {
    
    # Extract user details from CSV
    $Username     = $user.UserName
    $Password     = $user.Password
    $FirstName    = $user.FirstName
    $LastName     = $user.LastName
    $OU           = $user.OU
    $Address      = $user.Address
    $JobTitle     = $user.JobTitle
    $Department   = $user.Department
    $ManagerName  = $user.ManagerName
    $UPN          = "$Username@matrix.com"
    $DisplayName  = "$LastName, $FirstName"

    # Check if the user already exists in AD
    if (Get-ADUser -Filter {SamAccountName -eq $Username}) {
        Write-Warning "A user account with username $Username already exists in Active Directory."
    }
    else {
        # Create a new user account
        New-ADUser `
            -SamAccountName $Username `
            -UserPrincipalName $UPN `
            -Name "$FirstName $LastName" `
            -GivenName $FirstName `
            -Surname $LastName `
            -DisplayName $DisplayName `
            -Path $OU `
            -Enabled $true `
            -AccountPassword (ConvertTo-SecureString $Password -AsPlainText -Force) `
            -ChangePasswordAtLogon $true

        # Optional: Set additional attributes (e.g., Title, Department, Address)
        Set-ADUser -Identity $Username `
            -Title $JobTitle `
            -Department $Department `
            -StreetAddress $Address

        # If manager is provided, set it (must be DN or retrieved)
        if ($ManagerName) {
            $Manager = Get-ADUser -Filter {Name -eq $ManagerName}
            if ($Manager) {
                Set-ADUser -Identity $Username -Manager $Manager.DistinguishedName
            } else {
                Write-Warning "Manager '$ManagerName' not found for user $Username."
            }
        }
    }
}
