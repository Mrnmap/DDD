﻿#Import active directory module for running AD cmdlets

Import-Module ActiveDirectory

#Store the data from ADUsers.csv in the $ADUsers variable

$ADUsers = Import-csv C:\SW\AD\usersAD.csv

#Loop through each rom containing user details in the CSV file 
foreach ($user in $ADUsers)
{

Write-Host $user

$username  = $user.UserName
$Password  = $user.Password
$Firstname = $user.FirstName
$Lastname  = $User.LastName
$OU	   = $user.OU
$upn = $username + "@matrix.com"

#Check to see if the user already exists in AD

if (Get-ADUser -F {SamAccountName -eq $Username})
{
	#If user does exist, give a warning

	Write-Warning "A user account with username $Username already exist in Active Directory."
}
else
{
#User does not exist then proceed to create the new user account

#Account will be created in the OU provided by the $OU variable read from the CSV file

New-ADuser -SamAccountName $Username -UserPrincipalName $upn -Name ($Firstname + " " + $lastname) -GivenName $FirstName -Surname $Lastname -Enabled $True -DisplayName "$Firstname $Lastname " -Path $OU  -AccountPassword (convertto-securestring $Password -AsPlainText -Force) -ChangePasswordAtLogon $True

}
}
