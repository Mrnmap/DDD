<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Countries".
 *
 * @property int $CountryID
 * @property string $CountryCode
 * @property string $CountryName
 * @property int $PhoneCode
 * @property string $Nationality
 * @property int|null $PaymentProviderID
 * @property int $DeliveryPartnerID
 * @property int $IsIDMandatory 0=No, 1=Beneficiary, 2=Customer, 3=Both 
 * @property int $IsSpecificPayer 0=No, 1=Yes
 * @property int $Enable 0=>Disable, 1=>enable
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string|null $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 *
 * @property Cities[] $cities
 */
class Countries extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Countries';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['PaymentProviderID', 'OnDate'], 'default', 'value' => null],
            [['Enable'], 'default', 'value' => 0],
            [['CountryID', 'CountryCode', 'CountryName', 'PhoneCode', 'Nationality', 'DeliveryPartnerID', 'IsIDMandatory', 'IsSpecificPayer', 'IsDelete', 'CreateUID', 'UpdateUID'], 'required'],
            [['CountryID', 'PhoneCode', 'PaymentProviderID', 'DeliveryPartnerID', 'IsIDMandatory', 'IsSpecificPayer', 'Enable', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['CountryCode'], 'string', 'max' => 2],
            [['CountryName', 'Nationality'], 'string', 'max' => 100],
            [['CountryCode'], 'unique'],
            [['CountryName'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'CountryID' => 'Country ID',
            'CountryCode' => 'Country Code',
            'CountryName' => 'Country Name',
            'PhoneCode' => 'Phone Code',
            'Nationality' => 'Nationality',
            'PaymentProviderID' => 'Payment Provider ID',
            'DeliveryPartnerID' => 'Delivery Partner ID',
            'IsIDMandatory' => 'Is Id Mandatory',
            'IsSpecificPayer' => 'Is Specific Payer',
            'Enable' => 'Enable',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }
    /**
     * Gets query for [[Cities]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNationality()
    {
        return $this->hasOne(Countries::class, ['CountryCode' => 'CountryCode']);
    }
    /**
     * Gets query for [[Cities]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCities()
    {
        return $this->hasMany(Cities::class, ['CountryCode' => 'CountryCode']);
    }

    /**
     * Gets query for [[Cities]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCountryCurrencies()
    {
        return $this->hasMany(CountryCurrencies::class, ['CountryID' => 'CountryID']);
    }
}
