<?php

namespace common\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;

/**
 * ComplianceScreeningSearch represents the model behind the search form of `common\models\ComplianceScreening`.
 */
class ComplianceScreeningSearch extends ComplianceScreening
{
    // Additional attributes for date range filtering
    public $screening_date_from;
    public $screening_date_to;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'entity_score'], 'integer'],
            [['internal_reference', 'screened_by', 'screening_result', 'entity_type', 'watchlist_source'], 'safe'],
            [['screening_timestamp', 'screening_date_from', 'screening_date_to'], 'safe'],
            [['response_summary', 'raw_response'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = ComplianceScreening::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'screening_timestamp' => SORT_DESC
                ]
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'screening_result' => $this->screening_result,
            'entity_type' => $this->entity_type,
            'entity_score' => $this->entity_score,
        ]);

        $query->andFilterWhere(['like', 'internal_reference', $this->internal_reference])
            ->andFilterWhere(['like', 'screened_by', $this->screened_by])
            ->andFilterWhere(['like', 'watchlist_source', $this->watchlist_source])
            ->andFilterWhere(['like', 'response_summary', $this->response_summary]);

        // Date range filtering
        if (!empty($this->screening_date_from)) {
            $query->andFilterWhere(['>=', 'screening_timestamp', $this->screening_date_from . ' 00:00:00']);
        }
        
        if (!empty($this->screening_date_to)) {
            $query->andFilterWhere(['<=', 'screening_timestamp', $this->screening_date_to . ' 23:59:59']);
        }

        // Single date filtering (if no range is specified)
        if (empty($this->screening_date_from) && empty($this->screening_date_to) && !empty($this->screening_timestamp)) {
            $query->andFilterWhere(['like', 'screening_timestamp', $this->screening_timestamp]);
        }

        return $dataProvider;
    }

    /**
     * Search for high-risk screening results
     */
    public function searchHighRisk($params)
    {
        $query = ComplianceScreening::find()->where([
            'screening_result' => [
                ComplianceScreening::RESULT_MATCH,
                ComplianceScreening::RESULT_CONFIRMED_MATCH,
                ComplianceScreening::RESULT_PENDING_REVIEW
            ]
        ]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'screening_timestamp' => SORT_DESC
                ]
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }

        // Apply additional filters for high-risk search
        $query->andFilterWhere(['like', 'internal_reference', $this->internal_reference])
            ->andFilterWhere(['like', 'screened_by', $this->screened_by])
            ->andFilterWhere(['like', 'watchlist_source', $this->watchlist_source]);

        // Date range filtering for high-risk
        if (!empty($this->screening_date_from)) {
            $query->andFilterWhere(['>=', 'screening_timestamp', $this->screening_date_from . ' 00:00:00']);
        }
        
        if (!empty($this->screening_date_to)) {
            $query->andFilterWhere(['<=', 'screening_timestamp', $this->screening_date_to . ' 23:59:59']);
        }

        return $dataProvider;
    }

    /**
     * Get screening statistics
     */
    public function getStatistics()
    {
        $total = ComplianceScreening::find()->count();
        
        $results = [
            'total' => $total,
            'no_match' => ComplianceScreening::find()->where(['screening_result' => ComplianceScreening::RESULT_NO_MATCH])->count(),
            'match' => ComplianceScreening::find()->where(['screening_result' => ComplianceScreening::RESULT_MATCH])->count(),
            'false_positive' => ComplianceScreening::find()->where(['screening_result' => ComplianceScreening::RESULT_FALSE_POSITIVE])->count(),
            'confirmed_match' => ComplianceScreening::find()->where(['screening_result' => ComplianceScreening::RESULT_CONFIRMED_MATCH])->count(),
            'pending_review' => ComplianceScreening::find()->where(['screening_result' => ComplianceScreening::RESULT_PENDING_REVIEW])->count(),
            'error' => ComplianceScreening::find()->where(['screening_result' => ComplianceScreening::RESULT_ERROR])->count(),
        ];

        // Calculate percentages
        if ($total > 0) {
            foreach ($results as $key => $value) {
                if ($key !== 'total') {
                    $results[$key . '_percentage'] = round(($value / $total) * 100, 2);
                }
            }
        }

        return $results;
    }
} 