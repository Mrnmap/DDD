<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "PaymentGatewayTransaction".
 *
 * @property int $Id
 * @property int $TransactionId
 * @property string $GatewayReference
 * @property string $GatewayStatus
 * @property float $Amount
 * @property string $GatewayMessage
 * @property string $RawResponseJson
 * @property string $PayloadChecksum (SHA256)
 * @property string|null $CreatedAt
 * @property string $UpdatedAt
 */
class PaymentGatewayTransaction extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'PaymentGatewayTransaction';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CreatedAt'], 'default', 'value' => null],
            [['TransactionId',  'GatewayStatus', 'Amount'], 'required'],
            [['TransactionId'], 'integer'],
            [['Amount'], 'number'],
            [['RawResponseJson', 'CreatedAt', 'UpdatedAt'], 'safe'],
            [['GatewayReference'], 'string', 'max' => 50],
            [['GatewayStatus', 'GatewayMessage'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'TransactionId' => 'Transaction ID',
            'GatewayReference' => 'Gateway Reference',
            'GatewayStatus' => 'Gateway Status',
            'Amount' => 'Amount',
            'GatewayMessage' => 'Gateway Message',
            'RawResponseJson' => 'Raw Response Json',
            'PayloadChecksum' => 'Payload Checksum',
            'CreatedAt' => 'Created At',
            'UpdatedAt' => 'Updated At',
        ];
    }
}
