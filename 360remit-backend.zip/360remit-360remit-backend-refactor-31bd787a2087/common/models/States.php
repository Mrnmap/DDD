<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "States".
 *
 * @property int $StateID
 * @property string $MCStatID
 * @property string $StateName
 * @property int $CountryID
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 */
class States extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'States';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['MCStatID', 'StateName', 'CountryID', 'IsDelete', 'CreateUID', 'OnDate', 'UpdateUID'], 'required'],
            [['CountryID', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['MCStatID'], 'string', 'max' => 50],
            [['StateName'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'StateID' => 'State ID',
            'MCStatID' => 'Mc Stat ID',
            'StateName' => 'State Name',
            'CountryID' => 'Country ID',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }

    /**
     * Gets query for [[Transaction]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCities()
    {
        return $this->hasMany(Cities::class, ['StateID' => 'StateID']);
    }
}
