<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "IDTypes".
 *
 * @property int $IDTypeID
 * @property string $MCIdTypeID
 * @property string $Name
 * @property int $HasExpiryDate
 * @property int $Enable
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 */
class IDTypes extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'IDTypes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['MCIdTypeID', 'Name', 'HasExpiryDate', 'Enable', 'IsDelete', 'CreateUID', 'OnDate', 'UpdateUID'], 'required'],
            [['HasExpiryDate', 'Enable', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['MCIdTypeID'], 'string', 'max' => 10],
            [['Name'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'IDTypeID' => 'Id Type ID',
            'MCIdTypeID' => 'Mc Id Type ID',
            'Name' => 'Name',
            'HasExpiryDate' => 'Has Expiry Date',
            'Enable' => 'Enable',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }

}
