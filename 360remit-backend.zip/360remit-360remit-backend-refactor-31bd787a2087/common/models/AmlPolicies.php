<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "AmlPolicies".
 *
 * @property int $AmlPolicyID
 * @property string $Description
 * @property float $TotalAmountPerDay
 * @property float $TotalAmountPerMonth
 * @property float $AmountPerTransaction
 * @property int $TrnCountPerMonth
 * @property int $TrnCountPerDay
 * @property int $Enable 0=>Disable, 1=>Enable
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 */
class AmlPolicies extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'AmlPolicies';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Enable'], 'default', 'value' => 1],
            [['Description', 'TotalAmountPerDay', 'TotalAmountPerMonth', 'AmountPerTransaction', 'TrnCountPerMonth', 'TrnCountPerDay', 'CreateUID', 'UpdateUID'], 'required'],
            [['TotalAmountPerDay', 'TotalAmountPerMonth', 'AmountPerTransaction'], 'number'],
            [['TrnCountPerMonth', 'TrnCountPerDay', 'Enable', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['Description'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'AmlPolicyID' => 'Aml Policy ID',
            'Description' => 'Description',
            'TotalAmountPerDay' => 'Total Amount Per Day',
            'TotalAmountPerMonth' => 'Total Amount Per Month',
            'AmountPerTransaction' => 'Amount Per Transaction',
            'TrnCountPerMonth' => 'Trn Count Per Month',
            'TrnCountPerDay' => 'Trn Count Per Day',
            'Enable' => 'Enable',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }

}
