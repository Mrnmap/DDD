<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "EkycReportImages".
 *
 * @property int $Id
 * @property int $EkycReportId
 * @property string|null $FrameType
 * @property string|null $ContentType
 * @property string|null $SourceUrl
 * @property string|null $SourcePath
 * @property string|null $CreatedAt
 */
class EkycReportImages extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'EkycReportImages';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['FrameType', 'ContentType', 'SourceUrl', 'SourcePath'], 'default', 'value' => null],
            [['EkycReportId'], 'required'],
            [['EkycReportId'], 'integer'],
            [['CreatedAt'], 'safe'],
            [['FrameType'], 'string', 'max' => 100],
            [['ContentType'], 'string', 'max' => 50],
            [['SourceUrl', 'SourcePath'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'EkycReportId' => 'Ekyc Report ID',
            'FrameType' => 'Frame Type',
            'ContentType' => 'Content Type',
            'SourceUrl' => 'Source Url',
            'SourcePath' => 'Source Path',
            'CreatedAt' => 'Created At',
        ];
    }

}
