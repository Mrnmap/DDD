<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "FeeRules".
 *
 * @property int $Id
 * @property int $CountryCurrencyId
 * @property int $DeliveryMethodId
 * @property float $FixedFee
 * @property float $PercentFee
 * @property string $FeeType
 * @property string $CreatedAt
 */
class FeeRules extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const FEETYPE_FIXED = 'fixed';
    const FEETYPE_PERCENT = 'percent';
    const FEETYPE = '';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'FeeRules';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CountryCurrencyId', 'DeliveryMethodId', 'FixedFee', 'PercentFee', 'FeeType'], 'required'],
            [['CountryCurrencyId', 'DeliveryMethodId'], 'integer'],
            [['FixedFee', 'PercentFee'], 'number'],
            [['FeeType'], 'string'],
            [['CreatedAt'], 'safe'],
            ['FeeType', 'in', 'range' => array_keys(self::optsFeeType())],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'CountryCurrencyId' => 'Country Currency ID',
            'DeliveryMethodId' => 'Delivery Method ID',
            'FixedFee' => 'Fixed Fee',
            'PercentFee' => 'Percent Fee',
            'FeeType' => 'Fee Type',
            'CreatedAt' => 'Created At',
        ];
    }


    /**
     * column FeeType ENUM value labels
     * @return string[]
     */
    public static function optsFeeType()
    {
        return [
            self::FEETYPE_FIXED => 'fixed',
            self::FEETYPE_PERCENT => 'percent',
            self::FEETYPE => '',
            self::FEETYPE => '',
        ];
    }

    /**
     * @return string
     */
    public function displayFeeType()
    {
        return self::optsFeeType()[$this->FeeType];
    }

    /**
     * @return bool
     */
    public function isFeeTypeFixed()
    {
        return $this->FeeType === self::FEETYPE_FIXED;
    }

    public function setFeeTypeToFixed()
    {
        $this->FeeType = self::FEETYPE_FIXED;
    }

    /**
     * @return bool
     */
    public function isFeeTypePercent()
    {
        return $this->FeeType === self::FEETYPE_PERCENT;
    }

    public function setFeeTypeToPercent()
    {
        $this->FeeType = self::FEETYPE_PERCENT;
    }

    /**
     * @return bool
     */
    public function isFeeType()
    {
        return $this->FeeType === self::FEETYPE;
    }

    public function setFeeTypeTo()
    {
        $this->FeeType = self::FEETYPE;
    }

    public function getCountry()
    {
        return $this->hasOne(Countries::class, ['CountryId' => 'CountryID']);
    }
}
