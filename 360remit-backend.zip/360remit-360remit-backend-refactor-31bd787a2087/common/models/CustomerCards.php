<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "CustomerCards".
 *
 * @property int $CardID
 * @property int $UserID
 * @property string $CardName
 * @property string $CardToken
 * @property string $Last4
 * @property string|null $CardType
 * @property int|null $IsDefault
 * @property string $OnDate
 * @property string $UpdatedDate
 */
class CustomerCards extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'CustomerCards';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CardType'], 'default', 'value' => null],
            [['IsDefault'], 'default', 'value' => 0],
            [['UserID', 'CardToken', 'Last4'], 'required'],
            [['UserID', 'IsDefault'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['CardName', 'CardType'], 'string', 'max' => 50],
            [['CardToken'], 'string', 'max' => 255],
            [['Last4'], 'string', 'max' => 4],
            [
                ['CardToken'],
                'unique',
                'targetAttribute' => ['UserID', 'CardToken'],
                'message' => 'This Card already exists for this user.',
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'CardID' => 'Card ID',
            'UserID' => 'User ID',
            'CardName' => 'Card Name',
            'CardToken' => 'Card Token',
            'Last4' => 'Last4',
            'CardType' => 'Card Type',
            'IsDefault' => 'Is Default',
            'OnDate' => 'On Date',
            'UpdatedDate' => 'Updated Date',
        ];
    }
}
