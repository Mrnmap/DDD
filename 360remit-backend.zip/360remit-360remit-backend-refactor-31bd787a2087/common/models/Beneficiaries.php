<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Beneficiaries".
 *
 * @property int $BeneficiaryID
 * @property int $UserID
 * @property string $FirstName
 * @property string|null $MiddleName
 * @property string $LastName
 * @property string|null $Email
 * @property string|null $Phone
 * @property string|null $House
 * @property string|null $Street
 * @property string|null $State
 * @property string|null $City
 * @property int|null $Nationality
 * @property int|null $Relation
 * @property string|null $Gender
 * @property int|null $IDTypeID
 * @property string|null $IDNo
 * @property string|null $DocExpiry
 * @property int $IsDelete
 * @property string|null $Status
 * @property string $OnDate
 * @property string $UpdatedDate
 * @property string|null $ScreeningResult
 * @property string|null $SceeningReference	
 * @property string|null $LastSceeningAt
 */
class Beneficiaries extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const GENDER_MALE = 'Male';
    const GENDER_FEMALE = 'Female';
    const STATUS_ACTIVATED = 'activated';
    const STATUS_BLOCKED = 'blocked';
    const STATUS_UNDER_REVIEW = 'under review';
    const STATUS = '';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Beneficiaries';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['MiddleName', 'Email', 'Phone', 'House', 'Street', 'State', 'City', 'Nationality', 'Relation', 'Gender', 'IDTypeID', 'IDNo', 'DocExpiry', 'Status', 'ScreeningResult', 'SceeningReference', 'LastSceeningAt'], 'default', 'value' => null],
            [['IsDelete'], 'default', 'value' => 0],
            [['UserID', 'FirstName', 'LastName'], 'required'],
            [['UserID', 'Nationality', 'Relation', 'IDTypeID', 'IsDelete'], 'integer'],
            [['Gender', 'Status'], 'string'],
            [['DocExpiry', 'OnDate', 'UpdatedDate', 'LastSceeningAt'], 'safe'],
            [['FirstName', 'MiddleName', 'LastName', 'Email', 'ScreeningResult'], 'string', 'max' => 100],
            [['Phone'], 'string', 'max' => 15],
            [['House', 'Street', 'State', 'City'], 'string', 'max' => 20],
            [['IDNo'], 'string', 'max' => 50],
            ['Gender', 'in', 'range' => array_keys(self::optsGender())],
            ['Status', 'in', 'range' => array_keys(self::optsStatus())],
            [
                ['Phone'],
                'unique',
                'targetAttribute' => ['UserID', 'Phone'],
                'message' => 'This mobile number already exists for this user.',
                'filter' => ['IsDelete' => 0]
            ],
            ['Phone', 'match', 'pattern' => '/^\+[0-9]{8,15}$/', 'message' => 'Invalid phone number'],
            [
                ['Email'],
                'unique',
                'targetAttribute' => ['UserID', 'Email'],
                'message' => 'This email already exists for this user.',
                'filter' => ['IsDelete' => 0]
            ],
            [['Email'], 'email', 'message' => 'Please enter a valid email Address'],
            [
                'Email',
                'match',
                'pattern' => '/^[A-Za-z0-9](?:[A-Za-z0-9._%+-]{0,62}[A-Za-z0-9])?@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z]{2,63})+$/i',
                'message' => 'Please enter a valid email Address.'
            ],
            [
                ['IDNo'],
                'unique',
                'targetAttribute' => ['UserID', 'IDNo'],
                'message' => 'This ID already exists for this user.',
                'filter' => ['IsDeleted' => 0]
            ],
            [
                ['FirstName', 'MiddleName', 'LastName'],
                'match',
                'pattern' => '/^[\pL\s\-]+$/u',
                'message' => 'Names can only contain letters, spaces, and hyphens'
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'BeneficiaryID' => 'Beneficiary ID',
            'UserID' => 'User ID',
            'FirstName' => 'First Name',
            'MiddleName' => 'Middle Name',
            'LastName' => 'Last Name',
            'Email' => 'Email',
            'Phone' => 'Phone',
            'House' => 'House',
            'Street' => 'Street',
            'State' => 'State',
            'City' => 'City',
            'Nationality' => 'Nationality',
            'Relation' => 'Relation',
            'Gender' => 'Gender',
            'IDTypeID' => 'Id Type ID',
            'IDNo' => 'Id No',
            'DocExpiry' => 'Doc Expiry',
            'IsDelete' => 'Is Delete',
            'Status' => 'Status',
            'OnDate' => 'On Date',
            'UpdatedDate' => 'Updated Date',
            'SceeningReference' => 'Sceening Reference',
            'ScreeningResult' => 'Screening Result',
            'LastSceeningAt' => 'Last Sceening At',
        ];
    }


    /**
     * column Gender ENUM value labels
     * @return string[]
     */
    public static function optsGender()
    {
        return [
            self::GENDER_MALE => 'Male',
            self::GENDER_FEMALE => 'Female',
        ];
    }

    /**
     * column Status ENUM value labels
     * @return string[]
     */
    public static function optsStatus()
    {
        return [
            self::STATUS_ACTIVATED => 'activated',
            self::STATUS_BLOCKED => 'blocked',
            self::STATUS_UNDER_REVIEW => 'under review',
            self::STATUS => '',
        ];
    }

    /**
     * @return string
     */
    public function displayGender()
    {
        return self::optsGender()[$this->Gender];
    }

    /**
     * @return bool
     */
    public function isGenderMale()
    {
        return $this->Gender === self::GENDER_MALE;
    }

    public function setGenderToMale()
    {
        $this->Gender = self::GENDER_MALE;
    }

    /**
     * @return bool
     */
    public function isGenderFemale()
    {
        return $this->Gender === self::GENDER_FEMALE;
    }

    public function setGenderToFemale()
    {
        $this->Gender = self::GENDER_FEMALE;
    }

    /**
     * @return string
     */
    public function displayStatus()
    {
        return self::optsStatus()[$this->Status];
    }

    /**
     * @return bool
     */
    public function isStatusActivated()
    {
        return $this->Status === self::STATUS_ACTIVATED;
    }

    public function setStatusToActivated()
    {
        $this->Status = self::STATUS_ACTIVATED;
    }

    /**
     * @return bool
     */
    public function isStatusBlocked()
    {
        return $this->Status === self::STATUS_BLOCKED;
    }

    public function setStatusToBlocked()
    {
        $this->Status = self::STATUS_BLOCKED;
    }

    /**
     * @return bool
     */
    public function isStatusUnderReview()
    {
        return $this->Status === self::STATUS_UNDER_REVIEW;
    }

    public function setStatusToUnderReview()
    {
        $this->Status = self::STATUS_UNDER_REVIEW;
    }

    /**
     * @return bool
     */
    public function isStatus()
    {
        return $this->Status === self::STATUS;
    }

    public function setStatusTo()
    {
        $this->Status = self::STATUS;
    }

    /**
     * Gets query for [[Nationality]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNationality()
    {
        return $this->hasOne(Countries::class, ['CountryID' => 'Nationality']);
    }

    /**
     * Gets query for [[Relation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRelations()
    {
        return $this->hasOne(Relations::class, ['RelationID' => 'Relation']);
    }

    /**
     * Gets query for [[BeneficiaryBankAccounts]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBeneficiaryBankAccounts()
    {
        return $this->hasMany(BeneficiaryBankAccounts::class, ['BeneficiaryId' => 'BeneficiaryID'])
            ->where(['IsDelete' => 0, 'Enable' => 1]);
    }
}
