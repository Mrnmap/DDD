<?php

namespace common\models;

use api\models\BanksSearch;
use Yii;
use common\services\BankAccountValidator;

/**
 * This is the model class for table "BeneficiaryBankAccounts".
 *
 * @property int $BeneficiaryBankAccountId
 * @property int|null $BeneficiaryId
 * @property int|null $UserId
 * @property int|null $CountryId
 * @property int $BankId
 * @property string $AccountNumber
 * @property string $BankingIdentifier
 * @property int $IsDelete
 * @property int $CreateUId
 * @property string $OnDate
 * @property int $UpdateUId
 * @property string $UpdatedDate
 * @property int|null $BranchId
 * @property int $Enable
 * @property string|null $AccountPhone
 * @property string|null $Address
 * @property string|null $AddressRegion
 * @property string|null $AddressCity
 * @property string|null $AddressStreet
 * @property string|null $AddressHouse
 */
class BeneficiaryBankAccounts extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const BANKINGIDENTIFIER_ACCOUNT = 'account';
    const BANKINGIDENTIFIER_IBAN = 'iban';
    const BANKINGIDENTIFIER_UPI = 'upi';
    const BANKINGIDENTIFIER = '';

    const countryId = '';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'BeneficiaryBankAccounts';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['BeneficiaryId', 'UserId', 'BranchId'], 'default', 'value' => null],
            [['Enable'], 'default', 'value' => 1],
            [['IsDelete'], 'default', 'value' => 0],
            [['BeneficiaryId', 'UserId', 'CountryId', 'BankId', 'IsDelete', 'CreateUId', 'UpdateUId', 'BranchId', 'Enable'], 'integer'],
            [['BranchId', 'BankId', 'AccountNumber', 'IsDelete', 'CreateUId', 'OnDate', 'UpdateUId'], 'required'],
            [['BankingIdentifier', 'AccountPhone', 'Address', 'AddressRegion', 'AddressCity', 'AddressStreet', 'AddressHouse'], 'string'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['AccountNumber'], 'string', 'max' => 60],
            [['AccountPhone'], 'string', 'max' => 15],
            ['BankingIdentifier', 'in', 'range' => array_keys(self::optsBankingIdentifier())],
            [
                'AccountNumber',
                'unique',
                'targetAttribute' => ['UserId', 'BeneficiaryId', 'AccountNumber'],
                'filter' => ['IsDelete' => 0],
                'message' => 'This account number already exists for the same beneficiary.',
            ],
            [
                'BankId',
                'exist',
                'targetClass' => Banks::class,
                'targetAttribute' => [
                    'BankId'   => 'BankID',
                    'CountryId' => 'CountryID',
                ],
                'message' => 'Invalid Bank for the selected country.'
            ],
            [
                'BeneficiaryId',
                'exist',
                'targetClass' => Beneficiaries::class, // adjust namespace
                'targetAttribute' => [
                    'BeneficiaryId' => 'BeneficiaryId',
                    'UserId'        => 'UserID',
                ],
                'message' => 'The selected Beneficiary does not belong to this User.',
            ],
            [
                ['AccountNumber'],
                BankAccountValidator::class, // to validate bank account number
                'bankIdAttribute' => 'BankId',
                'branchIdAttribute' => 'BranchId',
                'bankingIdentifierAttribute' => 'BankingIdentifier',
                'accountNumberAttribute' => 'AccountNumber',
                'countryIdAttribute' => 'CountryId',
            ]
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'BeneficiaryBankAccountId' => 'Beneficiary Bank Account ID',
            'BeneficiaryId' => 'Beneficiary ID',
            'UserId' => 'User ID',
            'BankId' => 'Bank ID',
            'AccountNumber' => 'Account Number',
            'BankingIdentifier' => 'Banking Identifier',
            'IsDelete' => 'Is Delete',
            'CreateUId' => 'Create U ID',
            'OnDate' => 'On Date',
            'UpdateUId' => 'Update U ID',
            'UpdatedDate' => 'Updated Date',
            'BranchId' => 'Branch ID',
            'Enable' => 'Enable',
            'AccountPhone' => 'Account Phone',
            'Address' => 'Address',
            'AddressRegion' => 'Address Region',
            'AddressCity' => 'Address City',
            'AddressStreet' => 'Address Street',
            'AddressHouse' => 'Address House',
        ];
    }


    /**
     * column BankingIdentifier ENUM value labels
     * @return string[]
     */
    public static function optsBankingIdentifier()
    {
        return [
            self::BANKINGIDENTIFIER_ACCOUNT => 'account',
            self::BANKINGIDENTIFIER_IBAN => 'iban',
            self::BANKINGIDENTIFIER_UPI => 'upi',
            self::BANKINGIDENTIFIER => '',
        ];
    }

    /**
     * @return string
     */
    public function displayBankingIdentifier()
    {
        return self::optsBankingIdentifier()[$this->BankingIdentifier];
    }

    /**
     * @return bool
     */
    public function isBankingIdentifierAccount()
    {
        return $this->BankingIdentifier === self::BANKINGIDENTIFIER_ACCOUNT;
    }

    public function setBankingIdentifierToAccount()
    {
        $this->BankingIdentifier = self::BANKINGIDENTIFIER_ACCOUNT;
    }

    /**
     * @return bool
     */
    public function isBankingIdentifierIban()
    {
        return $this->BankingIdentifier === self::BANKINGIDENTIFIER_IBAN;
    }

    public function setBankingIdentifierToIban()
    {
        $this->BankingIdentifier = self::BANKINGIDENTIFIER_IBAN;
    }

    /**
     * @return bool
     */
    public function isBankingIdentifierUpi()
    {
        return $this->BankingIdentifier === self::BANKINGIDENTIFIER_UPI;
    }

    public function setBankingIdentifierToUpi()
    {
        $this->BankingIdentifier = self::BANKINGIDENTIFIER_UPI;
    }

    /**
     * @return bool
     */
    public function isBankingIdentifier()
    {
        return $this->BankingIdentifier === self::BANKINGIDENTIFIER;
    }

    public function setBankingIdentifierTo()
    {
        $this->BankingIdentifier = self::BANKINGIDENTIFIER;
    }

    /**
     * Gets query for [[Banks]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBranch()
    {
        return $this->hasOne(BanksBranches::class, ['BranchID' => 'BranchId']);
    }
    /**
     * Gets query for [[Banks]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBank()
    {
        return $this->hasOne(Banks::class, ['BankID' => 'BankId']);
    }
    /**
     * Gets query for [[Countries]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(Countries::class, ['CountryID' => 'CountryId']);
    }
}
