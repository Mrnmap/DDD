<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "aml_screening_logs".
 *
 * @property int $id
 * @property string $internal_reference
 * @property string $screened_by
 * @property string $screening_timestamp
 * @property string $screening_result
 * @property string|null $entity_type
 * @property string|null $watchlist_source
 * @property string|null $response_summary
 * @property string|null $raw_response
 * @property int|null $entity_score
 */
class ComplianceScreening extends \yii\db\ActiveRecord
{
    // Screening result constants
    const RESULT_NO_MATCH = 'No Match';
    const RESULT_MATCH = 'Match';
    const RESULT_FALSE_POSITIVE = 'False Positive';
    const RESULT_CONFIRMED_MATCH = 'Confirmed Match';
    const RESULT_PENDING_REVIEW = 'Pending Review';
    const RESULT_ERROR = 'Error';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'aml_screening_logs';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['internal_reference', 'screened_by', 'screening_timestamp', 'screening_result'], 'required'],
            [['screening_timestamp'], 'safe'],
            [['entity_score'], 'integer', 'min' => 0, 'max' => 100],
            [['response_summary', 'raw_response'], 'string'],
            [['internal_reference', 'screened_by', 'watchlist_source'], 'string', 'max' => 100],
            [['screening_result'], 'in', 'range' => [
                self::RESULT_NO_MATCH,
                self::RESULT_MATCH,
                self::RESULT_FALSE_POSITIVE,
                self::RESULT_CONFIRMED_MATCH,
                self::RESULT_PENDING_REVIEW,
                self::RESULT_ERROR
            ]],
            [['entity_type'], 'string', 'max' => 50],
            [['internal_reference'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'internal_reference' => 'Internal Reference',
            'screened_by' => 'Screened By',
            'screening_timestamp' => 'Screening Timestamp',
            'screening_result' => 'Screening Result',
            'entity_type' => 'Entity Type',
            'entity_score' => 'Entity Score',
            'watchlist_source' => 'Watchlist Source',
            'response_summary' => 'Response Summary',
            'raw_response' => 'Raw Response',
        ];
    }

    /**
     * Get screening results as key-value pairs for dropdowns
     */
    public static function getScreeningResults()
    {
        return [
            self::RESULT_NO_MATCH => 'No Match',
            self::RESULT_MATCH => 'Match',
            self::RESULT_FALSE_POSITIVE => 'False Positive',
            self::RESULT_CONFIRMED_MATCH => 'Confirmed Match',
            self::RESULT_PENDING_REVIEW => 'Pending Review',
            self::RESULT_ERROR => 'Error',
        ];
    }

    /**
     * Check if screening result indicates a potential risk
     */
    public function isHighRisk()
    {
        return in_array($this->screening_result, [
            self::RESULT_MATCH,
            self::RESULT_CONFIRMED_MATCH,
            self::RESULT_PENDING_REVIEW
        ]);
    }

    /**
     * Get formatted response summary
     */
    public function getFormattedSummary()
    {
        if (empty($this->response_summary)) {
            return 'No summary available';
        }
        return $this->response_summary;
    }
} 