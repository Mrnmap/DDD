<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "TransferPurposes".
 *
 * @property int $PurposeID
 * @property string $Name
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 */
class TransferPurposes extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'TransferPurposes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Name', 'IsDelete', 'CreateUID', 'OnDate', 'UpdateUID'], 'required'],
            [['IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['Name'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'PurposeID' => 'Purpose ID',
            'Name' => 'Name',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }

}
