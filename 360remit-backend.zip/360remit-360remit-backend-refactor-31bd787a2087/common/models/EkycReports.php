<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "EkycReports".
 *
 * @property int $Id
 * @property int $UserId
 * @property string $ProviderReportId
 * @property string|null $SessionId
 * @property string|null $AdminStatus
 * @property string|null $AdminReasons
 * @property int|null $IsOfficial
 * @property string|null $ProviderStatus
 * @property string|null $SystemDecision
 * @property string|null $SystemDecisionReasonsJson
 * @property string|null $RawJson
 * @property string|null $FullNameEn
 * @property string|null $FullNameAr
 * @property string|null $DocumentNumber
 * @property string|null $DocumentType
 * @property string|null $DateOfBirth
 * @property string|null $ExpiryDate
 * @property string|null $IssuingState
 * @property string|null $MrzFormat
 * @property string|null $MrzDocumentType
 * @property string|null $MrzGender
 * @property string|null $MrzCountryIso2
 * @property string|null $MrzCountryIso3
 * @property string|null $MrzNationalityIso2
 * @property string|null $MrzNationalityIso3
 * @property string|null $MrzString
 * @property int|null $IsExpired
 * @property int|null $MrzChecksumPassed
 * @property float|null $FaceMatchingScore
 * @property int|null $IsFaceMatched
 * @property int|null $IsPassivePassed
 * @property float|null $GenuineIdPhotoScore
 * @property float|null $NoScreenCaptureScore
 * @property float|null $NoPrintedCopyScore
 * @property int|null $DataConsistencyCheckPassed
 * @property int|null $GenderValidationPassed
 * @property int|null $DocumentNumberValidationPassed
 * @property int|null $DobValidationPassed
 * @property int|null $NationalityValidationPassed
 * @property int|null $IsDocumentHashValid
 * @property int|null $IsDobHashValid
 * @property int|null $IsExpiryHashValid
 * @property string|null $OverallCheckValidRaw
 * @property float|null $CaptureDuration
 * @property float|null $CaptureDurationFront
 * @property float|null $CaptureDurationBack
 * @property string|null $SdkVersion
 * @property string|null $SdkType
 * @property string|null $DeviceId
 * @property string|null $DeviceGuid
 * @property string|null $StartedAtRaw
 * @property string|null $EndedAtRaw
 * @property string|null $CreatedAt
 * @property string|null $UpdatedAt
 */
class EkycReports extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const ADMINSTATUS_REVIEW = 'review';
    const ADMINSTATUS_APPROVED = 'approved';
    const ADMINSTATUS_REJECTED = 'rejected';
    const SYSTEMDECISION_APPROVED = 'approved';
    const SYSTEMDECISION_REVIEW = 'review';
    const SYSTEMDECISION_REJECTED = 'rejected';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'EkycReports';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['SessionId', 'AdminStatus', 'AdminReasons', 'IsOfficial', 'ProviderStatus', 'SystemDecision', 'SystemDecisionReasonsJson', 'RawJson', 'FullNameEn', 'FullNameAr', 'DocumentNumber', 'DocumentType', 'DateOfBirth', 'ExpiryDate', 'IssuingState', 'MrzFormat', 'MrzDocumentType', 'MrzGender', 'MrzCountryIso2', 'MrzCountryIso3', 'MrzNationalityIso2', 'MrzNationalityIso3', 'MrzString', 'IsExpired', 'MrzChecksumPassed', 'FaceMatchingScore', 'IsFaceMatched', 'IsPassivePassed', 'GenuineIdPhotoScore', 'NoScreenCaptureScore', 'NoPrintedCopyScore', 'DataConsistencyCheckPassed', 'GenderValidationPassed', 'DocumentNumberValidationPassed', 'DobValidationPassed', 'NationalityValidationPassed', 'IsDocumentHashValid', 'IsDobHashValid', 'IsExpiryHashValid', 'OverallCheckValidRaw', 'CaptureDuration', 'CaptureDurationFront', 'CaptureDurationBack', 'SdkVersion', 'SdkType', 'DeviceId', 'DeviceGuid', 'StartedAtRaw', 'EndedAtRaw'], 'default', 'value' => null],
            [['UserId', 'ProviderReportId'], 'required'],
            [['UserId', 'IsOfficial', 'IsExpired', 'MrzChecksumPassed', 'IsFaceMatched', 'IsPassivePassed', 'DataConsistencyCheckPassed', 'GenderValidationPassed', 'DocumentNumberValidationPassed', 'DobValidationPassed', 'NationalityValidationPassed', 'IsDocumentHashValid', 'IsDobHashValid', 'IsExpiryHashValid'], 'integer'],
            [['AdminStatus', 'SystemDecision', 'SystemDecisionReasonsJson', 'RawJson', 'MrzString'], 'string'],
            [['DateOfBirth', 'ExpiryDate', 'CreatedAt', 'UpdatedAt'], 'safe'],
            [['FaceMatchingScore', 'GenuineIdPhotoScore', 'NoScreenCaptureScore', 'NoPrintedCopyScore', 'CaptureDuration', 'CaptureDurationFront', 'CaptureDurationBack'], 'number'],
            [['ProviderReportId', 'SessionId', 'DocumentNumber', 'IssuingState', 'DeviceId', 'DeviceGuid'], 'string', 'max' => 100],
            [['AdminReasons'], 'string', 'max' => 250],
            [['ProviderStatus', 'DocumentType', 'MrzFormat', 'MrzDocumentType', 'SdkVersion', 'SdkType', 'StartedAtRaw', 'EndedAtRaw'], 'string', 'max' => 50],
            [['FullNameEn', 'FullNameAr'], 'string', 'max' => 200],
            [['MrzGender'], 'string', 'max' => 20],
            [['MrzCountryIso2', 'MrzCountryIso3', 'MrzNationalityIso2', 'MrzNationalityIso3', 'OverallCheckValidRaw'], 'string', 'max' => 10],
            ['AdminStatus', 'in', 'range' => array_keys(self::optsAdminStatus())],
            ['SystemDecision', 'in', 'range' => array_keys(self::optsSystemDecision())],
            [['ProviderReportId'], 'unique'],
            [['UserId', 'IsOfficial'], 'unique', 'targetAttribute' => ['UserId', 'IsOfficial']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'UserId' => 'User ID',
            'ProviderReportId' => 'Provider Report ID',
            'SessionId' => 'Session ID',
            'AdminStatus' => 'Admin Status',
            'AdminReasons' => 'Admin Reasons',
            'IsOfficial' => 'Is Official',
            'ProviderStatus' => 'Provider Status',
            'SystemDecision' => 'System Decision',
            'SystemDecisionReasonsJson' => 'System Decision Reasons Json',
            'RawJson' => 'Raw Json',
            'FullNameEn' => 'Full Name En',
            'FullNameAr' => 'Full Name Ar',
            'DocumentNumber' => 'Document Number',
            'DocumentType' => 'Document Type',
            'DateOfBirth' => 'Date Of Birth',
            'ExpiryDate' => 'Expiry Date',
            'IssuingState' => 'Issuing State',
            'MrzFormat' => 'Mrz Format',
            'MrzDocumentType' => 'Mrz Document Type',
            'MrzGender' => 'Mrz Gender',
            'MrzCountryIso2' => 'Mrz Country Iso2',
            'MrzCountryIso3' => 'Mrz Country Iso3',
            'MrzNationalityIso2' => 'Mrz Nationality Iso2',
            'MrzNationalityIso3' => 'Mrz Nationality Iso3',
            'MrzString' => 'Mrz String',
            'IsExpired' => 'Is Expired',
            'MrzChecksumPassed' => 'Mrz Checksum Passed',
            'FaceMatchingScore' => 'Face Matching Score',
            'IsFaceMatched' => 'Is Face Matched',
            'IsPassivePassed' => 'Is Passive Passed',
            'GenuineIdPhotoScore' => 'Genuine Id Photo Score',
            'NoScreenCaptureScore' => 'No Screen Capture Score',
            'NoPrintedCopyScore' => 'No Printed Copy Score',
            'DataConsistencyCheckPassed' => 'Data Consistency Check Passed',
            'GenderValidationPassed' => 'Gender Validation Passed',
            'DocumentNumberValidationPassed' => 'Document Number Validation Passed',
            'DobValidationPassed' => 'Dob Validation Passed',
            'NationalityValidationPassed' => 'Nationality Validation Passed',
            'IsDocumentHashValid' => 'Is Document Hash Valid',
            'IsDobHashValid' => 'Is Dob Hash Valid',
            'IsExpiryHashValid' => 'Is Expiry Hash Valid',
            'OverallCheckValidRaw' => 'Overall Check Valid Raw',
            'CaptureDuration' => 'Capture Duration',
            'CaptureDurationFront' => 'Capture Duration Front',
            'CaptureDurationBack' => 'Capture Duration Back',
            'SdkVersion' => 'Sdk Version',
            'SdkType' => 'Sdk Type',
            'DeviceId' => 'Device ID',
            'DeviceGuid' => 'Device Guid',
            'StartedAtRaw' => 'Started At Raw',
            'EndedAtRaw' => 'Ended At Raw',
            'CreatedAt' => 'Created At',
            'UpdatedAt' => 'Updated At',
        ];
    }


    /**
     * column AdminStatus ENUM value labels
     * @return string[]
     */
    public static function optsAdminStatus()
    {
        return [
            self::ADMINSTATUS_REVIEW => 'review',
            self::ADMINSTATUS_APPROVED => 'approved',
            self::ADMINSTATUS_REJECTED => 'rejected',
        ];
    }

    /**
     * column SystemDecision ENUM value labels
     * @return string[]
     */
    public static function optsSystemDecision()
    {
        return [
            self::SYSTEMDECISION_APPROVED => 'approved',
            self::SYSTEMDECISION_REVIEW => 'review',
            self::SYSTEMDECISION_REJECTED => 'rejected',
        ];
    }

    /**
     * @return string
     */
    public function displayAdminStatus()
    {
        return self::optsAdminStatus()[$this->AdminStatus];
    }

    /**
     * @return bool
     */
    public function isAdminStatusReview()
    {
        return $this->AdminStatus === self::ADMINSTATUS_REVIEW;
    }

    public function setAdminStatusToReview()
    {
        $this->AdminStatus = self::ADMINSTATUS_REVIEW;
    }

    /**
     * @return bool
     */
    public function isAdminStatusApproved()
    {
        return $this->AdminStatus === self::ADMINSTATUS_APPROVED;
    }

    public function setAdminStatusToApproved()
    {
        $this->AdminStatus = self::ADMINSTATUS_APPROVED;
    }

    /**
     * @return bool
     */
    public function isAdminStatusRejected()
    {
        return $this->AdminStatus === self::ADMINSTATUS_REJECTED;
    }

    public function setAdminStatusToRejected()
    {
        $this->AdminStatus = self::ADMINSTATUS_REJECTED;
    }

    /**
     * @return string
     */
    public function displaySystemDecision()
    {
        return self::optsSystemDecision()[$this->SystemDecision];
    }

    /**
     * @return bool
     */
    public function isSystemDecisionApproved()
    {
        return $this->SystemDecision === self::SYSTEMDECISION_APPROVED;
    }

    public function setSystemDecisionToApproved()
    {
        $this->SystemDecision = self::SYSTEMDECISION_APPROVED;
    }

    /**
     * @return bool
     */
    public function isSystemDecisionReview()
    {
        return $this->SystemDecision === self::SYSTEMDECISION_REVIEW;
    }

    public function setSystemDecisionToReview()
    {
        $this->SystemDecision = self::SYSTEMDECISION_REVIEW;
    }

    /**
     * @return bool
     */
    public function isSystemDecisionRejected()
    {
        return $this->SystemDecision === self::SYSTEMDECISION_REJECTED;
    }

    public function setSystemDecisionToRejected()
    {
        $this->SystemDecision = self::SYSTEMDECISION_REJECTED;
    }
}
