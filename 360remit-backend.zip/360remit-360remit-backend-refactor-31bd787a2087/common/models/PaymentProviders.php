<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "PaymentProviders".
 *
 * @property int $PaymentProviderID
 * @property string $Name
 * @property string $Description
 * @property int $Enable
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 */
class PaymentProviders extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'PaymentProviders';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Name', 'Description', 'Enable', 'IsDelete', 'CreateUID', 'OnDate', 'UpdateUID'], 'required'],
            [['Enable', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['Name'], 'string', 'max' => 150],
            [['Description'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'PaymentProviderID' => 'Payment Provider ID',
            'Name' => 'Name',
            'Description' => 'Description',
            'Enable' => 'Enable',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }

    /**
     * Gets query for [[PaymentProviderCredentials]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCredentials()
    {
        return $this->hasMany(PaymentProviderCredentials::class, ['PaymentProviderID' => 'PaymentProviderID']);
    }
}
