<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "MastercardBanks".
 *
 * @property string $MastercardBankID
 * @property int $BankId
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property string $UpdateUID
 */
class MastercardBanks extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'MastercardBanks';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['UpdateUID'], 'default', 'value' => '0000-00-00 00:00:00.000000'],
            [['MastercardBankID', 'BankId', 'IsDelete', 'CreateUID'], 'required'],
            [['BankId', 'IsDelete', 'CreateUID'], 'integer'],
            [['OnDate', 'UpdateUID'], 'safe'],
            [['MastercardBankID'], 'string', 'max' => 20],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'MastercardBankID' => 'Mastercard Bank ID',
            'BankId' => 'Bank ID',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
        ];
    }

}
