<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "PaymentProviderCredentials".
 *
 * @property int $CredentialsID
 * @property int $PaymentProviderID
 * @property string $KeyName
 * @property string $KeyValue
 * @property int $Enable
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 */
class PaymentProviderCredentials extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'PaymentProviderCredentials';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['PaymentProviderID', 'KeyName', 'KeyValue', 'Enable', 'IsDelete', 'CreateUID', 'OnDate', 'UpdateUID'], 'required'],
            [['PaymentProviderID', 'Enable', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['KeyName', 'KeyValue'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'CredentialsID' => 'Credentials ID',
            'PaymentProviderID' => 'Payment Provider ID',
            'KeyName' => 'Key Name',
            'KeyValue' => 'Key Value',
            'Enable' => 'Enable',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }
}
