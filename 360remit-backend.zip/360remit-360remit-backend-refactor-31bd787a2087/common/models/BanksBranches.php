<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "BanksBranches".
 *
 * @property int $BranchID
 * @property string $ID
 * @property int $BankID
 * @property string $MCBankID
 * @property int $CompanyID
 * @property int $CountryID
 * @property string $CountryCode
 * @property string $Branch
 * @property int $Enable
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 *
 * @property Banks $bank
 * @property Countries $country
 */
class BanksBranches extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'BanksBranches';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['BankID', 'MCBankID', 'CompanyID', 'CountryID', 'CountryCode', 'Branch', 'CreateUID', 'OnDate', 'UpdateUID', 'UpdatedDate'], 'required'],
            [['BankID', 'CompanyID', 'CountryID', 'Enable', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['ID', 'MCBankID', 'Branch'], 'string', 'max' => 100],
            [['CountryCode'], 'string', 'max' => 2],
            [['BankID'], 'exist', 'skipOnError' => true, 'targetClass' => Banks::class, 'targetAttribute' => ['BankID' => 'BankID']],
            [['CountryID'], 'exist', 'skipOnError' => true, 'targetClass' => Countries::class, 'targetAttribute' => ['CountryID' => 'CountryID']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'BranchID' => 'Branch ID',
            'ID' => 'ID',
            'BankID' => 'Bank ID',
            'MCBankID' => 'MC Bank ID',
            'CompanyID' => 'Company ID',
            'CountryID' => 'Country ID',
            'CountryCode' => 'Country Code',
            'Branch' => 'Branch',
            'Enable' => 'Enabled',
            'IsDelete' => 'Deleted',
            'CreateUID' => 'Created By',
            'OnDate' => 'Created On',
            'UpdateUID' => 'Updated By',
            'UpdatedDate' => 'Updated On',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBank()
    {
        return $this->hasOne(Banks::class, ['BankID' => 'BankID']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(Countries::class, ['CountryID' => 'CountryID']);
    }
}
