<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "TransactionStatus".
 *
 * @property int $Id
 * @property string $Name
 * @property string $Description
 */
class TransactionStatus extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'TransactionStatus';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Name', 'Description'], 'required'],
            [['Name'], 'string', 'max' => 50],
            [['Description'], 'string', 'max' => 250],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'Name' => 'Name',
            'Description' => 'Description',
        ];
    }

}
