<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Users".
 *
 * @property int $UserID
 * @property string $Name
 * @property string|null $MiddleName
 * @property string|null $Surname
 * @property string $Email
 * @property int $auth_key
 * @property int $PinFailedAttempts
 * @property string|null $PinLockUntil
 * @property string|null $SignupDeviceID
 * @property string|null $MPIN
 * @property int $IsDelete
 * @property string $OnDate
 * @property string $UpdatedDate
 * @property string|null $Status Just a column, NOT USED!
 * @property string|null $PinStatus
 * @property string $TransactionStatus user being able to make transactions
 */
class Users extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_BLOCKED = 'blocked';
    const STATUS_UNDER_REVIEW = 'under review';
    const PINSTATUS_ACTIVE = 'active';
    const PINSTATUS_TEMP_LOCKED = 'temp_locked';
    const PINSTATUS_BLOCKED = 'blocked';
    const TRANSACTIONSTATUS_ACTIVE = 'active';
    const TRANSACTIONSTATUS_BLOCKED = 'blocked';
    const TRANSACTIONSTATUS_SUSPENDED = 'suspended';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Users';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['MiddleName', 'Surname', 'PinLockUntil', 'SignupDeviceID', 'MPIN', 'Status', 'PinStatus'], 'default', 'value' => null],
            [['IsDelete'], 'default', 'value' => 0],
            [['TransactionStatus'], 'default', 'value' => 'active'],
            [['OnDate'], 'required'],
            [['PinFailedAttempts', 'IsDelete'], 'integer'],
            [['PinLockUntil', 'OnDate', 'UpdatedDate'], 'safe'],
            [['Status', 'PinStatus', 'TransactionStatus'], 'string'],
            [['Name', 'MiddleName', 'Surname'], 'string', 'max' => 50],
            [['Email', 'SignupDeviceID', 'MPIN'], 'string', 'max' => 100],
            ['Status', 'in', 'range' => array_keys(self::optsStatus())],
            ['PinStatus', 'in', 'range' => array_keys(self::optsPinStatus())],
            ['TransactionStatus', 'in', 'range' => array_keys(self::optsTransactionStatus())],
            [
                ['Email'],
                'unique',
                'targetAttribute' => ['UserID', 'Email'],
                'message' => 'This email already exists for this user.'
            ],
            [
                'Email',
                'match',
                'pattern' => '/^[A-Za-z0-9](?:[A-Za-z0-9._%+-]{0,62}[A-Za-z0-9])?@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z]{2,63})+$/i',
                'message' => 'Please enter a valid email Address.'
            ],
            [
                ['Name', 'Surname'],
                'match',
                'pattern' => '/^[\pL\s\-]+$/u',
                'message' => 'Names can only contain letters, spaces, and hyphens'
            ]
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'UserID' => 'User ID',
            'Name' => 'Name',
            'MiddleName' => 'Middle Name',
            'Surname' => 'Surname',
            'Email' => 'Email',
            'auth_key' => 'Auth Key',
            'PinFailedAttempts' => 'Pin Failed Attempts',
            'PinLockUntil' => 'Pin Lock Until',
            'SignupDeviceID' => 'Signup Device ID',
            'MPIN' => 'Mpin',
            'IsDelete' => 'Is Delete',
            'OnDate' => 'On Date',
            'UpdatedDate' => 'Updated Date',
            'Status' => 'Status',
            'PinStatus' => 'Pin Status',
            'TransactionStatus' => 'Transaction Status',
        ];
    }


    /**
     * column Status ENUM value labels
     * @return string[]
     */
    public static function optsStatus()
    {
        return [
            self::STATUS_ACTIVE => 'active',
            self::STATUS_INACTIVE => 'inactive',
            self::STATUS_BLOCKED => 'blocked',
            self::STATUS_UNDER_REVIEW => 'under review',
        ];
    }

    /**
     * column PinStatus ENUM value labels
     * @return string[]
     */
    public static function optsPinStatus()
    {
        return [
            self::PINSTATUS_ACTIVE => 'active',
            self::PINSTATUS_TEMP_LOCKED => 'temp_locked',
            self::PINSTATUS_BLOCKED => 'blocked',
        ];
    }

    /**
     * column TransactionStatus ENUM value labels
     * @return string[]
     */
    public static function optsTransactionStatus()
    {
        return [
            self::TRANSACTIONSTATUS_ACTIVE => 'active',
            self::TRANSACTIONSTATUS_BLOCKED => 'blocked',
            self::TRANSACTIONSTATUS_SUSPENDED => 'suspended',
        ];
    }

    /**
     * @return string
     */
    public function displayStatus()
    {
        return self::optsStatus()[$this->Status];
    }

    /**
     * @return bool
     */
    public function isStatusActive()
    {
        return $this->Status === self::STATUS_ACTIVE;
    }

    public function setStatusToActive()
    {
        $this->Status = self::STATUS_ACTIVE;
    }

    /**
     * @return bool
     */
    public function isStatusInactive()
    {
        return $this->Status === self::STATUS_INACTIVE;
    }

    public function setStatusToInactive()
    {
        $this->Status = self::STATUS_INACTIVE;
    }

    /**
     * @return bool
     */
    public function isStatusBlocked()
    {
        return $this->Status === self::STATUS_BLOCKED;
    }

    public function setStatusToBlocked()
    {
        $this->Status = self::STATUS_BLOCKED;
    }

    /**
     * @return bool
     */
    public function isStatusUnderReview()
    {
        return $this->Status === self::STATUS_UNDER_REVIEW;
    }

    public function setStatusToUnderReview()
    {
        $this->Status = self::STATUS_UNDER_REVIEW;
    }

    /**
     * @return string
     */
    public function displayPinStatus()
    {
        return self::optsPinStatus()[$this->PinStatus];
    }

    /**
     * @return bool
     */
    public function isPinStatusActive()
    {
        return $this->PinStatus === self::PINSTATUS_ACTIVE;
    }

    public function setPinStatusToActive()
    {
        $this->PinStatus = self::PINSTATUS_ACTIVE;
    }

    /**
     * @return bool
     */
    public function isPinStatusTemplocked()
    {
        return $this->PinStatus === self::PINSTATUS_TEMP_LOCKED;
    }

    public function setPinStatusToTemplocked()
    {
        $this->PinStatus = self::PINSTATUS_TEMP_LOCKED;
    }

    /**
     * @return bool
     */
    public function isPinStatusBlocked()
    {
        return $this->PinStatus === self::PINSTATUS_BLOCKED;
    }

    public function setPinStatusToBlocked()
    {
        $this->PinStatus = self::PINSTATUS_BLOCKED;
    }

    /**
     * @return string
     */
    public function displayTransactionStatus()
    {
        return self::optsTransactionStatus()[$this->TransactionStatus];
    }

    /**
     * @return bool
     */
    public function isTransactionStatusActive()
    {
        return $this->TransactionStatus === self::TRANSACTIONSTATUS_ACTIVE;
    }

    public function setTransactionStatusToActive()
    {
        $this->TransactionStatus = self::TRANSACTIONSTATUS_ACTIVE;
    }

    /**
     * @return bool
     */
    public function isTransactionStatusBlocked()
    {
        return $this->TransactionStatus === self::TRANSACTIONSTATUS_BLOCKED;
    }

    public function setTransactionStatusToBlocked()
    {
        $this->TransactionStatus = self::TRANSACTIONSTATUS_BLOCKED;
    }

    /**
     * @return bool
     */
    public function isTransactionStatusSuspended()
    {
        return $this->TransactionStatus === self::TRANSACTIONSTATUS_SUSPENDED;
    }

    public function setTransactionStatusToSuspended()
    {
        $this->TransactionStatus = self::TRANSACTIONSTATUS_SUSPENDED;
    }


    /**
     * Gets query for [[Customer]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCustomer()
    {
        return $this->hasOne(Customers::class, ['UserID' => 'UserID']);
    }
}
