<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "TransactionLogs".
 *
 * @property int $ID
 * @property int $TransactionID
 * @property int $TransactionStatus
 * @property string $InternalSatus
 * @property string $Source
 * @property string|null $Comment
 * @property string|null $ProviderRawJsonRequest
 * @property string $CreatedAt
 *
 * @property Transactions $transaction
 */
class TransactionLogs extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const INTERNALSATUS_NEW = 'new';
    const INTERNALSATUS_CANCEL_IN_MASTERCARD = 'cancel in mastercard';
    const INTERNALSATUS_FUNDS_CAPTURED = 'funds captured';
    const INTERNALSATUS_FUNDS_NOT_CAPTURED = 'funds not captured';
    const INTERNALSATUS_CANCELED_BY_SYSTEM = 'canceled by system';
    const INTERNALSATUS_SUBMITTED = 'submitted';
    const INTERNALSATUS_RELEASED_IN_MASTERCARD = 'released in mastercard';
    const INTERNALSATUS_MANUAL_REVIEW = 'manual review';
    const INTERNALSATUS_COMPLIANCE_CLEARED = 'compliance cleared';
    const INTERNALSATUS_INITIATED_IN_MASTERCARD = 'initiated in mastercard';
    const INTERNALSATUS_INITIATE_PAYMENT_WITH_OMANNET = 'initiate payment with omannet';
    const INTERNALSATUS_COMPLIANCE_SCREENING = 'compliance screening';
    const SOURCE_SYSTEM = 'system';
    const SOURCE_GATEWAY = 'gateway';
    const SOURCE_PARTNER = 'partner';
    const SOURCE_MANUAL = 'manual';
    const SOURCE_USER = 'user';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'TransactionLogs';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Comment', 'ProviderRawJsonRequest'], 'default', 'value' => null],
            [['TransactionID', 'TransactionStatus', 'InternalSatus', 'Source'], 'required'],
            [['TransactionID', 'TransactionStatus'], 'integer'],
            [['InternalSatus', 'Source', 'Comment'], 'string'],
            [['ProviderRawJsonRequest', 'CreatedAt'], 'safe'],
            ['InternalSatus', 'in', 'range' => array_keys(self::optsInternalSatus())],
            ['Source', 'in', 'range' => array_keys(self::optsSource())],
            [['TransactionID'], 'exist', 'skipOnError' => true, 'targetClass' => Transactions::class, 'targetAttribute' => ['TransactionID' => 'TransactionID']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'TransactionID' => 'Transaction ID',
            'TransactionStatus' => 'Transaction Status',
            'InternalSatus' => 'Internal Satus',
            'Source' => 'Source',
            'Comment' => 'Comment',
            'ProviderRawJsonRequest' => 'Provider Raw Json Request',
            'CreatedAt' => 'Created At',
        ];
    }

    /**
     * Gets query for [[Transaction]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransaction()
    {
        return $this->hasOne(Transactions::class, ['TransactionID' => 'TransactionID']);
    }


    /**
     * column InternalSatus ENUM value labels
     * @return string[]
     */
    public static function optsInternalSatus()
    {
        return [
            self::INTERNALSATUS_NEW => 'new',
            self::INTERNALSATUS_CANCEL_IN_MASTERCARD => 'cancel in mastercard',
            self::INTERNALSATUS_FUNDS_CAPTURED => 'funds captured',
            self::INTERNALSATUS_FUNDS_NOT_CAPTURED => 'funds not captured',
            self::INTERNALSATUS_CANCELED_BY_SYSTEM => 'canceled by system',
            self::INTERNALSATUS_SUBMITTED => 'submitted',
            self::INTERNALSATUS_RELEASED_IN_MASTERCARD => 'released in mastercard',
            self::INTERNALSATUS_MANUAL_REVIEW => 'manual review',
            self::INTERNALSATUS_COMPLIANCE_CLEARED => 'compliance cleared',
            self::INTERNALSATUS_INITIATED_IN_MASTERCARD => 'initiated in mastercard',
            self::INTERNALSATUS_INITIATE_PAYMENT_WITH_OMANNET => 'initiate payment with omannet',
            self::INTERNALSATUS_COMPLIANCE_SCREENING => 'compliance screening',
        ];
    }

    /**
     * column Source ENUM value labels
     * @return string[]
     */
    public static function optsSource()
    {
        return [
            self::SOURCE_SYSTEM => 'system',
            self::SOURCE_GATEWAY => 'gateway',
            self::SOURCE_PARTNER => 'partner',
            self::SOURCE_MANUAL => 'manual',
            self::SOURCE_USER => 'user',
        ];
    }

    /**
     * @return string
     */
    public function displayInternalSatus()
    {
        return self::optsInternalSatus()[$this->InternalSatus];
    }

    /**
     * @return bool
     */
    public function isInternalSatusNew()
    {
        return $this->InternalSatus === self::INTERNALSATUS_NEW;
    }

    public function setInternalSatusToNew()
    {
        $this->InternalSatus = self::INTERNALSATUS_NEW;
    }

    /**
     * @return bool
     */
    public function isInternalSatusCancelInMastercard()
    {
        return $this->InternalSatus === self::INTERNALSATUS_CANCEL_IN_MASTERCARD;
    }

    public function setInternalSatusToCancelInMastercard()
    {
        $this->InternalSatus = self::INTERNALSATUS_CANCEL_IN_MASTERCARD;
    }

    /**
     * @return bool
     */
    public function isInternalSatusFundsCaptured()
    {
        return $this->InternalSatus === self::INTERNALSATUS_FUNDS_CAPTURED;
    }

    public function setInternalSatusToFundsCaptured()
    {
        $this->InternalSatus = self::INTERNALSATUS_FUNDS_CAPTURED;
    }

    /**
     * @return bool
     */
    public function isInternalSatusFundsNotCaptured()
    {
        return $this->InternalSatus === self::INTERNALSATUS_FUNDS_NOT_CAPTURED;
    }

    public function setInternalSatusToFundsNotCaptured()
    {
        $this->InternalSatus = self::INTERNALSATUS_FUNDS_NOT_CAPTURED;
    }

    /**
     * @return bool
     */
    public function isInternalSatusCanceledBySystem()
    {
        return $this->InternalSatus === self::INTERNALSATUS_CANCELED_BY_SYSTEM;
    }

    public function setInternalSatusToCanceledBySystem()
    {
        $this->InternalSatus = self::INTERNALSATUS_CANCELED_BY_SYSTEM;
    }

    /**
     * @return bool
     */
    public function isInternalSatusSubmitted()
    {
        return $this->InternalSatus === self::INTERNALSATUS_SUBMITTED;
    }

    public function setInternalSatusToSubmitted()
    {
        $this->InternalSatus = self::INTERNALSATUS_SUBMITTED;
    }

    /**
     * @return bool
     */
    public function isInternalSatusReleasedInMastercard()
    {
        return $this->InternalSatus === self::INTERNALSATUS_RELEASED_IN_MASTERCARD;
    }

    public function setInternalSatusToReleasedInMastercard()
    {
        $this->InternalSatus = self::INTERNALSATUS_RELEASED_IN_MASTERCARD;
    }

    /**
     * @return bool
     */
    public function isInternalSatusManualReview()
    {
        return $this->InternalSatus === self::INTERNALSATUS_MANUAL_REVIEW;
    }

    public function setInternalSatusToManualReview()
    {
        $this->InternalSatus = self::INTERNALSATUS_MANUAL_REVIEW;
    }

    /**
     * @return bool
     */
    public function isInternalSatusComplianceCleared()
    {
        return $this->InternalSatus === self::INTERNALSATUS_COMPLIANCE_CLEARED;
    }

    public function setInternalSatusToComplianceCleared()
    {
        $this->InternalSatus = self::INTERNALSATUS_COMPLIANCE_CLEARED;
    }

    /**
     * @return bool
     */
    public function isInternalSatusInitiatedInMastercard()
    {
        return $this->InternalSatus === self::INTERNALSATUS_INITIATED_IN_MASTERCARD;
    }

    public function setInternalSatusToInitiatedInMastercard()
    {
        $this->InternalSatus = self::INTERNALSATUS_INITIATED_IN_MASTERCARD;
    }

    /**
     * @return bool
     */
    public function isInternalSatusInitiatePaymentWithOmannet()
    {
        return $this->InternalSatus === self::INTERNALSATUS_INITIATE_PAYMENT_WITH_OMANNET;
    }

    public function setInternalSatusToInitiatePaymentWithOmannet()
    {
        $this->InternalSatus = self::INTERNALSATUS_INITIATE_PAYMENT_WITH_OMANNET;
    }

    /**
     * @return bool
     */
    public function isInternalSatusComplianceScreening()
    {
        return $this->InternalSatus === self::INTERNALSATUS_COMPLIANCE_SCREENING;
    }

    public function setInternalSatusToComplianceScreening()
    {
        $this->InternalSatus = self::INTERNALSATUS_COMPLIANCE_SCREENING;
    }

    /**
     * @return string
     */
    public function displaySource()
    {
        return self::optsSource()[$this->Source];
    }

    /**
     * @return bool
     */
    public function isSourceSystem()
    {
        return $this->Source === self::SOURCE_SYSTEM;
    }

    public function setSourceToSystem()
    {
        $this->Source = self::SOURCE_SYSTEM;
    }

    /**
     * @return bool
     */
    public function isSourceGateway()
    {
        return $this->Source === self::SOURCE_GATEWAY;
    }

    public function setSourceToGateway()
    {
        $this->Source = self::SOURCE_GATEWAY;
    }

    /**
     * @return bool
     */
    public function isSourcePartner()
    {
        return $this->Source === self::SOURCE_PARTNER;
    }

    public function setSourceToPartner()
    {
        $this->Source = self::SOURCE_PARTNER;
    }

    /**
     * @return bool
     */
    public function isSourceManual()
    {
        return $this->Source === self::SOURCE_MANUAL;
    }

    public function setSourceToManual()
    {
        $this->Source = self::SOURCE_MANUAL;
    }

    /**
     * @return bool
     */
    public function isSourceUser()
    {
        return $this->Source === self::SOURCE_USER;
    }

    public function setSourceToUser()
    {
        $this->Source = self::SOURCE_USER;
    }
}
