<?php

namespace common\models;

use common\services\Mastercard;
use Yii;

/**
 * This is the model class for table "Banks".
 *
 * @property int $BankID
 * @property int $CompanyID
 * @property int $ID
 * @property string $Name
 * @property int $CountryID
 * @property string $CountryCode
 * @property int $Enable
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 *
 * @property Countries $country
 */
class Banks extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Banks';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CompanyID', 'Name', 'CountryID', 'CountryCode', 'CreateUID', 'OnDate', 'UpdateUID', 'UpdatedDate'], 'required'],
            [['CompanyID', 'ID', 'CountryID', 'Enable', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['Name'], 'string', 'max' => 255],
            [['CountryCode'], 'string', 'max' => 3],
            [['CountryID'], 'exist', 'skipOnError' => true, 'targetClass' => Countries::class, 'targetAttribute' => ['CountryID' => 'CountryID']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'BankID' => 'Bank ID',
            'CompanyID' => 'Company ID',
            'ID' => 'ID',
            'Name' => 'Name',
            'CountryID' => 'Country ID',
            'CountryCode' => 'Country Code',
            'Enable' => 'Enabled',
            'IsDelete' => 'Deleted',
            'CreateUID' => 'Created By',
            'OnDate' => 'Created On',
            'UpdateUID' => 'Updated By',
            'UpdatedDate' => 'Updated On',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(Countries::class, ['CountryID' => 'CountryID']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMastercardBank()
    {
        return $this->hasOne(MastercardBanks::class, ['BankId' => 'BankID']);
    }


    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBranches()
    {
        return $this->hasMany(BanksBranches::class, ['BankID' => 'BankID']);
    }
}
