<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "CountryCurrencies".
 *
 * @property string $CountryCode
 * @property string $CurrencyCode
 *
 * @property Countries $countryCode
 * @property Currencies $currencyCode
 */
class CountryCurrencies extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'CountryCurrencies';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CountryCode', 'CurrencyCode'], 'required'],
            [['CountryCode'], 'string', 'max' => 2],
            [['CurrencyCode'], 'string', 'max' => 3],
            [['CountryCode'], 'exist', 'skipOnError' => true, 'targetClass' => Countries::class, 'targetAttribute' => ['CountryID' => 'CountryID']],
            [['CurrencyCode'], 'exist', 'skipOnError' => true, 'targetClass' => Currencies::class, 'targetAttribute' => ['CurrencyCode' => 'CurrencyCode']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'CountryCode' => 'Country Code',
            'CurrencyCode' => 'Currency Code',
        ];
    }

    /**
     * Gets query for [[CountryCode]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCountryCode()
    {
        return $this->hasOne(Countries::class, ['CountryID' => 'CountryID']);
    }

    /**
     * Gets query for [[CountryCode]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(Countries::class, ['CountryID' => 'CountryID']);
    }

    /**
     * Gets query for [[CurrencyCode]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCurrencyCode()
    {
        return $this->hasOne(Currencies::class, ['CurrencyCode' => 'CurrencyCode']);
    }
}
