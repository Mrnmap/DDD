<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "DeliveryTime".
 *
 * @property int $Id
 * @property int $CountryId
 * @property string $CurrencyCode
 * @property int $DeliveryMethodId
 * @property string $Estimation
 */
class DeliveryTime extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'DeliveryTime';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CountryId', 'CurrencyCode', 'DeliveryMethodId', 'Estimation'], 'required'],
            [['CountryId', 'DeliveryMethodId'], 'integer'],
            [['CurrencyCode'], 'string', 'max' => 10],
            [['Estimation'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'CountryId' => 'Country ID',
            'CurrencyCode' => 'Currency Code',
            'DeliveryMethodId' => 'Delivery Method ID',
            'Estimation' => 'Estimation',
        ];
    }

}
