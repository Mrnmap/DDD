<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "PartnersTransaction".
 *
 * @property int $PartnersTransactionID
 * @property int $TransactionID
 * @property int $PartnerID
 * @property string $PartnerTransactionReference
 * @property string $Status
 * @property string $RawRequestJson
 * @property string $RawResponseJson
 * @property string $PayloadChecksum SHA256
 * @property string|null $LastEventAt
 * @property string $CreatedAt
 * @property string $UpdatedAt
 */
class PartnersTransaction extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'PartnersTransaction';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['LastEventAt'], 'default', 'value' => null],
            [['UpdatedAt'], 'default', 'value' => null],
            [['PartnerTransactionReference'], 'default', 'value' => null],
            [['TransactionID', 'PartnerID', 'Status'], 'required'],
            [['TransactionID', 'PartnerID'], 'integer'],
            [['RawRequestJson', 'RawResponseJson', 'LastEventAt', 'CreatedAt', 'UpdatedAt'], 'safe'],
            [['PartnerTransactionReference', 'PayloadChecksum'], 'string', 'max' => 100],
            [['Status'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'PartnersTransactionID' => 'Partners Transaction ID',
            'TransactionID' => 'Transaction ID',
            'PartnerID' => 'Partner ID',
            'PartnerTransactionReference' => 'Partner Transaction Reference',
            'Status' => 'Status',
            'RawRequestJson' => 'Raw Request Json',
            'RawResponseJson' => 'Raw Response Json',
            'PayloadChecksum' => 'Payload Checksum',
            'LastEventAt' => 'Last Event At',
            'CreatedAt' => 'Created At',
            'UpdatedAt' => 'Updated At',
        ];
    }
}
