<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Customers".
 *
 * @property int $CustomerID
 * @property int $UserID
 * @property string $CountryCode
 * @property string $MobileNo
 * @property string $Nationality
 * @property int|null $Occupation
 * @property int|null $SourceOfFund
 * @property string|null $DOB
 * @property string|null $Address
 * @property int|null $StateID
 * @property int|null $CityID
 * @property int|null $IDType
 * @property string|null $IDNo
 * @property string|null $DocExpiry
 * @property int $IsDelete
 * @property string $OnDate
 * @property string $UpdatedDate
 * @property string|null $Status
 * @property string|null $ScreeningResult
 * @property string|null $SceeningReference
 * @property string|null $LastSceeningAt
 */
class Customers extends \yii\db\ActiveRecord
{
    /**
     * ENUM field values
     */
    const STATUS_ACTIVATED = 'activated';
    const STATUS_BLOCKED = 'blocked';
    const STATUS_UNDER_REVIEW = 'under review';
    const STATUS = '';


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Customers';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Occupation', 'DOB', 'Address', 'StateID', 'CityID', 'IDType', 'IDNo', 'DocExpiry', 'SourceOfFund', 'Status', 'ScreeningResult', 'SceeningReference', 'LastSceeningAt'], 'default', 'value' => null],
            [['UserID', 'CountryCode', 'MobileNo', 'Nationality', 'IsDelete', 'OnDate'], 'required'],
            [['UserID', 'Occupation', 'StateID', 'CityID', 'IDType', 'IsDelete', "SourceOfFund"], 'integer'],
            [['DOB', 'DocExpiry', 'OnDate', 'UpdatedDate', 'LastSceeningAt'], 'safe'],
            [['Status'], 'string'],
            [['ScreeningResult', 'SceeningReference'], 'string', 'max' => 100],
            ['Status', 'in', 'range' => array_keys(self::optsStatus())],
            [['CountryCode', 'Nationality'], 'string', 'max' => 11],
            [['MobileNo'], 'string', 'max' => 20],
            [['Address'], 'string', 'max' => 150],
            [['IDNo'], 'string', 'max' => 50],
            [['MobileNo'], 'unique'],
            ['CityID', 'exist', 'targetClass' => Cities::class, 'targetAttribute' => ['CityID' => 'CityID'], 'message' => 'Invalid City ID'],
            ['SourceOfFund', 'exist', 'targetClass' => SourceOfFund::class, 'targetAttribute' => ['SourceOfFund' => 'SourceID'], 'message' => 'Invalid Source Of Fund ID'],
            ['Occupation', 'exist', 'targetClass' => Occupation::class, 'targetAttribute' => ['Occupation' => 'OccupationID'], 'message' => 'Invalid Occupation ID'],
            ['StateID', 'exist', 'targetClass' => States::class, 'targetAttribute' => ['StateID' => 'StateID'], 'message' => 'Invalid State ID'],
            ['IDType', 'exist', 'targetClass' => IDTypes::class, 'targetAttribute' => ['IDType' => 'IDTypeID'], 'message' => 'Invalid ID Type'],
            ['Nationality', 'exist', 'targetClass' => Countries::class, 'targetAttribute' => ['Nationality' => 'CountryID'], 'message' => 'Invalid Nationality'],
            [
                'CityID',
                'exist',
                'targetClass' => Cities::class,
                'targetAttribute' => ['CityID' => 'CityID'],
                'filter' => function ($query) {
                    // Only accept the City when it belongs to the selected State
                    if ($this->StateID !== null) {
                        $query->andWhere(['StateID' => (int)$this->StateID]);
                    } else {
                        // Force a miss if StateID is missing but CityID provided
                        $query->andWhere('1=0');
                    }
                },
                'message' => 'City does not belong to the selected State.',
            ],
            [
                ['IDNo'],
                'unique',
                'message' => 'This ID number is already registered in the system.',
            ],

        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'CustomerID' => 'Customer ID',
            'UserID' => 'User ID',
            'CountryCode' => 'Country Code',
            'MobileNo' => 'Mobile No',
            'Nationality' => 'Nationality',
            'Occupation' => 'Occupation',
            'SourceOfFund' => 'Source Of Fund',
            'DOB' => 'Dob',
            'Address' => 'Address',
            'StateID' => 'State ID',
            'CityID' => 'City ID',
            'IDType' => 'Id Type',
            'IDNo' => 'Id No',
            'DocExpiry' => 'Doc Expiry',
            'IsDelete' => 'Is Delete',
            'OnDate' => 'On Date',
            'UpdatedDate' => 'Updated Date',
            'Status' => 'Status',
            'ScreeningResult' => 'Screening Result',
            'SceeningReference' => 'Sceening Reference',
            'LastSceeningAt' => 'Last Sceening At',
        ];
    }

    /**
     * column Status ENUM value labels
     * @return string[]
     */
    public static function optsStatus()
    {
        return [
            self::STATUS_ACTIVATED => 'activated',
            self::STATUS_BLOCKED => 'blocked',
            self::STATUS_UNDER_REVIEW => 'under review',
            self::STATUS => '',
        ];
    }

    /**
     * @return string
     */
    public function displayStatus()
    {
        return self::optsStatus()[$this->Status] ?? '';
    }

    /**
     * @return bool
     */
    public function isStatusActivated()
    {
        return $this->Status === self::STATUS_ACTIVATED;
    }

    public function setStatusToActivated()
    {
        $this->Status = self::STATUS_ACTIVATED;
    }

    /**
     * @return bool
     */
    public function isStatusBlocked()
    {
        return $this->Status === self::STATUS_BLOCKED;
    }

    public function setStatusToBlocked()
    {
        $this->Status = self::STATUS_BLOCKED;
    }

    /**
     * @return bool
     */
    public function isStatusUnderReview()
    {
        return $this->Status === self::STATUS_UNDER_REVIEW;
    }

    public function setStatusToUnderReview()
    {
        $this->Status = self::STATUS_UNDER_REVIEW;
    }


    /**
     * Gets query for [[States]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getState()
    {
        return $this->hasOne(States::class, ['StateID' => 'StateID']);
    }
    /**
     * Gets query for [[States]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCity()
    {
        return $this->hasOne(Cities::class, ['CityID' => 'CityID']);
    }
    /**
     * Gets query for [[Countries]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(Countries::class, ['CountryCode' => 'CountryCode']);
    }

    /**
     * Gets query for [[Countries]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNationality()
    {
        return $this->hasOne(Countries::class, ['CountryID' => 'Nationality']);
    }

    /**
     * Gets query for [[IDTypes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getIdType()
    {
        return $this->hasOne(IDTypes::class, ['IDTypeID' => 'IDType']);
    }
    /**
     * Gets query for [[IDTypes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getOccupation()
    {
        return $this->hasOne(Occupation::class, ['OccupationID' => 'Occupation']);
    }

    /**
     * Gets query for [[IDTypes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSourceOfFund()
    {
        return $this->hasOne(SourceOfFund::class, ['SourceID' => 'SourceOfFund']);
    }

    /**
     * Gets query for [[Users]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::class, ['UserID' => 'UserID']);
    }
}
