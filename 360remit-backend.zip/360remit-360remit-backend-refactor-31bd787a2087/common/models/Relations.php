<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Relations".
 *
 * @property int $RelationID
 * @property string $RelationName
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 */
class Relations extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Relations';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['RelationName', 'IsDelete', 'CreateUID', 'OnDate', 'UpdateUID'], 'required'],
            [['IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['RelationName'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'RelationID' => 'Relation ID',
            'RelationName' => 'Relation Name',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }

}
