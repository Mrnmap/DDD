<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Currencies".
 *
 * @property string $Name
 * @property string $CurrencyCode
 * @property string $Symbol
 * @property int $DecimalDigits
 * @property string $SymbolNative
 * @property int $Rounding
 * @property string $NamePlural
 * @property int $IsDelete
 * @property int $CreateUId
 * @property string $OnDate
 * @property int $UpdateUId
 * @property string $UpdatedDate
 *
 * @property CountryCurrencies[] $countryCurrencies
 */
class Currencies extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Currencies';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Name', 'CurrencyCode', 'Symbol', 'DecimalDigits', 'SymbolNative', 'Rounding', 'NamePlural', 'IsDelete', 'CreateUId', 'OnDate', 'UpdateUId'], 'required'],
            [['DecimalDigits', 'Rounding', 'IsDelete', 'CreateUId', 'UpdateUId'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['Name', 'NamePlural'], 'string', 'max' => 50],
            [['CurrencyCode'], 'string', 'max' => 3],
            [['Symbol'], 'string', 'max' => 4],
            [['SymbolNative'], 'string', 'max' => 10],
            [['CurrencyCode'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Name' => 'Name',
            'CurrencyCode' => 'Currency Code',
            'Symbol' => 'Symbol',
            'DecimalDigits' => 'Decimal Digits',
            'SymbolNative' => 'Symbol Native',
            'Rounding' => 'Rounding',
            'NamePlural' => 'Name Plural',
            'IsDelete' => 'Is Delete',
            'CreateUId' => 'Create U ID',
            'OnDate' => 'On Date',
            'UpdateUId' => 'Update U ID',
            'UpdatedDate' => 'Updated Date',
        ];
    }

    /**
     * Gets query for [[CountryCurrencies]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCountryCurrencies()
    {
        return $this->hasMany(CountryCurrencies::class, ['CurrencyCode' => 'CurrencyCode']);
    }

}
