<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Cities".
 *
 * @property int $CityID
 * @property string $MCCityId
 * @property int $StateID
 * @property string $CityName
 * @property int $CountryID
 * @property int $IsDelete
 * @property int $CreateUID
 * @property string $OnDate
 * @property int $UpdateUID
 * @property string $UpdatedDate
 */
class Cities extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Cities';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['MCCityId', 'StateID', 'CityName', 'CountryID', 'IsDelete', 'CreateUID', 'OnDate', 'UpdateUID'], 'required'],
            [['StateID', 'CountryID', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
            [['MCCityId'], 'string', 'max' => 50],
            [['CityName'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'CityID' => 'City ID',
            'MCCityId' => 'Mc City ID',
            'StateID' => 'State ID',
            'CityName' => 'City Name',
            'CountryID' => 'Country ID',
            'IsDelete' => 'Is Delete',
            'CreateUID' => 'Create Uid',
            'OnDate' => 'On Date',
            'UpdateUID' => 'Update Uid',
            'UpdatedDate' => 'Updated Date',
        ];
    }

    /**
     * Gets query for [[States]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getState()
    {
        return $this->hasOne(States::class, ['StateID' => 'StateID']);
    }

    /**
     * Gets query for [[Countries]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getcountry()
    {
        return $this->hasOne(Countries::class, ['CountryID' => 'CountryID']);
    }
}
