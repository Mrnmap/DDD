<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "TransactionDetails".
 *
 * @property int $Id
 * @property int $TransactionID
 * @property int $SendingCountryId
 * @property string $SendingCurrencyCode
 * @property int $ReceivingCountryId
 * @property string $ReceivingCurrencyCode
 * @property int $DeliveryMethodId
 * @property float $SendingAmount (OMR)
 * @property float $ReceivedAmount
 * @property float $CustomerExchangeRate
 * @property float $CustomerFee
 * @property float $VatAmount
 * @property float $TotalFees
 * @property float $CollectedAmount (OMR)
 * @property float $PartnerFee
 * @property float $BaseExchangeRate
 * @property float $BaseReceivedAmount
 * @property float $FxMarkupPercent
 * @property float $FxMarkupAmount (OMR)
 */
class TransactionDetails extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'TransactionDetails';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['TransactionID', 'SendingCountryId', 'SendingCurrencyCode', 'ReceivingCountryId', 'ReceivingCurrencyCode', 'DeliveryMethodId', 'SendingAmount', 'ReceivedAmount', 'CustomerExchangeRate', 'CustomerFee', 'VatAmount', 'TotalFees', 'CollectedAmount', 'PartnerFee', 'BaseExchangeRate', 'BaseReceivedAmount', 'FxMarkupPercent', 'FxMarkupAmount'], 'required'],
            [['Id', 'TransactionID', 'SendingCountryId', 'ReceivingCountryId', 'DeliveryMethodId'], 'integer'],
            [['SendingAmount', 'ReceivedAmount', 'CustomerExchangeRate', 'CustomerFee', 'VatAmount', 'TotalFees', 'CollectedAmount', 'PartnerFee', 'BaseExchangeRate', 'BaseReceivedAmount', 'FxMarkupPercent', 'FxMarkupAmount'], 'number'],
            [['SendingCurrencyCode', 'ReceivingCurrencyCode'], 'string', 'max' => 3],
            [['Id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'TransactionID' => 'Transaction ID',
            'SendingCountryId' => 'Sending Country ID',
            'SendingCurrencyCode' => 'Sending Currency Code',
            'ReceivingCountryId' => 'Receiving Country ID',
            'ReceivingCurrencyCode' => 'Receiving Currency Code',
            'DeliveryMethodId' => 'Delivery Method ID',
            'SendingAmount' => 'Sending Amount',
            'ReceivedAmount' => 'Received Amount',
            'CustomerExchangeRate' => 'Customer Exchange Rate',
            'CustomerFee' => 'Customer Fee',
            'VatAmount' => 'Vat Amount',
            'TotalFees' => 'Total Fees',
            'CollectedAmount' => 'Collected Amount',
            'PartnerFee' => 'Partner Fee',
            'BaseExchangeRate' => 'Base Exchange Rate',
            'BaseReceivedAmount' => 'Base Received Amount',
            'FxMarkupPercent' => 'Fx Markup Percent',
            'FxMarkupAmount' => 'Fx Markup Amount'
        ];
    }
}
