<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "TransactionCompliance".
 *
 * @property int $Id
 * @property int $TransactionId
 * @property string|null $FlagType
 * @property string|null $Status
 * @property string|null $ReasonText
 * @property string $CreatedAt
 * @property string|null $ClearedAt
 * @property int|null $ClearedBy
 */
class TransactionCompliance extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const FLAGTYPE_AML = 'AML';
    const FLAGTYPE_KYC = 'KYC';
    const FLAGTYPE_SANCTIONS = 'sanctions';
    const FLAGTYPE_MANUAL_REVIEW = 'manual review';
    const STATUS_CLEARED = 'cleared';
    const STATUS_BLOCKED = 'blocked';
    const STATUS_UNDER_REVIEW = 'under review';
    const STATUS = '';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'TransactionCompliance';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['FlagType', 'Status', 'ReasonText', 'ClearedAt', 'ClearedBy'], 'default', 'value' => null],
            [['TransactionId'], 'required'],
            [['Id', 'TransactionId', 'ClearedBy'], 'integer'],
            [['FlagType', 'Status'], 'string'],
            [['CreatedAt', 'ClearedAt'], 'safe'],
            [['ReasonText'], 'string', 'max' => 100],
            ['FlagType', 'in', 'range' => array_keys(self::optsFlagType())],
            ['Status', 'in', 'range' => array_keys(self::optsStatus())],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'TransactionId' => 'Transaction ID',
            'FlagType' => 'Flag Type',
            'Status' => 'Status',
            'ReasonText' => 'Reason Text',
            'CreatedAt' => 'Created At',
            'ClearedAt' => 'Cleared At',
            'ClearedBy' => 'Cleared By',
        ];
    }


    /**
     * column FlagType ENUM value labels
     * @return string[]
     */
    public static function optsFlagType()
    {
        return [
            self::FLAGTYPE_AML => 'AML',
            self::FLAGTYPE_KYC => 'KYC',
            self::FLAGTYPE_SANCTIONS => 'sanctions',
            self::FLAGTYPE_MANUAL_REVIEW => 'manual review',
        ];
    }

    /**
     * column Status ENUM value labels
     * @return string[]
     */
    public static function optsStatus()
    {
        return [
            self::STATUS_CLEARED => 'cleared',
            self::STATUS_BLOCKED => 'blocked',
            self::STATUS_UNDER_REVIEW => 'manual review',
            self::STATUS => '',
        ];
    }

    /**
     * @return string
     */
    public function displayFlagType()
    {
        return self::optsFlagType()[$this->FlagType];
    }

    /**
     * @return bool
     */
    public function isFlagTypeAml()
    {
        return $this->FlagType === self::FLAGTYPE_AML;
    }

    public function setFlagTypeToAml()
    {
        $this->FlagType = self::FLAGTYPE_AML;
    }

    /**
     * @return bool
     */
    public function isFlagTypeKyc()
    {
        return $this->FlagType === self::FLAGTYPE_KYC;
    }

    public function setFlagTypeToKyc()
    {
        $this->FlagType = self::FLAGTYPE_KYC;
    }

    /**
     * @return bool
     */
    public function isFlagTypeSanctions()
    {
        return $this->FlagType === self::FLAGTYPE_SANCTIONS;
    }

    public function setFlagTypeToSanctions()
    {
        $this->FlagType = self::FLAGTYPE_SANCTIONS;
    }

    /**
     * @return bool
     */
    public function isFlagTypeManualReview()
    {
        return $this->FlagType === self::FLAGTYPE_MANUAL_REVIEW;
    }

    public function setFlagTypeToManualReview()
    {
        $this->FlagType = self::FLAGTYPE_MANUAL_REVIEW;
    }

    /**
     * @return string
     */
    public function displayStatus()
    {
        return self::optsStatus()[$this->Status];
    }

    /**
     * @return bool
     */
    public function isStatusCleared()
    {
        return $this->Status === self::STATUS_CLEARED;
    }

    public function setStatusToCleared()
    {
        $this->Status = self::STATUS_CLEARED;
    }

    /**
     * @return bool
     */
    public function isStatusBlocked()
    {
        return $this->Status === self::STATUS_BLOCKED;
    }

    public function setStatusToBlocked()
    {
        $this->Status = self::STATUS_BLOCKED;
    }

    /**
     * @return bool
     */
    public function isStatusUnderReview()
    {
        return $this->Status === self::STATUS_UNDER_REVIEW;
    }

    public function setStatusToManualReview()
    {
        $this->Status = self::STATUS_UNDER_REVIEW;
    }

    /**
     * @return bool
     */
    public function isStatus()
    {
        return $this->Status === self::STATUS;
    }

    public function setStatusTo()
    {
        $this->Status = self::STATUS;
    }
}
