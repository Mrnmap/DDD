<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "OtpSessions".
 *
 * @property int $Id
 * @property string $Phone
 * @property string $OtpCodeHash
 * @property string|null $CreatedAt
 * @property string|null $ExpiresAt
 * @property int $AttemptsRemaining
 * @property string $Status
 * @property int $IsDelivered
 * @property int|null $UndeliveredCount
 * @property string|null $DeliveredAt
 * @property string|null $LastErrorAt
 * @property string|null $LastDeliveryError
 */
class OtpSessions extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const STATUS_PENDING = 'pending';
    const STATUS_EXPIRED = 'expired';
    const STATUS_VERIFIED = 'verified';
    const STATUS_FAILED = 'failed';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'OtpSessions';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CreatedAt', 'ExpiresAt', 'UndeliveredCount', 'DeliveredAt', 'LastDeliveryError'], 'default', 'value' => null],
            [['Phone', 'OtpCodeHash', 'AttemptsRemaining', 'Status', 'IsDelivered'], 'required'],
            [['CreatedAt', 'ExpiresAt', 'DeliveredAt', 'LastErrorAt'], 'safe'],
            [['AttemptsRemaining', 'IsDelivered', 'UndeliveredCount'], 'integer'],
            [['Status'], 'string'],
            [['Phone', 'OtpCodeHash'], 'string', 'max' => 100],
            [['LastDeliveryError'], 'string', 'max' => 200],
            ['Status', 'in', 'range' => array_keys(self::optsStatus())],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'Phone' => 'Phone',
            'OtpCodeHash' => 'Otp Code Hash',
            'CreatedAt' => 'Created At',
            'ExpiresAt' => 'Expires At',
            'AttemptsRemaining' => 'Attempts Remaining',
            'Status' => 'Status',
            'IsDelivered' => 'Is Delivered',
            'UndeliveredCount' => 'Undelivered Count',
            'DeliveredAt' => 'Delivered At',
            'LastErrorAt' => 'Last Error At',
            'LastDeliveryError' => 'Last Delivery Error',
        ];
    }


    /**
     * column Status ENUM value labels
     * @return string[]
     */
    public static function optsStatus()
    {
        return [
            self::STATUS_PENDING => 'pending',
            self::STATUS_EXPIRED => 'expired',
            self::STATUS_VERIFIED => 'verified',
            self::STATUS_FAILED => 'failed',
        ];
    }

    /**
     * @return string
     */
    public function displayStatus()
    {
        return self::optsStatus()[$this->Status];
    }

    /**
     * @return bool
     */
    public function isStatusPending()
    {
        return $this->Status === self::STATUS_PENDING;
    }

    public function setStatusToPending()
    {
        $this->Status = self::STATUS_PENDING;
    }

    /**
     * @return bool
     */
    public function isStatusExpired()
    {
        return $this->Status === self::STATUS_EXPIRED;
    }

    public function setStatusToExpired()
    {
        $this->Status = self::STATUS_EXPIRED;
    }

    /**
     * @return bool
     */
    public function isStatusVerified()
    {
        return $this->Status === self::STATUS_VERIFIED;
    }

    public function setStatusToVerified()
    {
        $this->Status = self::STATUS_VERIFIED;
    }

    /**
     * @return bool
     */
    public function isStatusFailed()
    {
        return $this->Status === self::STATUS_FAILED;
    }

    public function setStatusToFailed()
    {
        $this->Status = self::STATUS_FAILED;
    }
}
