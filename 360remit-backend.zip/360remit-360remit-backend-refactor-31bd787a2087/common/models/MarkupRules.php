<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "MarkupRules".
 *
 * @property int $Id
 * @property int $CountryId
 * @property string $CurrencyCode
 * @property int $DeliveryMethodId
 * @property float $MarkupValuePercent
 * @property string $CreatedAt
 */
class MarkupRules extends \yii\db\ActiveRecord
{


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'MarkupRules';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CountryId', 'CurrencyCode', 'DeliveryMethodId', 'MarkupValuePercent'], 'required'],
            [['CountryId', 'DeliveryMethodId'], 'integer'],
            [['MarkupValuePercent'], 'number'],
            [['CreatedAt'], 'safe'],
            [['CurrencyCode'], 'string', 'max' => 10],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'CountryId' => 'Country ID',
            'CurrencyCode' => 'Currency Code',
            'DeliveryMethodId' => 'Delivery Method ID',
            'MarkupValuePercent' => 'Markup Value Percent',
            'CreatedAt' => 'Created At',
        ];
    }
    public function getCountry()
    {
        return $this->hasOne(Countries::class, ['CountryId' => 'CountryID']);
    }
}
