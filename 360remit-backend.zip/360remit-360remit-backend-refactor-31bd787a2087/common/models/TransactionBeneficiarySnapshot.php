<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "transaction_beneficiary_snapshot".
 *
 * @property int $id
 * @property int $transaction_id
 * @property int $beneficiary_id
 * @property string|null $first_name_at_time
 * @property string|null $last_name_at_time
 * @property string|null $phone_at_time
 * @property string|null $address_at_time
 * @property string|null $bank_account_number
 * @property string|null $bank_name
 * @property string|null $bank_branch_code
 * @property string|null $mobile_wallet_number
 * @property string|null $pickup_location
 * @property string|null $pickup_reference
 * @property string $snapshot_created_at
 *
 * @property Transactions $transaction
 * @property Beneficiaries $beneficiary
 */
class TransactionBeneficiarySnapshot extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'transaction_beneficiary_snapshot';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['transaction_id', 'beneficiary_id'], 'required'],
            [['transaction_id', 'beneficiary_id'], 'integer'],
            [['snapshot_created_at'], 'safe'],
            [['first_name_at_time', 'last_name_at_time'], 'string', 'max' => 100],
            [['phone_at_time'], 'string', 'max' => 15],
            [['address_at_time'], 'string', 'max' => 255],
            [['bank_account_number'], 'string', 'max' => 60],
            [['bank_name'], 'string', 'max' => 100],
            [['bank_branch_code'], 'string', 'max' => 50],
            [['mobile_wallet_number'], 'string', 'max' => 20],
            [['pickup_location'], 'string', 'max' => 255],
            [['pickup_reference'], 'string', 'max' => 100],
            [['transaction_id'], 'exist', 'skipOnError' => true, 'targetClass' => Transactions::class, 'targetAttribute' => ['transaction_id' => 'TransactionID']],
            [['beneficiary_id'], 'exist', 'skipOnError' => true, 'targetClass' => Beneficiaries::class, 'targetAttribute' => ['beneficiary_id' => 'BeneficiaryID']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'transaction_id' => 'Transaction ID',
            'beneficiary_id' => 'Beneficiary ID',
            'first_name_at_time' => 'First Name At Time',
            'last_name_at_time' => 'Last Name At Time',
            'phone_at_time' => 'Phone At Time',
            'address_at_time' => 'Address At Time',
            'bank_account_number' => 'Bank Account Number',
            'bank_name' => 'Bank Name',
            'bank_branch_code' => 'Bank Branch Code',
            'mobile_wallet_number' => 'Mobile Wallet Number',
            'pickup_location' => 'Pickup Location',
            'pickup_reference' => 'Pickup Reference',
            'snapshot_created_at' => 'Snapshot Created At',
        ];
    }

    /**
     * Gets query for [[Transaction]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransaction()
    {
        return $this->hasOne(Transactions::class, ['TransactionID' => 'transaction_id']);
    }

    /**
     * Gets query for [[Beneficiary]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBeneficiary()
    {
        return $this->hasOne(Beneficiaries::class, ['BeneficiaryID' => 'beneficiary_id']);
    }
}


