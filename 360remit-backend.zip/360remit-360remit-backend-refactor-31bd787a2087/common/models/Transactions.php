<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Transactions".
 *
 * @property int $TransactionID
 * @property int $UserID
 * @property int $OrginalTransactionId
 * @property int $BeneficiaryId
 * @property string $Direction
 * @property int $CurrentStatus
 * @property string|null $CreatedAt
 * @property string $SubmittedAt when transaction funds are captured and in process to be released
 * @property string $UpdatedAt
 *
 * @property TransactionLogs[] $transactionLogs
 */
class Transactions extends \yii\db\ActiveRecord
{

    /**
     * ENUM field values
     */
    const DIRECTION_CREDIT = 'credit';
    const DIRECTION_DEBIT = 'debit';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Transactions';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CreatedAt'], 'default', 'value' => null],
            [['SubmittedAt'], 'default', 'value' => null],
            [['OrginalTransactionId'], 'default', 'value' => null],
            [['UpdatedAt'], 'default', 'value' => '0000-00-00 00:00:00.000000'],
            [['UserID', 'BeneficiaryId', 'Direction', 'CurrentStatus'], 'required'],
            [['UserID', 'OrginalTransactionId', 'BeneficiaryId', 'CurrentStatus'], 'integer'],
            [['Direction'], 'string'],
            [['CreatedAt', 'UpdatedAt'], 'safe'],
            ['Direction', 'in', 'range' => array_keys(self::optsDirection())],
            [
                'BeneficiaryId',
                'exist',
                'targetClass' => Beneficiaries::class,
                'targetAttribute' => ['BeneficiaryId' => 'BeneficiaryId'],
                'filter' => function ($query) {
                    $query->andWhere(['UserID' => $this->UserID]);
                    $query->andWhere(['IsDelete' => 0]);
                },
                'message' => 'The selected beneficiary does not belong to this user.'
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'TransactionID' => 'Transaction ID',
            'UserID' => 'User ID',
            'OrginalTransactionId' => 'Orginal Transaction ID',
            'BeneficiaryId' => 'Beneficiary ID',
            'Direction' => 'Direction',
            'CurrentStatus' => 'Current Status',
            'CreatedAt' => 'Created At',
            'SubmittedAt' => 'Submitted At',
            'UpdatedAt' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[TransactionLogs]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransactionLogs()
    {
        return $this->hasMany(TransactionLogs::class, ['TransactionID' => 'TransactionID']);
    }


    /**
     * column Direction ENUM value labels
     * @return string[]
     */
    public static function optsDirection()
    {
        return [
            self::DIRECTION_CREDIT => 'credit',
            self::DIRECTION_DEBIT => 'debit',
        ];
    }

    /**
     * @return string
     */
    public function displayDirection()
    {
        return self::optsDirection()[$this->Direction];
    }

    /**
     * @return bool
     */
    public function isDirectionCredit()
    {
        return $this->Direction === self::DIRECTION_CREDIT;
    }

    public function setDirectionToCredit()
    {
        $this->Direction = self::DIRECTION_CREDIT;
    }

    /**
     * @return bool
     */
    public function isDirectionDebit()
    {
        return $this->Direction === self::DIRECTION_DEBIT;
    }

    public function setDirectionToDebit()
    {
        $this->Direction = self::DIRECTION_DEBIT;
    }

    /**
     * Gets query for [[TransactionDetails]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransactionDetails()
    {
        return $this->hasOne(TransactionDetails::class, ['TransactionID' => 'TransactionID']);
    }
    /**
     * Gets query for [[TransactionDetails]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBeneficiary()
    {
        return $this->hasOne(Beneficiaries::class, ['BeneficiaryID' => 'BeneficiaryId']);
    }

    /**
     * Gets query for [[TransactionStatus]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransactionStatus()
    {
        return $this->hasOne(TransactionStatus::class, ['Id' => 'CurrentStatus']);
    }
    /**
     * Gets query for [[PartnersTransaction]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPartnersTransaction()
    {
        return $this->hasOne(PartnersTransaction::class, ['TransactionID' => 'TransactionID']);
    }
    /**
     * Gets query for [[TransactionStatus]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransactionCompliance()
    {
        return $this->hasOne(TransactionCompliance::class, ['TransactionId' => 'TransactionID']);
    }
}
