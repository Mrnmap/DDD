<?php

namespace common\classes;

use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class PaymentGateway
{
    private $baseUrl;
    private $inquireUrl;
    private $client;
    private $timeout;

    public function __construct($config = [])
    {
        $this->baseUrl = $_ENV["OMANNET_BASE_URL"];
        $this->inquireUrl = $_ENV["OMANNET_INQUIRE_URL"];
        $this->timeout =  30;

        $this->client = new Client([
            'timeout' => $this->timeout,
            'verify' => false, // Set to true in production with proper SSL certificates
        ]);
    }

    /**
     * Create a new payment
     * 
     * 
     * @param array $paymentData Payment data including amount, trackId, etc.
     * @return array Response from payment gateway
     */
    public function createPayment(array $paymentData): array
    {
        try {
            $url = $this->baseUrl . '/HostedPaymentBuyHttpAPI.php';


            $formData = [
                'AMOUNT' => $paymentData['amount'] ?? '',
                'TRACKID' => $paymentData['trackId'] ?? '',
                'REQUESTTYPE' => $paymentData['requestType'] ?? 'payment',
                'ACTION' => $paymentData['action'] ?? '1'
            ];

            $response = $this->client->post($url, [
                'form_params' => $formData,
                'headers' => [
                    'Content-Type' => 'application/x-www-form-urlencoded',
                ]
            ]);

            $responseBody = $response->getBody()->getContents();
            $statusCode = $response->getStatusCode();

            return [
                'success' => true,
                'status_code' => $statusCode,
                'data' => $responseBody,
                'message' => 'Payment creation request sent successfully'
            ];
        } catch (RequestException $e) {
            return [
                'success' => false,
                'error' => 'Request failed: ' . $e->getMessage(),
                'status_code' => $e->getCode(),
                'data' => null
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => 'Unexpected error: ' . $e->getMessage(),
                'data' => null
            ];
        }
    }

    /**
     * Inquiry request for payment status
     * 
     * @param array $inquiryData Inquiry data including transactionId, amount, etc.
     * @return array Response from payment gateway
     */
    public function inquiryRequest(array $inquiryData): array
    {
        try {
            $url = $this->baseUrl . '/HostedPaymentBuyHttpAPIInquire.php/';


            $formData = [
                'ACTION' => $inquiryData['action'] ?? '8',
                'AMOUNT' => $inquiryData['amount'] ?? '',
                'TRANSACTIONID' => $inquiryData['transactionId'] ?? ''
            ];

            $response = $this->client->post($url, [
                'form_params' => $formData,
                'headers' => [
                    'Content-Type' => 'application/x-www-form-urlencoded',
                ]
            ]);

            $responseBody = $response->getBody()->getContents();
            $statusCode = $response->getStatusCode();

            return [
                'success' => true,
                'status_code' => $statusCode,
                'data' => $responseBody,
                'message' => 'Inquiry request sent successfully'
            ];
        } catch (RequestException $e) {
            return [
                'success' => false,
                'error' => 'Request failed: ' . $e->getMessage(),
                'status_code' => $e->getCode(),
                'data' => null
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => 'Unexpected error: ' . $e->getMessage(),
                'data' => null
            ];
        }
    }
    public function getSavedTrn($transactionId): array
    {
        try {;

            // Pass transaction ID as query parameter properly
            $response = $this->client->get($this->inquireUrl, [
                'query' => [
                    'trn' => $transactionId
                ],
                'headers' => [
                    'Accept' => 'application/json',
                ],
                'http_errors' => false // Prevent Guzzle from throwing exceptions on 4xx/5xx
            ]);

            $statusCode = $response->getStatusCode();
            $responseBody = $response->getBody()->getContents();

            return [
                'success' => $statusCode === 200,
                'status_code' => $statusCode,
                'data' => $responseBody,
                'message' => 'Inquiry request sent successfully'
            ];
        } catch (RequestException $e) {
            return [
                'success' => false,
                'error' => 'Request failed: ' . $e->getMessage(),
                'status_code' => $e->getCode(),
                'data' => $e->hasResponse() ? $e->getResponse()->getBody()->getContents() : null
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => 'Unexpected error: ' . $e->getMessage(),
                'data' => null
            ];
        }
    }
}
