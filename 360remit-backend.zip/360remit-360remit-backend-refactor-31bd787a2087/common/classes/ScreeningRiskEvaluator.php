<?php

namespace common\classes;

class ScreeningRiskEvaluator
{
    public const RISK_HIGH   = 'HIGH_RISK';
    public const RISK_MEDIUM = 'MEDIUM_RISK';
    public const RISK_LOW    = 'NOT_RISKY';

    /**
     * Entry point: give me the ScreeningResponse (already mapped by ScreeningMapper)
     * and I tell you the overall risk.
     */
    public static function evaluate(ScreeningResponse $resp): array
    {
        // 0) no records at all
        if (empty($resp->Records)) {
            return self::result(self::RISK_LOW, 'No records in response');
        }

        $actionableMatches = [];

        foreach ($resp->Records as $record) {
            // record without watchlist = not risky
            if (!$record->Watchlist || empty($record->Watchlist->Matches)) {
                continue;
            }

            foreach ($record->Watchlist->Matches as $match) {
                if (self::isActionableMatch($match, $record)) {
                    $actionableMatches[] = $match;
                }
            }
        }

        // 1) after cleaning: nothing left → not risky
        if (empty($actionableMatches)) {
            return self::result(self::RISK_LOW, 'All matches were false/accepted/non-actionable');
        }

        // 2) check high first
        foreach ($actionableMatches as $m) {
            if (self::isHighRiskMatch($m)) {
                return self::result(self::RISK_HIGH, 'High–risk watchlist match found', $m);
            }
        }

        // 3) then medium
        foreach ($actionableMatches as $m) {
            if (self::isMediumRiskMatch($m)) {
                return self::result(self::RISK_MEDIUM, 'Medium–strength match (needs review)', $m);
            }
        }

        // 4) otherwise low
        return self::result(self::RISK_LOW, 'Only weak / conflicting matches found');
    }

    /**
     * Remove things we don’t want to bother analysts with.
     */
    private static function isActionableMatch(WatchlistMatch $m, ?ScreeningRecord $record = null): bool
    {
        // system/auto false positives
        if ($m->AutoFalsePositive) {
            return false;
        }

        // user/analyst decided it was FP
        if ($m->FalsePositive) {
            return false;
        }

        // already on accept list (either on match or on record)
        if ($m->AddedToAcceptList) {
            return false;
        }

        // record-level accept
        if ($record !== null) {
            // whole record accepted
            if ($record->RecordDetails?->AddedToAcceptList) {
                return false;
            }
            if ($record->RecordDetails?->RecordState?->AddedToAcceptList) {
                return false;
            }

            // record-level match states (manual decisions in UI)
            $states = $record->RecordDetails?->RecordState?->MatchStates ?? [];
            foreach ($states as $st) {
                if ($st->MatchID === $m->ID) {
                    // depending on how LN names it in your env:
                    $t = strtolower((string)$st->Type);
                    if (in_array($t, ['falsepositive', 'false_positive', 'nomatch', 'cleared', 'accepted'])) {
                        return false; // analyst said “this is NOT them”
                    }
                }
            }
        }

        // otherwise keep it
        return true;
    }

    /**
     * Our “definitely bad” bucket.
     */
    private static function isHighRiskMatch(WatchlistMatch $m): bool
    {
        $conflicts = self::countConflicts($m);

        // 1) explicit true match from XG
        if ($m->TrueMatch) {
            return true;
        }

        // 2) OFAC / gateway indicators
        if ($m->GatewayOFACScreeningIndicatorMatch || $m->SecondaryOFACScreeningIndicatorMatch) {
            return true;
        }

        // 3) very strong name match AND no conflicts
        if (!is_null($m->EntityScore) && $m->EntityScore >= 90 && $conflicts === 0) {
            return true;
        }

        // 4) PEP + (adverse media OR enforcement)
        if (!empty($m->PEPs) && (!empty($m->AdverseMedias) || !empty($m->Enforcements))) {
            return true;
        }

        // 5) file looks like sanctions list (when LN gives type/name)
        if ($m->File && self::fileLooksLikeSanctions($m->File)) {
            // and it’s a reasonably strong match
            if (!is_null($m->EntityScore) && $m->EntityScore >= 80) {
                return true;
            }
        }

        return false;
    }

    /**
     * Our “maybe / needs human” bucket.
     */
    private static function isMediumRiskMatch(WatchlistMatch $m): bool
    {
        $score     = $m->EntityScore ?? 0;
        $conflicts = self::countConflicts($m);

        // score good but some conflicts -> human check
        if ($score >= 75 && $score < 90 && $conflicts <= 2) {
            return true;
        }

        // PEP alone → medium (unless already promoted to high above)
        if (!empty($m->PEPs)) {
            return true;
        }

        // Adverse media alone → medium
        if (!empty($m->AdverseMedias)) {
            return true;
        }

        return false;
    }

    private static function countConflicts(WatchlistMatch $m): int
    {
        if (!$m->Conflicts) {
            return 0;
        }

        $c = $m->Conflicts;
        $flags = [
            $c->AddressConflict,
            $c->CitizenshipConflict,
            $c->CountryConflict,
            $c->DOBConflict,
            $c->EntityTypeConflict,
            $c->GenderConflict,
            $c->IDConflict,
            $c->PhoneConflict,
        ];

        return count(array_filter($flags));
    }

    private static function fileLooksLikeSanctions(WatchlistFileInfo $f): bool
    {
        $hay = strtolower(trim(($f->Type ?? '') . ' ' . ($f->Name ?? '')));
        return str_contains($hay, 'ofac')
            || str_contains($hay, 'sanction')
            || str_contains($hay, 'consolidated')
            || str_contains($hay, 'eu ')
            || str_contains($hay, 'un ');
    }

    private static function result(string $level, string $reason, ?WatchlistMatch $match = null): array
    {
        // this structure is easy to log/json_encode
        return [
            'risk'   => $level,
            'reason' => $reason,
            'match'  => $match ? [
                'id'            => $match->ID,
                'entityName'    => $match->EntityName,
                'entityScore'   => $match->EntityScore,
                'fileName'      => $match->File?->Name,
                'hasPEP'        => !empty($match->PEPs),
                'hasAdverse'    => !empty($match->AdverseMedias),
                'hasEnforcement' => !empty($match->Enforcements),
                'conflicts'     => $match->Conflicts ? [
                    'address'     => $match->Conflicts->AddressConflict,
                    'country'     => $match->Conflicts->CountryConflict,
                    'dob'         => $match->Conflicts->DOBConflict,
                    'gender'      => $match->Conflicts->GenderConflict,
                ] : null,
            ] : null,
        ];
    }
}
