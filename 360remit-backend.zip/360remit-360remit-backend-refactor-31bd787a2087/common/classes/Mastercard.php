<?php

namespace common\classes;

use Yii;
use common\models\Beneficiaries;
use common\models\Countries;
use common\models\Users;
use common\models\Customers;
use common\models\TransferPurposes;
use common\models\BeneficiaryBankAccounts;
use Countable;
use Exception;
use common\classes\TransactionRequest;
use common\models\Transactions;
use common\services\TransactionsHandler;

class PartnerProcessor
{
    protected $url = "";
    protected $header = "";
    protected $responseCode = null;
    public function sendHTTPRequest($url, $data, $method, $header)
    {
        $options = [
            'http' => [
                'header' => $header,
                'method' => $method,
                'content' => $data,
                //'timeout' =>0.2, // this to sitmulate timeout error
                'ignore_errors' => true
            ],
        ];

        $context = stream_context_create($options);
        $response = @file_get_contents($url, false, $context);
        if (isset($http_response_header) && is_array($http_response_header)) {
            // Example: "HTTP/1.1 200 OK"
            $statusLine = $http_response_header[0];
            if (preg_match('{HTTP/\S+ (\d{3})}', $statusLine, $match)) {
                $this->responseCode = (int)$match[1];
            }
        }
        if ($response === false) {
            echo $response;
            return null;
        }
        return $response;
    }
}

class Mastercard extends PartnerProcessor
{
    function __construct($config = [])
    {



        $this->url = $_ENV["MC_BASE_URL"];
        $this->header = array(
            "Content-Type: application/json",
            "Authorization: " . $_ENV["MC_AUTHORIZATION"]
        );
    }

    function getCalculation(DeliveryMethod $deliveryMethod, $receiveCurrencyCode, $receiveCountryCode, $sourceCurrency, $sendingAmount, $payerId)
    {

        $paymentmodeid = $deliveryMethod->mastercard();
        $payerObj = [];
        if ($deliveryMethod == DeliveryMethod::BankDeposit) {
            $payerObj = ["BankId" => $payerId];
        } else if ($deliveryMethod == DeliveryMethod::CashPickup) {
            $payerObj = ["PayerId" => $payerId];
        }
        $params = [
            'receiveCurrencyIsoCode' =>  $receiveCurrencyCode,
            'receiverCountryIsoCode' => $receiveCountryCode,
            'sourceCurrencyIsoCode' => $sourceCurrency,
            'sentAmount' => $sendingAmount,
            // 'receiveAmount' => $data['receiveAmount'] ?? null,
            'paymentmodeid' => $paymentmodeid
        ];

        $params += $payerObj;
        $filtered = array_filter($params, function ($value) {
            return $value !== null && $value !== '';
        });

        $urlEncoded = http_build_query($filtered);

        $url = $this->url  . "transaction/TransactionInfo?" . $urlEncoded;
        $response = $this->sendHTTPRequest($url, "", "GET", $this->header);
        if ($response) {
            $response = json_decode($response, true);
            return $response;
        }
    }
    /**
     * to return the rates availabe in the destination country
     */
    function getAvailableExchangeRates($sourceCurrencyCode, $receiveCountryCode)
    {

        $params = [
            'SourceCurrencyIsoCode' => $sourceCurrencyCode,
            'ReceiveCountryIsoCode' => $receiveCountryCode,
        ];

        $filtered = array_filter($params, function ($value) {
            return $value !== null && $value !== '';
        });

        $urlEncoded = http_build_query($filtered);

        $url = $this->url  . "rates/countryrates?" . $urlEncoded;
        $response = $this->sendHTTPRequest($url, "", "GET", $this->header);
        if ($response) {
            $response = json_decode($response, true);
            if (isset($response["Rates"])) {
                return $response;
            }
        }

        return null;
    }

    function getBestExchangeRate($sourceCurrency, $receiveCountryCode, $receivigCurrencyCode, DeliveryMethod $deliveryMethod)
    {
        $exchangeRateArray = $this->getAvailableExchangeRates($sourceCurrency, $receiveCountryCode);
        if ($exchangeRateArray == null) {
            return null;
        }
        $deliveryMethodMC = $deliveryMethod->mastercard();
        $bestRate = [];
        foreach ($exchangeRateArray["Rates"] as $rate) {
            if ($rate["ModeOfPaymentId"] == $deliveryMethodMC && $rate["ReceiveCurrencyIsoCode"] == $receivigCurrencyCode) {
                if ($bestRate == []) {
                    $bestRate = $rate;
                } else if ((float)$bestRate["StartRate"] > (float)$rate["StartRate"]) {
                    $bestRate = $rate;
                }
            }
        }

        return $bestRate;
    }

    function validateTransaction($transactionId, $params)
    {
        // first build the transaction 
        $transaction = $this->buildTransaction($transactionId, $params);
        if (isset($transaction["ok"]) && $transaction["ok"] == false) {
            return $transaction;
        }
        // send the transaction information to mastercard to validate it and initiate
        $result = $this->sendTransaction($transaction);
        if ($result == null) {
            // retry in case network failure or null response
            $result = $this->getTransactionByRef($transactionId);
        }

        if (!empty($result['TfPin'])) {
            // save transaction in partner transaction
            $createTrnResult = TransactionsHandler::createOrUpdatePartnerTransaction($transactionId, $result['TfPin'], $result['StatusName'], $transaction, $result);
            return $createTrnResult;
        } else if (!empty($result['BusinessErrors'][0]['Message']) || !empty($result['DataValidationErrors'][0]['Message'])) {
            $createTrnResult = TransactionsHandler::createOrUpdatePartnerTransaction($transactionId, null, "failed", $transaction, $result);
            if (isset($createTrnResult["ok"])  && $createTrnResult["ok"] == false) {
                return $createTrnResult;
            }
            $trnMsg = (!empty($result['BusinessErrors'][0]['Message']) ? $result['BusinessErrors'][0]['Message'] : "") . " " . (!empty($result['DataValidationErrors'][0]['Message']) ? $result['DataValidationErrors'][0]['Message'] : "") . " " . (!empty($result['DataValidationErrors'][0]['FieldName']) ? $result['DataValidationErrors'][0]['FieldName'] : "");
            $trnError = "Transaction Failed - on MasterCard BusinessErrors";
            return self::fail($trnError, [$trnMsg]);
        } else {
            $createTrnResult = TransactionsHandler::createOrUpdatePartnerTransaction($transactionId, null, "failed", $transaction, $result);
            if (isset($createTrnResult["ok"]) && $createTrnResult["ok"] == false) {
                return $createTrnResult;
            }
            $trnError = "Transaction Failed - on MasterCard Response";
            $trnMsg = "Something went wrong while communicating with partner!";
            return self::fail($trnError, [$trnMsg]);
        }
    }

    public function buildTransaction($transactionId, $params)
    {
        $details = $params["transaction"];
        $user = Users::findOne(["UserID" => $params["userId"]]);
        $customer = Customers::findOne(["UserID" => $params["userId"]]);
        $beneficiary = Beneficiaries::findOne(["UserID" => $params["userId"], "BeneficiaryID" => $params["beneficiaryId"]]);
        $receivingCountry = Countries::findOne(["CountryID" => $details["receivingCountryId"]]);
        $sourceCountry = Countries::findOne(["CountryID" => $details["sourceCountryId"]]);
        $transferPurpose = TransferPurposes::findOne($details["transferPurpose"]);
        $deliveryMethod = DeliveryMethod::fromName($details["deliveryMethod"]);

        $beneficiaryFullAddress = "";
        $beneficiaryPhoneNumber = "";

        if ($user == null || $beneficiary == null) {
            return self::fail('Exception while validating transaction: ' . []);
        }
        $trn = new TransactionRequest();
        $senderFullName = implode(' ', array_filter([
            $user->Name ?? null,
            $user->MiddleName ?? null,
            $user->Surname ?? null,
        ]));
        $receiverFullName = implode(' ', array_filter([
            $beneficiary->FirstName ?? null,
            $beneficiary->MiddleName ?? null,
            $beneficiary->LastName ?? null,
        ]));
        $fullAddress = implode(' ', array_filter([
            $customer->Address ?? null,
            $customer->city->CityName ?? null,
            $customer->state->StateName ?? null,
            $customer->country->CountryName ?? null,
        ]));
        try {
            // sender info
            $trn->Sender->Name = (string)$senderFullName;
            $trn->Sender->Address = (string)$fullAddress;
            $trn->Sender->PhoneMobile = (string)$customer->MobileNo; // must have
            $trn->Sender->CountryIsoCode = (string)$customer->CountryCode;
            $trn->Sender->StateId = "OMA";
            $trn->Sender->CityId = (string)$customer->city->MCCityId;
            $trn->Sender->TypeOfId = (string)$customer->idType->MCIdTypeID;
            $trn->Sender->IdNumber = (string)$customer->IDNo;
            $trn->Sender->IdExpiryDate = (string)$customer->DocExpiry;
            $trn->Sender->DateOfBirth = (string)$customer->DOB;
            $trn->Sender->NationalityIsoCode = (string)$customer->nationality->CountryCode;

            // transaction info
            $trn->TransactionInfo->SourceCurrencyIsoCode = (string)$details["sourceCurrency"];
            $trn->TransactionInfo->PaymentModeId = (string)$deliveryMethod->mastercard();
            $trn->TransactionInfo->ReceiveCurrencyIsoCode = (string)$details["receivingCurrency"];
            $trn->TransactionInfo->ReceiveAmount = (string)$details["receivingAmount"];
            $trn->TransactionInfo->PurposeOfRemittanceId = (string)$details["transferPurpose"]; // TODO: check mastercard id
            $trn->TransactionInfo->FormOfPaymentId = "DC"; // Debit Card Payment
            $trn->TransactionInfo->ReferenceNumber = (string)$transactionId;
            // bank
            if ($deliveryMethod == DeliveryMethod::BankDeposit) {
                $bankAccount = BeneficiaryBankAccounts::findOne([
                    "UserId" => (int)$params["userId"],
                    "BeneficiaryId" => (int)$params["beneficiaryId"],
                    "BeneficiaryBankAccountId" => (int)$details["paymentProfileId"],
                    "CountryId" => (int)$details["receivingCountryId"],
                ]);
                $beneficiaryFullAddress = $bankAccount->Address;
                $beneficiaryPhoneNumber = $bankAccount->AccountPhone;

                $trn->TransactionInfo->BankId = (string)$bankAccount->branch->MCBankID;
                $trn->TransactionInfo->BankBranchId = (string)$bankAccount->branch->ID;

                // validate bank and bank branch with mastercard
                // this step from mastercard to validate if bank and brach are still valid
                if (!$this->isValidBank($receivingCountry->CountryCode, $trn->TransactionInfo->BankId, $trn->TransactionInfo->BankBranchId)) {
                    return self::fail('Mastercard: Bank and Branch are not valid!' . []);
                }

                if (array_key_exists($receivingCountry->CountryCode, ["BD", "PH", "IN"]) && $bankAccount->isBankingIdentifierAccount()) {
                    $trn->TransactionInfo->AccountNumber = (string)$bankAccount->AccountNumber;
                } else if (!array_key_exists($receivingCountry->CountryCode, ["BD", "PH", "IN"]) && ($bankAccount->isBankingIdentifierIban() || $bankAccount->isBankingIdentifierAccount())) {
                    //TODO LATER: breaking point. what if the account number from bank account must be as AccountNumber for Mastercard
                    $trn->TransactionInfo->Account = (string)$bankAccount->AccountNumber;
                } else {
                    return self::fail('Bank account format is not correct!', ["banking reference set to worng format: account / iban"]);
                }
            } else {
                // TODO LATER: when developing cash pickup points
                $trn->TransactionInfo->PayerId = "";
            }


            // beneficiary info
            $trn->Receiver->FirstName = (string)$beneficiary->FirstName;
            $trn->Receiver->SecondName = (string)$beneficiary->MiddleName ?? "";
            $trn->Receiver->LastName = (string)$beneficiary->LastName ?? "";
            $trn->Receiver->CompleteAddress = $beneficiaryFullAddress;
            $trn->Receiver->MobilePhone = $beneficiaryPhoneNumber;
            $trn->Receiver->CountryIsoCode = (string)$receivingCountry->CountryCode;
            $trn->Receiver->NationalityIsoCode = (string)$beneficiary->nationality->CountryCode;
            $trn->Receiver->IsIndividual = "true";



            $trn->Compliance->CountryIssueIsoCode = $sourceCountry->CountryCode;
            $trn->Compliance->SourceOfFunds = $customer->SourceOfFund; // TODO: get from user info
            $trn->Compliance->ReceiverFullName = $receiverFullName;
        } catch (Exception $e) {
            return self::fail('Mastercard Transaction Body: ' . $e->getMessage());
        }
        $trn = $this->filterNulls($trn);
        return json_encode($trn);
    }

    public function sendTransaction($transaction)
    {
        // log before sending
        Yii::info(json_encode($transaction), 'sent_requests_to_mastercard');

        if ($transaction != null) {
            // Send the HTTP rquest
            $response = $this->sendHTTPRequest($this->url . 'transaction/invoice', $transaction, "POST", $this->header);
            $response = json_decode($response, true);
            // log after sending
            Yii::info(json_encode($response), 'mastercard_respond');
            return $response;
        }

        return null;
    }

    public function cancelTransaction($transactionId, $reason)
    {
        // reason = "user", "system"
        $transaction = Transactions::findOne(["TransactionID" => $transactionId]);

        if ($transaction == null) {
            return [
                "sucess" => true,
                "data" => "transaction id not found"
            ];
        }
        $tfPin = $transaction->partnersTransaction->PartnerTransactionReference ?? null;

        if ($tfPin == null) {
            return [
                "sucess" => true,
                "data" => "partner refernece not found"
            ];
        }
        $errorCode = "";
        if ($reason == "user") {
            $errorCode = "116"; //CLIENT DID NOT PAY -- canceled by user
        } else if ($reason == "system") {
            $errorCode = "106"; //system issue
        }
        $body = array(
            "TfPin" => $tfPin,
            "ReasonId" => $errorCode ?? "116"
        );
        Yii::info(json_encode($body), 'sent_requests_to_mastercard');
        if ($transaction != null) {
            // Send the HTTP rquest
            $response = $this->sendHTTPRequest($this->url . 'transaction/cancel', json_encode($body), "PUT", $this->header);
            $responseStatus = $this->responseCode ?? 0; // mastercard returns empty response but with 204 response code when sucessful
            $response = json_decode($response, true);

            // log after sending
            Yii::info(json_encode($response), 'mastercard_respond');
            if ($responseStatus >= 200) {
                $data = $this->getTransactionDetails($tfPin);
                return [
                    "sucess" => true,
                    "data" => $data
                ];
            } else {
                return [
                    "sucess" => false,
                    "data" => $response
                ];
            }
        }

        return null;
    }

    public function releaseTransaction($transactionId)
    {
        $transaction = Transactions::findOne(["TransactionID" => $transactionId]);

        if ($transaction == null) {
            return [
                "sucess" => false,
                "data" => "transaction id not found"
            ];
        }
        $tfPin = $transaction->partnersTransaction->PartnerTransactionReference ?? null;

        if ($tfPin == null) {
            return [
                "sucess" => false,
                "data" => "partner refernece not found"
            ];
        }

        $body = array(
            "TfPin" => $tfPin,
        );
        Yii::info(json_encode($body), 'release_to_mastercard');
        if ($transaction != null) {
            // Send the HTTP rquest
            $response = $this->sendHTTPRequest($this->url . 'transaction/release', json_encode($body), "PUT", $this->header);
            $responseStatus = $this->responseCode ?? 0; // mastercard returns empty response but with 204 response code when sucessful
            $response = json_decode($response, true);

            // log after sending
            Yii::info(json_encode($response), 'release_to_mastercard');
            if ($responseStatus >= 200) {
                $data = $this->getTransactionDetails($tfPin);
                return [
                    "sucess" => true,
                    "data" => $data
                ];
            } else {
                return [
                    "sucess" => false,
                    "data" => $response
                ];
            }
        }

        return null;
    }
    public function getTransactionDetails($tfpin)
    {
        $uri = $this->url . "transaction/bytfpin?TfPin=" . $tfpin;
        $response = $this->sendHTTPRequest($uri, "", "GET", $this->header);
        if ($response) {
            $response = json_decode($response, true);
            return $response;
        }

        return array();
    }
    private function isValidBank($countryCode, $bankId, $branchId)
    {
        // reverse lookup functionality from mastercard to check the bank and bank branch passed
        // there are two methods of reverse lookup
        if (in_array($countryCode, ["PK", "EG", "PH", "JO", "LK", "ID", "QA", "TH"])) {
            //first is to check the branch code using get bank branch id api
            $uri = $this->url . "catalogs/BankBranch?BankId=" . $bankId;
            $response = $this->sendHTTPRequest($uri, "", "GET", $this->header);
            if ($response) {
                $response = json_decode($response, true);
                if (array_key_exists("GetBankBranchResultBo", $response)) {
                    foreach ($response["GetBankBranchResultBo"] as $branch) {
                        if ($branch["BankBranchID"] == $branchId) {
                            return true;
                        }
                    }
                }
            }
        } else {
            // second is to check the brach code using the normal reverse lookup api
            $uri = $this->url . "transaction/BankDetailByRoutingNo?CountryISOcode=" . $countryCode . "&RoutingNumber=" . $branchId;
            $response = $this->sendHTTPRequest($uri, "", "GET", $this->header);
            if ($response !== null) {
                $response = json_decode($response, true);
                if (array_key_exists("BankId", $response)) { // if there is BusinessErrors means the branch not valid
                    return true;
                }
            }
        }

        return false;
    }
    private function getTransactionByRef($transactionId)
    {
        $uri = $this->url . "transaction/ByReferenceNo?ReferenceNumber=" . $transactionId;
        $response = $this->sendHTTPRequest($uri, "", "GET", $this->header);
        if ($response != null) {
            return $response;
        }
    }
    private static function fail(string $message, array $errors = []): array
    {
        return ['ok' => false, 'message' => $message, 'errors' => $errors];
    }
    function filterNulls($data, bool $stripEmptyStrings = false)
    {
        if (is_object($data)) {
            // turn objects (like your $trn sub-objects) into arrays first
            $data = get_object_vars($data);
        }
        if (is_array($data)) {
            foreach ($data as $k => $v) {
                $data[$k] = $this->filterNulls($v, $stripEmptyStrings);
            }
            return array_filter(
                $data,
                function ($v) use ($stripEmptyStrings) {
                    if ($v === null) return false;
                    //if ($stripEmptyStrings && $v === '') return false;
                    //if (is_array($v) && $v === []) return false; // drop now-empty branches
                    return true;
                }
            );
        }
        return $data;
    }
}
