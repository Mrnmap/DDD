<?php

declare(strict_types=1);

namespace common\classes;

/**
 * Entry point DTO for the full response JSON.
 *
 * Usage:
 *   $report = \common\dto\EkycReport::fromJson($jsonString);
 *   // Access:
 *   $report->ReportDetail->ScanTab->MrzString;
 */
final class EkycReport implements \JsonSerializable
{
    public ?ReportDetail $ReportDetail = null;
    public bool $Success = false;
    public ?string $Message = null;
    public ?string $SessionId = null;
    public ?string $Timestamp = null;


    public static function fromJson(string $json): self
    {
        $data = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        return self::fromArray($data);
    }

    public static function fromArray(array $data): self
    {
        $o = new self();
        $o->ReportDetail = isset($data['ReportDetail']) && is_array($data['ReportDetail'])
            ? ReportDetail::fromArray($data['ReportDetail']) : null;
        $o->Success   = (bool)($data['Success'] ?? false);
        $o->Message   = self::strOrNull($data['Message'] ?? null);
        $o->SessionId = self::strOrNull($data['SessionId'] ?? null);
        $o->Timestamp = self::strOrNull($data['Timestamp'] ?? null);
        return $o;
    }

    public function jsonSerialize(): array
    {
        return [
            'ReportDetail' => $this->ReportDetail,
            'Success'      => $this->Success,
            'Message'      => $this->Message,
            'SessionId'    => $this->SessionId,
            'Timestamp'    => $this->Timestamp,
        ];
    }

    private static function strOrNull($v): ?string
    {
        return is_string($v) ? $v : null;
    }
}

final class ReportDetail implements \JsonSerializable
{
    public ?string $Id = null;
    public ?string $SessionId = null;
    public ?string $Status = null;
    public ?string $StartTime = null;
    public ?string $EndTime = null;
    public ?string $SdkVersion = null;
    public ?string $SdkType = null;
    public ?string $ErrorMessage = null;

    public ?ScanTab $ScanTab = null;
    public ?VerificationTab $VerificationTab = null;
    public ?NfcTab $NfcTab = null;

    public bool $HasNFC = false;
    public ?string $DocumentType = null;
    public ?string $DeviceGuid = null;
    public ?string $DeviceId = null;

    public static function fromArray(array $a): self
    {
        $o = new self();
        $o->Id          = self::strOrNull($a['Id'] ?? null);
        $o->SessionId   = self::strOrNull($a['SessionId'] ?? null);
        $o->Status      = self::strOrNull($a['Status'] ?? null);
        $o->StartTime   = self::strOrNull($a['StartTime'] ?? null);
        $o->EndTime     = self::strOrNull($a['EndTime'] ?? null);
        $o->SdkVersion  = self::strOrNull($a['SdkVersion'] ?? null);
        $o->SdkType     = self::strOrNull($a['SdkType'] ?? null);
        $o->ErrorMessage = self::strOrNull($a['ErrorMessage'] ?? null);

        $o->ScanTab = isset($a['ScanTab']) && is_array($a['ScanTab']) ? ScanTab::fromArray($a['ScanTab']) : null;
        $o->VerificationTab = isset($a['VerificationTab']) && is_array($a['VerificationTab']) ? VerificationTab::fromArray($a['VerificationTab']) : null;
        $o->NfcTab = isset($a['NfcTab']) && is_array($a['NfcTab']) ? NfcTab::fromArray($a['NfcTab']) : null;

        $o->HasNFC       = (bool)($a['HasNFC'] ?? false);
        $o->DocumentType = self::strOrNull($a['DocumentType'] ?? null);
        $o->DeviceGuid   = self::strOrNull($a['DeviceGuid'] ?? null);
        $o->DeviceId     = self::strOrNull($a['DeviceId'] ?? null);
        return $o;
    }

    public function jsonSerialize(): array
    {
        return [
            'Id'           => $this->Id,
            'SessionId'    => $this->SessionId,
            'Status'       => $this->Status,
            'StartTime'    => $this->StartTime,
            'EndTime'      => $this->EndTime,
            'SdkVersion'   => $this->SdkVersion,
            'SdkType'      => $this->SdkType,
            'ErrorMessage' => $this->ErrorMessage,
            'ScanTab'      => $this->ScanTab,
            'VerificationTab' => $this->VerificationTab,
            'NfcTab'       => $this->NfcTab,
            'HasNFC'       => $this->HasNFC,
            'DocumentType' => $this->DocumentType,
            'DeviceGuid'   => $this->DeviceGuid,
            'DeviceId'     => $this->DeviceId,
        ];
    }

    private static function strOrNull($v): ?string
    {
        return is_string($v) ? $v : null;
    }
}

final class ScanTab implements \JsonSerializable
{
    public ?string $DocumentNumber = null;
    public ?string $FullNameArabic = null;
    public ?string $FullNameEnglish = null;
    public ?string $DateOfBirth = null;
    public ?string $DateOfBirthFormatted = null;
    public ?string $PlaceOfBirthArabic = null;
    public ?string $DateOfExpiry = null;
    public ?string $DateOfExpiryFormatted = null;
    public ?string $SecondaryID = null;
    public ?string $PrimaryID = null;
    public ?string $FullName = null;

    /** @var CapturedFrame[] */
    public array $CapturedFrames = [];

    public ?string $IssuingState = null;
    public ?float $CaptureDurationFront = null;
    public ?float $CaptureDurationBack = null;
    public ?float $CaptureDuration = null;

    public ?string $MrzFormat = null;
    public ?string $MrzDocumentType = null;
    public ?string $MrzSurNames = null;
    public ?string $MrzGivenNames = null;
    public ?string $MrzOptionalData = null;
    public ?string $MrzOptionalData2 = null;
    public ?string $MrzString = null;

    public bool $IsDocumentNumberHashValid = false;
    public bool $IsBirthDateHashValid = false;
    public bool $IsExpiryDateHashValid = false;
    public bool $IsAllChecksValid = false;

    public ?string $MrzNationalityCountryName = null;
    public ?string $MrzNationalityCountryIso1 = null;
    public ?string $MrzNationalityCountryIso2 = null;
    public ?string $MrzNationalityCountryIso3 = null;
    public ?string $MrzNationalityCountryCode = null;
    public bool $MrzNationalityCountryIsExtended = false;

    public ?string $MrzCountryName = null;
    public ?string $MrzCountryIso1 = null;
    public ?string $MrzCountryIso2 = null;
    public ?string $MrzCountryIso3 = null;
    public ?string $MrzCountryCode = null;
    public bool $MrzCountryIsExtended = false;

    public $MrzValues = null; // unknown structure
    public ?string $MrzCountry = null;
    public ?string $MrzGender = null;
    public ?string $MrzDocumentClassCode = null;
    public ?string $MrzIssuingState = null;

    public ?string $VisualZoneNationalIDNumber = null;
    public ?string $VisualZoneNationality = null;
    public ?string $VisualZoneSurNames = null;
    public ?string $VisualZoneGivenNames = null;
    public ?string $VisualZoneBirthDate = null;
    public ?string $VisualZoneDocumentNumber = null;
    public ?string $VisualZoneExpiryDate = null;
    public ?string $VisualZoneGender = null;
    public ?string $VisualZoneIssuingState = null;

    public ?string $NfcPhotoData = null;
    public ?string $NfcFullNameArabic = null;
    public ?string $NfcFullNameEnglish = null;
    public ?string $NfcGenderArabic = null;
    public ?string $NfcGenderEnglish = null;
    public ?string $NfcPlaceOfIssueEnglish = null;
    public ?string $NfcCompanyNameEnglish = null;

    public static function fromArray(array $a): self
    {
        $o = new self();
        $o->DocumentNumber = self::s($a['DocumentNumber'] ?? null);
        $o->FullNameArabic = self::s($a['FullNameArabic'] ?? null);
        $o->FullNameEnglish = self::s($a['FullNameEnglish'] ?? null);
        $o->DateOfBirth = self::s($a['DateOfBirth'] ?? null);
        $o->DateOfBirthFormatted = self::s($a['DateOfBirthFormatted'] ?? null);
        $o->PlaceOfBirthArabic = self::s($a['PlaceOfBirthArabic'] ?? null);
        $o->DateOfExpiry = self::s($a['DateOfExpiry'] ?? null);
        $o->DateOfExpiryFormatted = self::s($a['DateOfExpiryFormatted'] ?? null);
        $o->SecondaryID = self::s($a['SecondaryID'] ?? null);
        $o->PrimaryID = self::s($a['PrimaryID'] ?? null);
        $o->FullName = self::s($a['FullName'] ?? null);

        $o->CapturedFrames = [];
        if (!empty($a['CapturedFrames']) && is_array($a['CapturedFrames'])) {
            foreach ($a['CapturedFrames'] as $row) {
                if (is_array($row)) {
                    $o->CapturedFrames[] = CapturedFrame::fromArray($row);
                }
            }
        }

        $o->IssuingState = self::s($a['IssuingState'] ?? null);
        $o->CaptureDurationFront = self::f($a['CaptureDurationFront'] ?? null);
        $o->CaptureDurationBack  = self::f($a['CaptureDurationBack'] ?? null);
        $o->CaptureDuration      = self::f($a['CaptureDuration'] ?? null);

        $o->MrzFormat = self::s($a['MrzFormat'] ?? null);
        $o->MrzDocumentType = self::s($a['MrzDocumentType'] ?? null);
        $o->MrzSurNames = self::s($a['MrzSurNames'] ?? null);
        $o->MrzGivenNames = self::s($a['MrzGivenNames'] ?? null);
        $o->MrzOptionalData = self::s($a['MrzOptionalData'] ?? null);
        $o->MrzOptionalData2 = self::s($a['MrzOptionalData2'] ?? null);
        $o->MrzString = self::s($a['MrzString'] ?? null);

        $o->IsDocumentNumberHashValid = (bool)($a['IsDocumentNumberHashValid'] ?? false);
        $o->IsBirthDateHashValid      = (bool)($a['IsBirthDateHashValid'] ?? false);
        $o->IsExpiryDateHashValid     = (bool)($a['IsExpiryDateHashValid'] ?? false);
        $o->IsAllChecksValid          = (bool)($a['IsAllChecksValid'] ?? false);

        $o->MrzNationalityCountryName = self::s($a['MrzNationalityCountryName'] ?? null);
        $o->MrzNationalityCountryIso1 = self::s($a['MrzNationalityCountryIso1'] ?? null);
        $o->MrzNationalityCountryIso2 = self::s($a['MrzNationalityCountryIso2'] ?? null);
        $o->MrzNationalityCountryIso3 = self::s($a['MrzNationalityCountryIso3'] ?? null);
        $o->MrzNationalityCountryCode = self::s($a['MrzNationalityCountryCode'] ?? null);
        $o->MrzNationalityCountryIsExtended = (bool)($a['MrzNationalityCountryIsExtended'] ?? false);

        $o->MrzCountryName = self::s($a['MrzCountryName'] ?? null);
        $o->MrzCountryIso1 = self::s($a['MrzCountryIso1'] ?? null);
        $o->MrzCountryIso2 = self::s($a['MrzCountryIso2'] ?? null);
        $o->MrzCountryIso3 = self::s($a['MrzCountryIso3'] ?? null);
        $o->MrzCountryCode = self::s($a['MrzCountryCode'] ?? null);
        $o->MrzCountryIsExtended = (bool)($a['MrzCountryIsExtended'] ?? false);

        $o->MrzValues = $a['MrzValues'] ?? null;
        $o->MrzCountry = self::s($a['MrzCountry'] ?? null);
        $o->MrzGender  = self::s($a['MrzGender'] ?? null);
        $o->MrzDocumentClassCode = self::s($a['MrzDocumentClassCode'] ?? null);
        $o->MrzIssuingState = self::s($a['MrzIssuingState'] ?? null);

        $o->VisualZoneNationalIDNumber = self::s($a['VisualZoneNationalIDNumber'] ?? null);
        $o->VisualZoneNationality      = self::s($a['VisualZoneNationality'] ?? null);
        $o->VisualZoneSurNames         = self::s($a['VisualZoneSurNames'] ?? null);
        $o->VisualZoneGivenNames       = self::s($a['VisualZoneGivenNames'] ?? null);
        $o->VisualZoneBirthDate        = self::s($a['VisualZoneBirthDate'] ?? null);
        $o->VisualZoneDocumentNumber   = self::s($a['VisualZoneDocumentNumber'] ?? null);
        $o->VisualZoneExpiryDate       = self::s($a['VisualZoneExpiryDate'] ?? null);
        $o->VisualZoneGender           = self::s($a['VisualZoneGender'] ?? null);
        $o->VisualZoneIssuingState     = self::s($a['VisualZoneIssuingState'] ?? null);

        $o->NfcPhotoData           = self::s($a['NfcPhotoData'] ?? null);
        $o->NfcFullNameArabic      = self::s($a['NfcFullNameArabic'] ?? null);
        $o->NfcFullNameEnglish     = self::s($a['NfcFullNameEnglish'] ?? null);
        $o->NfcGenderArabic        = self::s($a['NfcGenderArabic'] ?? null);
        $o->NfcGenderEnglish       = self::s($a['NfcGenderEnglish'] ?? null);
        $o->NfcPlaceOfIssueEnglish = self::s($a['NfcPlaceOfIssueEnglish'] ?? null);
        $o->NfcCompanyNameEnglish  = self::s($a['NfcCompanyNameEnglish'] ?? null);
        return $o;
    }

    public function jsonSerialize(): array
    {
        return get_object_vars($this);
    }

    private static function s($v): ?string
    {
        return is_string($v) ? $v : null;
    }
    private static function f($v): ?float
    {
        return is_numeric($v) ? (float)$v : null;
    }
}

final class CapturedFrame implements \JsonSerializable
{
    public ?string $FrameType = null;
    public ?string $ImagePath = null;
    public ?string $ContentType = null;
    public $ImageData = null; // null or base64 string per provider
    public ?string $ImageUrl = null;

    public static function fromArray(array $a): self
    {
        $o = new self();
        $o->FrameType   = self::s($a['FrameType'] ?? null);
        $o->ImagePath   = self::s($a['ImagePath'] ?? null);
        $o->ContentType = self::s($a['ContentType'] ?? null);
        $o->ImageData   = $a['ImageData'] ?? null;
        $o->ImageUrl    = self::s($a['ImageUrl'] ?? null);
        return $o;
    }

    public function jsonSerialize(): array
    {
        return [
            'FrameType' => $this->FrameType,
            'ImagePath' => $this->ImagePath,
            'ContentType' => $this->ContentType,
            'ImageData' => $this->ImageData,
            'ImageUrl' => $this->ImageUrl,
        ];
    }

    private static function s($v): ?string
    {
        return is_string($v) ? $v : null;
    }
}

final class VerificationTab implements \JsonSerializable
{
    public bool $OpticalFraudDetection = false;
    public bool $AllowNinPhysicalDocument = false;
    public ?float $GenuineIdPhotoScore = null;
    public ?float $NoScreenCaptureScore = null;
    public ?float $NoPrintedCopyScore = null;
    public ?float $FaceMatchingScore = null;
    public bool $IsPassivePassed = false;
    public bool $IsFaceMatched = false;
    public ?string $ScanFrontDateOfExpiryFormatted = null;
    public ?string $ScanBackDateOfExpiryFormatted = null;
    public ?string $ReadingExpiryDate = null;
    public bool $DataConsistencyCheckPassed = false;
    public bool $GenderValidationPassed = false;
    public bool $DocumentNumberValidationPassed = false;
    public bool $DateOfBirthValidationPassed = false;
    public bool $NationalityValidationPassed = false;
    public bool $MrzChecksumPassed = false;
    /** Note: In your sample this is "False" (string). Keep string to match provider. */
    public ?string $OverallCheckValid = null;
    public bool $IsDocumentNumberHashValid = false;
    public bool $IsBirthDateHashValid = false;
    public bool $IsExpiryDateHashValid = false;
    public bool $IsAllChecksValid = false;

    public static function fromArray(array $a): self
    {
        $o = new self();
        $o->OpticalFraudDetection = (bool)($a['OpticalFraudDetection'] ?? false);
        $o->AllowNinPhysicalDocument = (bool)($a['AllowNinPhysicalDocument'] ?? false);
        $o->GenuineIdPhotoScore = self::f($a['GenuineIdPhotoScore'] ?? null);
        $o->NoScreenCaptureScore = self::f($a['NoScreenCaptureScore'] ?? null);
        $o->NoPrintedCopyScore = self::f($a['NoPrintedCopyScore'] ?? null);
        $o->FaceMatchingScore = self::f($a['FaceMatchingScore'] ?? null);
        $o->IsPassivePassed = (bool)($a['IsPassivePassed'] ?? false);
        $o->IsFaceMatched = (bool)($a['IsFaceMatched'] ?? false);
        $o->ScanFrontDateOfExpiryFormatted = self::s($a['ScanFrontDateOfExpiryFormatted'] ?? null);
        $o->ScanBackDateOfExpiryFormatted  = self::s($a['ScanBackDateOfExpiryFormatted'] ?? null);
        $o->ReadingExpiryDate = self::s($a['ReadingExpiryDate'] ?? null);
        $o->DataConsistencyCheckPassed = (bool)($a['DataConsistencyCheckPassed'] ?? false);
        $o->GenderValidationPassed = (bool)($a['GenderValidationPassed'] ?? false);
        $o->DocumentNumberValidationPassed = (bool)($a['DocumentNumberValidationPassed'] ?? false);
        $o->DateOfBirthValidationPassed = (bool)($a['DateOfBirthValidationPassed'] ?? false);
        $o->NationalityValidationPassed = (bool)($a['NationalityValidationPassed'] ?? false);
        $o->MrzChecksumPassed = (bool)($a['MrzChecksumPassed'] ?? false);
        $o->OverallCheckValid = self::s($a['OverallCheckValid'] ?? null);
        $o->IsDocumentNumberHashValid = (bool)($a['IsDocumentNumberHashValid'] ?? false);
        $o->IsBirthDateHashValid = (bool)($a['IsBirthDateHashValid'] ?? false);
        $o->IsExpiryDateHashValid = (bool)($a['IsExpiryDateHashValid'] ?? false);
        $o->IsAllChecksValid = (bool)($a['IsAllChecksValid'] ?? false);
        return $o;
    }

    public function jsonSerialize(): array
    {
        return get_object_vars($this);
    }

    private static function s($v): ?string
    {
        return is_string($v) ? $v : null;
    }
    private static function f($v): ?float
    {
        return is_numeric($v) ? (float)$v : null;
    }
}

final class NfcTab implements \JsonSerializable
{
    public $SponsorRelationship = null;
    public $SponsorNumber = null;
    public $SponsorIssueDate = null;
    public $SponsorExpiryDate = null;
    public $VisaNumber = null;
    public $VisaExpiryDate = null;
    public $VisaPlaceOfIssueArabic = null;

    public ?string $NfcIdNumber = null;
    public ?string $NfcIssueDate = null;
    public ?string $NfcExpiryDate = null;
    public ?string $NfcPlaceOfIssueArabic = null;
    public ?string $NfcDateOfBirth = null;
    public ?string $NfcCountryOfBirthArabic = null;
    public ?string $NfcNationalityEnglish = null;
    public ?string $NfcNationalityArabic = null;
    public ?string $NfcIdNumber2 = null;
    public ?string $NfcCompanyNameArabic = null;
    public ?string $NfcCompanyAddressArabic = null;
    public ?string $NfcFullNameArabic = null;
    public ?string $NfcFullNameEnglish = null;
    public ?string $NfcGenderArabic = null;
    public ?string $NfcGenderEnglish = null;
    public ?string $NfcPlaceOfIssueEnglish = null;
    public ?string $NfcCompanyNameEnglish = null;

    public static function fromArray(array $a): self
    {
        $o = new self();
        // Unknown/nullable provider fields
        $o->SponsorRelationship = $a['SponsorRelationship'] ?? null;
        $o->SponsorNumber = $a['SponsorNumber'] ?? null;
        $o->SponsorIssueDate = $a['SponsorIssueDate'] ?? null;
        $o->SponsorExpiryDate = $a['SponsorExpiryDate'] ?? null;
        $o->VisaNumber = $a['VisaNumber'] ?? null;
        $o->VisaExpiryDate = $a['VisaExpiryDate'] ?? null;
        $o->VisaPlaceOfIssueArabic = $a['VisaPlaceOfIssueArabic'] ?? null;

        $o->NfcIdNumber = self::s($a['NfcIdNumber'] ?? null);
        $o->NfcIssueDate = self::s($a['NfcIssueDate'] ?? null);
        $o->NfcExpiryDate = self::s($a['NfcExpiryDate'] ?? null);
        $o->NfcPlaceOfIssueArabic = self::s($a['NfcPlaceOfIssueArabic'] ?? null);
        $o->NfcDateOfBirth = self::s($a['NfcDateOfBirth'] ?? null);
        $o->NfcCountryOfBirthArabic = self::s($a['NfcCountryOfBirthArabic'] ?? null);
        $o->NfcNationalityEnglish = self::s($a['NfcNationalityEnglish'] ?? null);
        $o->NfcNationalityArabic = self::s($a['NfcNationalityArabic'] ?? null);
        $o->NfcIdNumber2 = self::s($a['NfcIdNumber2'] ?? null);
        $o->NfcCompanyNameArabic = self::s($a['NfcCompanyNameArabic'] ?? null);
        $o->NfcCompanyAddressArabic = self::s($a['NfcCompanyAddressArabic'] ?? null);
        $o->NfcFullNameArabic = self::s($a['NfcFullNameArabic'] ?? null);
        $o->NfcFullNameEnglish = self::s($a['NfcFullNameEnglish'] ?? null);
        $o->NfcGenderArabic = self::s($a['NfcGenderArabic'] ?? null);
        $o->NfcGenderEnglish = self::s($a['NfcGenderEnglish'] ?? null);
        $o->NfcPlaceOfIssueEnglish = self::s($a['NfcPlaceOfIssueEnglish'] ?? null);
        $o->NfcCompanyNameEnglish = self::s($a['NfcCompanyNameEnglish'] ?? null);
        return $o;
    }

    public function jsonSerialize(): array
    {
        return get_object_vars($this);
    }

    private static function s($v): ?string
    {
        return is_string($v) ? $v : null;
    }
}
