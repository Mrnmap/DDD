<?php

declare(strict_types=1);

namespace common\classes;

use GuzzleHttp\Client as HttpClient;
use GuzzleHttp\Exception\GuzzleException;
use JsonException;
use common\classes\EkycReport;
use Exception;

/**
 * VisionPoint
 *
 * Full standalone implementation using Guzzle instead of yii\httpclient.
 */
final class VisionPoint
{
    // ===== CRYPTO KEYS =====
    private string $AES_KEY_HEX;
    private string $HMAC_KEY_HEX;
    private string $IV_UTF8; // 16 chars

    // ===== API DETAILS =====
    private string $BASE_URL;
    private string $PATH;
    private string $SDK_SECRET;

    // ===== AUTH HEADERS =====
    private string $X_API_KEY;
    private string $BEARER_TOKEN;

    // ===== INTERNAL =====
    private string $aesKeyBin;
    private string $hmacKeyBin;
    private string $ivBin;
    private HttpClient $http;

    public function __construct()
    {

        $this->AES_KEY_HEX = $_ENV["EKYC_AES_KEY_HEX"];
        $this->HMAC_KEY_HEX = $_ENV["EKYC_HMAC_KEY_HEX"];
        $this->IV_UTF8      = $_ENV["EKYC_IV_UTF8"]; // 16 chars

        // ===== API DETAILS =====
        $this->BASE_URL   = $_ENV["EKYC_BASE_URL"];
        $this->PATH       = $_ENV["EKYC_PATH"];
        $this->SDK_SECRET = $_ENV["EKYC_SDK_SECRET"];

        // ===== AUTH HEADERS =====
        $this->X_API_KEY    = $_ENV["EKYC_X_API_KEY"];
        $this->BEARER_TOKEN = $_ENV["EKYC_BEARER_TOKEN"];

        $this->aesKeyBin  = $this->hexToBinStrict($this->AES_KEY_HEX, 'AES key');
        $this->hmacKeyBin = $this->hexToBinStrict($this->HMAC_KEY_HEX, 'HMAC key');
        $this->ivBin      = $this->utf8ToFixedBytes($this->IV_UTF8, 16, 'IV');

        $this->http = new HttpClient([
            'base_uri' => $this->BASE_URL,
            'timeout'  => 30.0,
            'verify'   => true, // keep TLS verification on
        ]);
    }

    /**
     * Fetch eKYC report and return as DTO
     */
    public function fetchReport(string $reportId): array
    {
        try {
            $data = $this->requestAndDecrypt($reportId);
            $dto = EkycReport::fromArray($data);
            return [$data, $dto];
        } catch (Exception $e) {
            return [null, null];
        }
    }

    /**
     * Perform encrypted POST and return decrypted array
     */
    public function requestAndDecrypt(string $reportId): array
    {
        $body = $this->buildEncryptedBody($reportId, $this->SDK_SECRET);

        try {
            $response = $this->http->post($this->BASE_URL . $this->PATH, [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'X-API-KEY'     => $this->X_API_KEY,
                    'Authorization' => 'Bearer ' . $this->BEARER_TOKEN,
                ],
                'body' => json_encode($body, JSON_UNESCAPED_SLASHES),
            ]);
        } catch (GuzzleException $e) {
            throw new \RuntimeException('HTTP request failed: ' . $e->getMessage(), 0, $e);
        }

        $content = (string)$response->getBody();
        return $this->decryptResponseJson($content);
    }

    /**
     * Build encrypted payload (AES + HMAC)
     */
    private function buildEncryptedBody(string $reportId, string $sdkSecretKey, string $sessionId = ''): array
    {
        $payload = [
            'ReportId'     => $reportId,
            'SDKSecretKey' => $sdkSecretKey,
        ];

        $json = json_encode($payload, JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            throw new \RuntimeException('Failed to encode payload to JSON.');
        }

        $cipherRaw = openssl_encrypt(
            $json,
            'AES-256-CBC',
            $this->aesKeyBin,
            OPENSSL_RAW_DATA,
            $this->ivBin
        );
        if ($cipherRaw === false) {
            throw new \RuntimeException('Encryption failed.');
        }

        $hmacRaw = hash_hmac('sha256', $cipherRaw, $this->hmacKeyBin, true);

        return [
            'EncryptedData' => base64_encode($cipherRaw),
            'Hmac'          => base64_encode($hmacRaw),
            'SessionId'     => $sessionId,
        ];
    }

    /**
     * Verify HMAC and decrypt AES response
     */
    private function decryptResponseJson(string $responseJson): array
    {
        $top = json_decode($responseJson, true, 512, JSON_THROW_ON_ERROR);

        $encB64  = $top['EncryptedData'] ?? $top['encryptedData'] ?? null;
        $hmacB64 = $top['Hmac'] ?? $top['hmac'] ?? null;

        if (!is_string($encB64) || !is_string($hmacB64)) {
            throw new \RuntimeException('Missing EncryptedData or Hmac.');
        }

        $cipherRaw       = base64_decode($encB64, true);
        $providedHmacRaw = base64_decode($hmacB64, true);

        if ($cipherRaw === false || $providedHmacRaw === false) {
            throw new \RuntimeException('Invalid Base64 values.');
        }

        // Verify HMAC
        $computedHmacRaw = hash_hmac('sha256', $cipherRaw, $this->hmacKeyBin, true);
        if (!hash_equals($computedHmacRaw, $providedHmacRaw)) {
            throw new \RuntimeException('HMAC verification failed.');
        }

        $plain = openssl_decrypt(
            $cipherRaw,
            'AES-256-CBC',
            $this->aesKeyBin,
            OPENSSL_RAW_DATA,
            $this->ivBin
        );
        if ($plain === false) {
            throw new \RuntimeException('Decryption failed.');
        }

        return json_decode($plain, true, 512, JSON_THROW_ON_ERROR);
    }

    // ---------- Helpers ----------
    private function hexToBinStrict(string $hex, string $label): string
    {
        $hex = preg_replace('/\s+/', '', $hex);
        if (!ctype_xdigit($hex) || strlen($hex) % 2 !== 0) {
            throw new \InvalidArgumentException("$label must be valid even-length hex.");
        }
        $bin = hex2bin($hex);
        if ($bin === false) {
            throw new \InvalidArgumentException("Invalid hex for $label");
        }
        return $bin;
    }

    private function utf8ToFixedBytes(string $s, int $len, string $label): string
    {
        if (strlen($s) !== $len) {
            throw new \InvalidArgumentException("$label must be $len bytes.");
        }
        return $s;
    }
}
