<?php

namespace common\classes;

enum DeliveryMethod
{
    case BankDeposit;
    case CashPickup;
    case MobileWallet;
    case WireTransfer;

    public function mastercard(): string
    {
        return match ($this) {
            self::BankDeposit => 'C',
            self::CashPickup => '2',
            self::MobileWallet => 'W',
            self::WireTransfer => 'WT',
        };
    }

    public function system(): string
    {
        return match ($this) {
            self::BankDeposit => '1',
            self::CashPickup => '2',
            self::MobileWallet => '3',
        };
    }
    public static function fromCode(string $code): ?self
    {
        return match ($code) {
            '1' => self::BankDeposit,
            '2' => self::CashPickup,
            '3' => self::MobileWallet,
            '4' => self::WireTransfer,
            default => null,
        };
    }

    public static function fromName(string $name): ?self
    {
        return match ($name) {
            'bank' => self::BankDeposit,
            'cash' => self::CashPickup,
            'wallet' => self::MobileWallet,
            default => null,
        };
    }
}
