<?php

declare(strict_types=1);

namespace common\classes;

use common\classes\EkycReport;

final class EkycEvaluator
{
    public const DECISION_APPROVED = 'approved';
    public const DECISION_REVIEW   = 'review';
    public const DECISION_REJECTED = 'rejected';

    // Tunables
    private const MIN_FACE_MATCH       = 0.75;
    private const REQUIRE_MRZ_CHECKSUM = true;
    private const REQUIRE_HASH_VALID   = true;
    private const REJECT_IF_EXPIRED    = true;

    /**
     * Returns:
     *  - decision: approved|review|rejected
     *  - reason: short summary
     *  - pass_count / total_checks: boolean condition counts
     *  - conditions: EkycConditions object (flags)
     *  - meta: small extras
     *  - review_reasons: array of human-readable reasons (only for review)
     *
     * @return array{
     *   decision:string,
     *   reason:string,
     *   pass_count:int,
     *   total_checks:int,
     *   conditions:EkycConditions,
     *   meta:array<string,mixed>,
     *   review_reasons?:string[]
     * }
     */
    public static function evaluate(EkycReport $dto): array
    {
        if (!$dto->Success) {
            return self::result(self::DECISION_REJECTED, 'Provider Success=false', new EkycConditions());
        }
        if (!$dto->ReportDetail || ($dto->ReportDetail->Status ?? '') !== 'Complete') {
            return self::result(self::DECISION_REVIEW, 'Report incomplete/missing ReportDetail', new EkycConditions(), [], ['reportId' => $dto->ReportDetail->Id ?? null]);
        }

        $v  = $dto->ReportDetail->VerificationTab ?? (object)[];
        $st = $dto->ReportDetail->ScanTab        ?? (object)[];

        // Build conditions as an OBJECT
        $c = self::buildConditions($v, $st);

        // 1) Hard-fail gate (simple, strict)
        //TODO: apply if there is no face verfication done
        // it is applied now by face matching score
        if (self::isHardFail($c)) {
            $reviewReasons = self::collectReviewReasons($c);
            return self::result(self::DECISION_REJECTED, 'Hard-fail conditions present', $c, $reviewReasons, [
                'reportId'  => $dto->ReportDetail->Id ?? null,
                'faceScore' => $v->FaceMatchingScore ?? null,
            ]);
        }

        // 2) Approved = ALL CORE must pass (simple!)
        //    Core = face match, liveness, not expired
        if ($c->face_match && $c->liveness_passed && $c->not_expired) {
            return self::result(self::DECISION_APPROVED, 'Core checks passed', $c, [], [
                'reportId'  => $dto->ReportDetail->Id ?? null,
                'faceScore' => $v->FaceMatchingScore ?? null,
            ]);
        }

        // 3) Otherwise REVIEW — list exactly why it isn’t approved (and wasn’t hard-failed)
        $reviewReasons = self::collectReviewReasons($c);
        return self::result(
            self::DECISION_REVIEW,
            'Core checks not fully satisfied; requires human review',
            $c,
            $reviewReasons,
            [
                'reportId'  => $dto->ReportDetail->Id ?? null,
                'faceScore' => $v->FaceMatchingScore ?? null,
            ]
        );
    }

    /* -------------------------- Conditions -------------------------- */

    private static function buildConditions(object $v, object $st): EkycConditions
    {
        $c = new EkycConditions();

        $c->face_match        = self::checkFaceMatch($v);
        $c->liveness_passed   = self::checkLiveness($v);
        $c->mrz_checksum      = self::checkMrzChecksum($v);
        $c->doc_hash_valid    = self::checkDocHash($v);
        $c->dob_hash_valid    = self::checkDobHash($v);
        $c->expiry_hash_valid = self::checkExpiryHash($v);
        $c->not_expired       = self::checkNotExpired($st);
        $c->data_consistency  = self::checkDataConsistency($v);
        $c->gender_valid      = self::checkGenderValid($v);
        $c->nationality_valid = self::checkNationalityValid($v);

        return $c;
    }

    /* --------------------------- Gates ------------------------------ */

    private static function isHardFail(EkycConditions $c): bool
    {
        // Fail liveness OR face mismatch
        if (!$c->liveness_passed || !$c->face_match) {
            return true;
        }

        // Expired
        if (self::REJECT_IF_EXPIRED && !$c->not_expired) {
            return true;
        }

        // Consistency + MRZ + hashes all bad (clear integrity problem)
        $hashBundleBad = (!$c->doc_hash_valid || !$c->dob_hash_valid || !$c->expiry_hash_valid);
        if ((!$c->data_consistency) && (self::REQUIRE_MRZ_CHECKSUM && !$c->mrz_checksum) && $hashBundleBad) {
            return true;
        }

        return false;
    }

    /* ---------------------------- Checks ---------------------------- */

    private static function checkFaceMatch(object $v): bool
    {
        $score = (float)($v->FaceMatchingScore ?? 0.0);
        return (bool)($v->IsFaceMatched ?? false) && $score >= self::MIN_FACE_MATCH;
    }

    private static function checkLiveness(object $v): bool
    {
        return (bool)($v->IsPassivePassed ?? false);
    }

    private static function checkMrzChecksum(object $v): bool
    {
        return self::REQUIRE_MRZ_CHECKSUM ? (bool)($v->MrzChecksumPassed ?? false) : true;
    }

    private static function checkDocHash(object $v): bool
    {
        return self::REQUIRE_HASH_VALID ? (bool)($v->IsDocumentNumberHashValid ?? false) : true;
    }

    private static function checkDobHash(object $v): bool
    {
        return self::REQUIRE_HASH_VALID ? (bool)($v->IsBirthDateHashValid ?? false) : true;
    }

    private static function checkExpiryHash(object $v): bool
    {
        return self::REQUIRE_HASH_VALID ? (bool)($v->IsExpiryDateHashValid ?? false) : true;
    }

    private static function checkNotExpired(object $st): bool
    {
        if (!self::REJECT_IF_EXPIRED) return true;
        $expiryStr = $st->DateOfExpiry ?? null;
        if (!$expiryStr) return false;
        try {
            $expiry = new \DateTimeImmutable($expiryStr);
            return $expiry >= new \DateTimeImmutable('now');
        } catch (\Throwable $e) {
            return false;
        }
    }

    private static function checkDataConsistency(object $v): bool
    {
        return (bool)($v->DataConsistencyCheckPassed ?? false);
    }

    private static function checkGenderValid(object $v): bool
    {
        return (bool)($v->GenderValidationPassed ?? true);
    }

    private static function checkNationalityValid(object $v): bool
    {
        return (bool)($v->NationalityValidationPassed ?? true);
    }

    /* ------------------------ Review reasons ------------------------- */

    /**
     * Only called when it’s not a hard-fail and not approved.
     * Explain, in plain language, why this case is in REVIEW.
     * Keep it focused on CORE failures first, then secondary hints.
     *
     * @return string[]
     */
    private static function collectReviewReasons(EkycConditions $c): array
    {
        $reasons = [];

        // Core failures (any missing → review)
        if (!$c->face_match)      $reasons[] = 'Face match below threshold or mismatch';
        if (!$c->liveness_passed) $reasons[] = 'Passive liveness not confirmed';
        if (!$c->not_expired)     $reasons[] = 'Document expired or expiry invalid';

        // Secondary signals (optional hints for the analyst)
        if (self::REQUIRE_MRZ_CHECKSUM && !$c->mrz_checksum) {
            $reasons[] = 'MRZ checksum did not pass';
        }
        if (!($c->doc_hash_valid && $c->dob_hash_valid && $c->expiry_hash_valid)) {
            $hashes = [];
            if (!$c->doc_hash_valid)   $hashes[] = 'document #';
            if (!$c->dob_hash_valid)   $hashes[] = 'date of birth';
            if (!$c->expiry_hash_valid) $hashes[] = 'expiry date';
            $reasons[] = 'Hash validation failed for: ' . implode(', ', $hashes);
        }
        if (!$c->data_consistency) {
            $reasons[] = 'Data consistency check failed';
        }
        if (!$c->gender_valid) {
            $reasons[] = 'Gender validation failed';
        }
        if (!$c->nationality_valid) {
            $reasons[] = 'Nationality validation failed';
        }

        // If somehow empty, add a generic reason
        if (empty($reasons)) {
            $reasons[] = 'Core checks not fully satisfied';
        }

        return $reasons;
    }

    /* ---------------------------- Utils ----------------------------- */

    private static function passCounts(EkycConditions $c): array
    {
        $ref = new \ReflectionObject($c);
        $props = $ref->getProperties();
        $pass = 0;
        $total = 0;
        foreach ($props as $p) {
            $v = $p->getValue($c);
            if (!is_bool($v)) continue;
            $total++;
            if ($v) $pass++;
        }
        return [$pass, $total];
    }

    private static function result(string $decision, string $reason, EkycConditions $c, array $reviewReasons = [], array $meta = []): array
    {
        [$pass, $total] = self::passCounts($c);
        $out = [
            'decision'     => $decision,
            'reason'       => $reason,
            'pass_count'   => $pass,
            'total_checks' => $total,
            'conditions'   => $c,     // object with ->liveness_passed, ->face_match, ...
            'meta'         => $meta,
        ];
        if ($decision == self::DECISION_REVIEW || $decision == self::DECISION_REJECTED) {
            $out['review_reasons'] = array_values(array_unique($reviewReasons));
        }
        return $out;
    }
}

/**
 * Typed container for conditions — access as $c->liveness_passed etc.
 */
final class EkycConditions
{
    public bool $face_match        = false;
    public bool $liveness_passed   = false;
    public bool $mrz_checksum      = false;
    public bool $doc_hash_valid    = false;
    public bool $dob_hash_valid    = false;
    public bool $expiry_hash_valid = false;
    public bool $not_expired       = false;
    public bool $data_consistency  = false;
    public bool $gender_valid      = true;  // default non-fail
    public bool $nationality_valid = true;  // default non-fail
}
