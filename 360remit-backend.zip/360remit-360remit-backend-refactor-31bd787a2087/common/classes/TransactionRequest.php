<?php

namespace common\classes;

class Sender
{
    public $Name;
    public $Address;
    public $PhoneMobile;
    public $CountryIsoCode;
    public $StateId;
    public $CityId;
    public $TypeOfId;
    public $IdNumber;
    public $IdExpiryDate;
    public $DateOfBirth;
    public $NationalityIsoCode;
}

class Receiver
{
    public $FirstName;
    public $SecondName;
    public $LastName;
    public $CompleteAddress;
    public $MobilePhone;
    public $CountryIsoCode;
    public $NationalityIsoCode;
    public $IsIndividual;
}

class TransactionInfo
{
    public $SourceCurrencyIsoCode;
    public $PaymentModeId;
    public $ReceiveCurrencyIsoCode;
    public $ReceiveAmount;
    public $PurposeOfRemittanceId;
    public $FormOfPaymentId;
    public $ReferenceNumber;
    public $BankId;
    public $BankBranchId;
    public $Account;
    public $PayerId;
    public $AccountNumber;
}

class Compliance
{
    public $CountryIssueIsoCode;
    public $SourceOfFunds;
    public $ReceiverFullName;
}

class TransactionRequest
{
    public $Sender;
    public $Receiver;
    public $TransactionInfo;
    public $Compliance;

    public function __construct()
    {
        $this->Sender = new Sender();
        $this->Receiver = new Receiver();
        $this->TransactionInfo = new TransactionInfo();
        $this->Compliance = new Compliance();
    }
}
