<?php

namespace common\classes;

use Exception;
use common\services\SmppService;
use Yii;

class Tamimah
{
    // TODO: this class is not used anymore
    private $smppService;

    function __construct($config = [])
    {
        // Initialize SMS/SMPP service with Tamimah configuration from params
        $smppConfig = Yii::$app->params['smpp'] ?? [];
        $this->smppService = new SmppService();
    }

    /**
     * Establish SMPP connection
     * @return array
     */
    public function connectSmpp(): array
    {
        try {
            $this->smppService->connect();
            return [
                'success' => true,
                'message' => 'Connected to SMPP'
            ];
        } catch (\Exception $e) {
            \Yii::error("SMPP connect failed: " . $e->getMessage(), __METHOD__);
            return [
                'success' => false,
                'message' => 'SMPP connect failed: ' . $e->getMessage()
            ];
        }
    }
    /**
     * Establish SMPP connection
     * @return array
     */
    public function disconnectSmpp(): array
    {
        try {
            $this->smppService->disconnect();
            return [
                'status' => 'success',
                'message' => 'Connected to SMPP'
            ];
        } catch (\Exception $e) {
            \Yii::error("SMPP connect failed: " . $e->getMessage(), __METHOD__);
            return [
                'status' => 'error',
                'message' => 'SMPP connect failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Send SMS via SMPP
     * @param string $phoneNumber Destination phone number
     * @param string $message SMS message content
     * @param string|null $sourceAddress Override source address
     * @return array SMS sending result
     */
    public function sendSms(string $phoneNumber, string $message, ?string $sourceAddress = null): array
    {
        $result = $this->smppService->sendSms($phoneNumber, $message, $sourceAddress);
        return $result;
    }


    /**
     * Get SMS delivery status (if supported by the provider)
     * @param string $messageId Message ID to check
     * @return array Delivery status
     */
    public function getDeliveryStatus(string $messageId): array
    {
        try {
            // This would typically query the SMPP provider's delivery receipt system
            // but for now we will return a placeholder response
            return [
                'status' => 'success',
                'data' => [
                    'message_id' => $messageId,
                    'delivery_status' => 'unknown',
                    'delivery_time' => null,
                    'error_code' => null
                ],
                'message' => 'Delivery status retrieved (placeholder)'
            ];
        } catch (\Exception $e) {
            \Yii::error("Failed to get delivery status: " . $e->getMessage(), __METHOD__);
            return [
                'status' => 'error',
                'data' => null,
                'message' => 'Failed to get delivery status: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Send SMS with delivery receipt request
     * This method is in case we want to request deliver recepits
     * @param string $phoneNumber Destination phone number
     * @param string $message SMS message content
     * @param string|null $sourceAddress Override source address
     * @return array SMS sending result with delivery receipt info
     */
    public function sendSmsWithReceipt(string $phoneNumber, string $message, ?string $sourceAddress = null): array
    {
        try {
            // Enable delivery receipts for this message
            $originalSetting = $this->smppService->enableDeliveryReceipts;
            $this->smppService->enableDeliveryReceipts = true;

            $result = $this->sendSms($phoneNumber, $message, $sourceAddress);

            // Restore original setting
            $this->smppService->enableDeliveryReceipts = $originalSetting;

            if ($result['status'] === 'success') {
                $result['data']['delivery_receipt_requested'] = true;
                $result['message'] = 'SMS sent with delivery receipt request';
            }

            return $result;
        } catch (\Exception $e) {
            \Yii::error("Tamimah SMS with receipt failed: " . $e->getMessage(), __METHOD__);
            return [
                'status' => 'error',
                'data' => null,
                'message' => 'Tamimah SMS with receipt failed: ' . $e->getMessage()
            ];
        }
    }
}
