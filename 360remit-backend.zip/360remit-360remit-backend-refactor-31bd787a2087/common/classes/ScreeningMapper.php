<?php

namespace common\classes;

// ====== MODEL CLASSES ======

class ScreeningResponse
{
    public ?string $ClientReference = null;
    /** @var ScreeningRecord[] */
    public array $Records = [];
}

class ScreeningRecord
{
    public ?int $Record = null;
    public ?RecordDetails $RecordDetails = null;
    public ?int $ResultID = null;
    public ?int $RunID = null;
    public ?Watchlist $Watchlist = null;
}

class RecordDetails
{
    public ?int $AcceptListID = null;
    public ?string $AccountAmount = null;
    public ?string $AccountGroupID = null;
    public ?string $AccountOtherData = null;
    public ?string $AccountProviderID = null;
    public ?string $AccountMemberID = null;
    public ?string $AccountType = null;
    public bool $AddedToAcceptList = false;
    /** @var AdditionalInfoItem[] */
    public array $AdditionalInfo = [];
    /** @var AddressItem[] */
    public array $Addresses = [];
    public ?string $PredefinedSearch = null;
    public ?int $PDSVersion = null;
    public ?string $Division = null;
    public ?string $DPPA = null;
    public ?string $EFTType = null;
    public ?string $EntityType = null;
    public ?string $Gender = null;
    public ?int $GLB = null;
    public ?string $LastUpdatedDate = null;
    public ?NameDetails $Name = null;
    public ?RecordState $RecordState = null;
    public ?string $SearchDate = null;
}

class AdditionalInfoItem
{
    public ?string $Type = null;
    public ?string $Value = null;
}

class AddressItem
{
    public ?string $City = null;
    public ?string $Country = null;
    public ?string $PostalCode = null;
    public ?string $Street2 = null;
    public ?string $Type = null;
}

class NameDetails
{
    public ?string $First = null;
    public ?string $Full = null;
    public ?string $Generation = null;
    public ?string $Last = null;
    public ?string $Middle = null;
    public ?string $Title = null;
}

class RecordState
{
    public bool $AddedToAcceptList = false;
    public ?string $AlertState = null;
    /** @var string[] */
    public array $AssignedTo = [];
    public ?string $AssignmentType = null;
    public ?string $Division = null;
    /** @var RecordHistoryItem[] */
    public array $History = [];
    /** @var MatchStateItem[] */
    public array $MatchStates = [];
    public ?string $Status = null;
}

class RecordHistoryItem
{
    public ?string $Date = null;
    public ?string $Event = null;
    public ?string $Note = null;
    public ?string $User = null;
}

class MatchStateItem
{
    public ?int $MatchID = null;
    public ?string $Type = null;
}

class Watchlist
{
    /** @var WatchlistMatch[] */
    public array $Matches = [];
}

class WatchlistMatch
{
    public ?int $AcceptListID = null;
    public bool $AddedToAcceptList = false;
    public bool $AddressName = false;
    public bool $AutoFalsePositive = false;
    public bool $BestAddressIsPartial = false;
    public ?string $BestCountry = null;
    public ?int $BestCountryScore = null;
    public ?string $BestCountryType = null;
    public bool $BestDOBIsPartial = false;
    public ?string $BestName = null;
    public ?int $BestNameScore = null;
    public ?int $CheckSum = null;
    public ?WatchlistConflicts $Conflicts = null;
    public ?EntityDetails $EntityDetails = null;
    public ?string $EntityName = null;
    public ?int $EntityScore = null;
    public ?string $EntityUniqueID = null;
    public bool $FalsePositive = false;
    public ?WatchlistFileInfo $File = null;
    public bool $GatewayOFACScreeningIndicatorMatch = false;
    public ?int $ID = null;
    public bool $MatchReAlert = false;
    public ?MatchXml $MatchXML = null;
    public ?int $PreviousResultID = null;
    public ?string $ReasonListed = null;
    public ?string $ResultDate = null;
    public bool $SecondaryOFACScreeningIndicatorMatch = false;
    public bool $TrueMatch = false;
    public ?string $FalseMatchUpdate = null;
    /** @var EnforcementItem[] */
    public array $Enforcements = [];
    /** @var SourceItem[] */
    public array $SourceItems = [];
    public ?string $DateModified = null;
    public ?string $Status = null;
    /** @var PepItem[] */
    public array $PEPs = [];
    /** @var MsbsItem[] */
    public array $MSBs = [];
    /** @var RelationshipItem[] */
    public array $Relationships = [];
    /** @var AdverseMediaItem[] */
    public array $AdverseMedias = [];
}

class WatchlistConflicts
{
    public bool $AddressConflict = false;
    public bool $CitizenshipConflict = false;
    public bool $CountryConflict = false;
    public bool $DOBConflict = false;
    public bool $EntityTypeConflict = false;
    public bool $GenderConflict = false;
    public bool $IDConflict = false;
    public bool $PhoneConflict = false;
}

class EntityDetails
{
    /** @var AdditionalInfoItem[] */
    public array $AdditionalInfo = [];
    /** @var EntityAddressItem[] */
    public array $Addresses = [];
    /** @var EntityAkaItem[] */
    public array $AKAs = [];
    public ?string $Comments = null;
    public ?string $DateListed = null;
    public ?string $EntityType = null;
    public ?string $Gender = null;
    /** @var EntityIdItem[] */
    public array $IDs = [];
    public ?string $ListReferenceNumber = null;
    public ?NameDetails $Name = null;
}

class EntityAddressItem
{
    public ?string $City = null;
    public ?string $Country = null;
    public ?int $ID = null;
    public ?string $PostalCode = null;
    public ?string $StateProvinceDistrict = null;
    public ?string $Street1 = null;
    public ?string $Street2 = null;
    public ?string $Type = null;
    public ?string $Category = null;
}

class EntityAkaItem
{
    public ?string $Category = null;
    public ?int $ID = null;
    public ?NameDetails $Name = null;
    public ?string $Type = null;
    public ?string $ScriptType = null;
}

class EntityIdItem
{
    public ?int $ID = null;
    public ?string $Number = null;
    public ?string $Type = null;
    public ?string $Issuer = null;
    public ?string $Label = null;
}

class WatchlistFileInfo
{
    public ?string $Build = null;
    public bool $Custom = false;
    public ?int $ID = null;
    public ?string $Name = null;
    public ?string $Published = null;
    public ?string $Type = null;
}

class MatchXml
{
    public ?MatchXmlGender $Gender = null;
}

class MatchXmlGender
{
    public ?string $Input = null;
    public ?string $List = null;
    public ?int $Score = null;
}

class EnforcementItem
{
    public ?string $Country = null;
    public ?string $Source = null;
    /** @var string[] */
    public array $SubCategories = [];
    public ?string $DateModified = null;
}

class SourceItem
{
    public ?string $SourceURI = null;
    public ?string $DateModified = null;
}

class PepItem
{
    public ?string $Country = null;
    public ?string $AdminUnit1 = null;
    /** @var string[] */
    public array $SubCategories = [];
    public ?string $AdminLevel = null;
    public ?string $DateModified = null;
    public ?string $Status = null;
    public bool $IsPrimary = false;
    public ?string $CountryRole = null;
    public ?string $GoverningInstitution = null;
    public ?string $GoverningRole = null;
    public ?string $EffectiveDateType = null;
    public ?string $EffectiveDate = null;
    public ?string $ExpirationDateType = null;
    public ?string $ExpirationDate = null;
}

class MsbsItem
{
    public ?string $Type = null;
    public ?string $Source = null;
    /** @var string[] */
    public array $SubCategories = [];
    public ?string $AuthorizedSignature = null;
    public ?string $ReceiveDate = null;
    public ?string $DateModified = null;
    public ?string $RegistrationType = null;
}

class RelationshipItem
{
    public ?string $Group = null;
    public ?string $Type = null;
    public ?int $EntityId = null;
    public ?string $DateModified = null;
    public ?string $EntityName = null;
    public float $OwnershipPercentage = 0.0;
    public ?string $Segments = null;
}

class AdverseMediaItem
{
    public ?string $Description = null;
    /** @var string[] */
    public array $SubCategories = [];
    public ?string $DateModified = null;
}

// ====== MAPPER CLASS ======
class ScreeningMapper
{
    public static function fromJson(string $json): ScreeningResponse
    {
        $data = json_decode($json, true);
        return self::mapRoot($data);
    }

    private static function mapRoot(array $data): ScreeningResponse
    {
        $root = new ScreeningResponse();
        $root->ClientReference = $data['ClientReference'] ?? null;

        foreach ($data['Records'] ?? [] as $rec) {
            $record = new ScreeningRecord();
            $record->Record = $rec['Record'] ?? null;
            $record->ResultID = $rec['ResultID'] ?? null;
            $record->RunID = $rec['RunID'] ?? null;

            if (isset($rec['RecordDetails'])) {
                $record->RecordDetails = self::mapRecordDetails($rec['RecordDetails']);
            }

            if (isset($rec['Watchlist'])) {
                $record->Watchlist = self::mapWatchlist($rec['Watchlist']);
            }

            $root->Records[] = $record;
        }

        return $root;
    }

    private static function mapRecordDetails(array $src): RecordDetails
    {
        $rd = new RecordDetails();
        $rd->AcceptListID = $src['AcceptListID'] ?? null;
        $rd->AccountAmount = $src['AccountAmount'] ?? null;
        $rd->AccountGroupID = $src['AccountGroupID'] ?? null;
        $rd->AccountOtherData = $src['AccountOtherData'] ?? null;
        $rd->AccountProviderID = $src['AccountProviderID'] ?? null;
        $rd->AccountMemberID = $src['AccountMemberID'] ?? null;
        $rd->AccountType = $src['AccountType'] ?? null;
        $rd->AddedToAcceptList = (bool)($src['AddedToAcceptList'] ?? false);
        $rd->PredefinedSearch = $src['PredefinedSearch'] ?? null;
        $rd->PDSVersion = $src['PDSVersion'] ?? null;
        $rd->Division = $src['Division'] ?? null;
        $rd->DPPA = $src['DPPA'] ?? null;
        $rd->EFTType = $src['EFTType'] ?? null;
        $rd->EntityType = $src['EntityType'] ?? null;
        $rd->Gender = $src['Gender'] ?? null;
        $rd->GLB = $src['GLB'] ?? null;
        $rd->LastUpdatedDate = $src['LastUpdatedDate'] ?? null;
        $rd->SearchDate = $src['SearchDate'] ?? null;

        // AdditionalInfo
        foreach ($src['AdditionalInfo'] ?? [] as $ai) {
            $item = new AdditionalInfoItem();
            $item->Type = $ai['Type'] ?? null;
            $item->Value = $ai['Value'] ?? null;
            $rd->AdditionalInfo[] = $item;
        }

        // Addresses
        foreach ($src['Addresses'] ?? [] as $ad) {
            $addr = new AddressItem();
            $addr->City = $ad['City'] ?? null;
            $addr->Country = $ad['Country'] ?? null;
            $addr->PostalCode = $ad['PostalCode'] ?? null;
            $addr->Street2 = $ad['Street2'] ?? null;
            $addr->Type = $ad['Type'] ?? null;
            $rd->Addresses[] = $addr;
        }

        // Name
        if (isset($src['Name'])) {
            $n = new NameDetails();
            $n->First = $src['Name']['First'] ?? null;
            $n->Full = $src['Name']['Full'] ?? null;
            $n->Generation = $src['Name']['Generation'] ?? null;
            $n->Last = $src['Name']['Last'] ?? null;
            $n->Middle = $src['Name']['Middle'] ?? null;
            $n->Title = $src['Name']['Title'] ?? null;
            $rd->Name = $n;
        }

        // RecordState
        if (isset($src['RecordState'])) {
            $rd->RecordState = self::mapRecordState($src['RecordState']);
        }

        return $rd;
    }

    private static function mapRecordState(array $src): RecordState
    {
        $rs = new RecordState();
        $rs->AddedToAcceptList = (bool)($src['AddedToAcceptList'] ?? false);
        $rs->AlertState = $src['AlertState'] ?? null;
        $rs->AssignedTo = $src['AssignedTo'] ?? [];
        $rs->AssignmentType = $src['AssignmentType'] ?? null;
        $rs->Division = $src['Division'] ?? null;
        $rs->Status = $src['Status'] ?? null;

        foreach ($src['History'] ?? [] as $h) {
            $hi = new RecordHistoryItem();
            $hi->Date = $h['Date'] ?? null;
            $hi->Event = $h['Event'] ?? null;
            $hi->Note = $h['Note'] ?? null;
            $hi->User = $h['User'] ?? null;
            $rs->History[] = $hi;
        }

        foreach ($src['MatchStates'] ?? [] as $m) {
            $ms = new MatchStateItem();
            $ms->MatchID = $m['MatchID'] ?? null;
            $ms->Type = $m['Type'] ?? null;
            $rs->MatchStates[] = $ms;
        }

        return $rs;
    }

    private static function mapWatchlist(array $src): Watchlist
    {
        $w = new Watchlist();
        foreach ($src['Matches'] ?? [] as $m) {
            $w->Matches[] = self::mapWatchlistMatch($m);
        }
        return $w;
    }

    private static function mapWatchlistMatch(array $src): WatchlistMatch
    {
        $wm = new WatchlistMatch();
        $wm->AcceptListID = $src['AcceptListID'] ?? null;
        $wm->AddedToAcceptList = (bool)($src['AddedToAcceptList'] ?? false);
        $wm->AddressName = (bool)($src['AddressName'] ?? false);
        $wm->AutoFalsePositive = (bool)($src['AutoFalsePositive'] ?? false);
        $wm->BestAddressIsPartial = (bool)($src['BestAddressIsPartial'] ?? false);
        $wm->BestCountry = $src['BestCountry'] ?? null;
        $wm->BestCountryScore = $src['BestCountryScore'] ?? null;
        $wm->BestCountryType = $src['BestCountryType'] ?? null;
        $wm->BestDOBIsPartial = (bool)($src['BestDOBIsPartial'] ?? false);
        $wm->BestName = $src['BestName'] ?? null;
        $wm->BestNameScore = $src['BestNameScore'] ?? null;
        $wm->CheckSum = $src['CheckSum'] ?? null;
        $wm->EntityName = $src['EntityName'] ?? null;
        $wm->EntityScore = $src['EntityScore'] ?? null;
        $wm->EntityUniqueID = $src['EntityUniqueID'] ?? null;
        $wm->FalsePositive = (bool)($src['FalsePositive'] ?? false);
        $wm->GatewayOFACScreeningIndicatorMatch = (bool)($src['GatewayOFACScreeningIndicatorMatch'] ?? false);
        $wm->ID = $src['ID'] ?? null;
        $wm->MatchReAlert = (bool)($src['MatchReAlert'] ?? false);
        $wm->PreviousResultID = $src['PreviousResultID'] ?? null;
        $wm->ReasonListed = $src['ReasonListed'] ?? null;
        $wm->ResultDate = $src['ResultDate'] ?? null;
        $wm->SecondaryOFACScreeningIndicatorMatch = (bool)($src['SecondaryOFACScreeningIndicatorMatch'] ?? false);
        $wm->TrueMatch = (bool)($src['TrueMatch'] ?? false);
        $wm->FalseMatchUpdate = $src['FalseMatchUpdate'] ?? null;
        $wm->DateModified = $src['DateModified'] ?? null;
        $wm->Status = $src['Status'] ?? null;

        if (isset($src['Conflicts'])) {
            $c = new WatchlistConflicts();
            $c->AddressConflict = (bool)($src['Conflicts']['AddressConflict'] ?? false);
            $c->CitizenshipConflict = (bool)($src['Conflicts']['CitizenshipConflict'] ?? false);
            $c->CountryConflict = (bool)($src['Conflicts']['CountryConflict'] ?? false);
            $c->DOBConflict = (bool)($src['Conflicts']['DOBConflict'] ?? false);
            $c->EntityTypeConflict = (bool)($src['Conflicts']['EntityTypeConflict'] ?? false);
            $c->GenderConflict = (bool)($src['Conflicts']['GenderConflict'] ?? false);
            $c->IDConflict = (bool)($src['Conflicts']['IDConflict'] ?? false);
            $c->PhoneConflict = (bool)($src['Conflicts']['PhoneConflict'] ?? false);
            $wm->Conflicts = $c;
        }

        if (isset($src['EntityDetails'])) {
            $wm->EntityDetails = self::mapEntityDetails($src['EntityDetails']);
        }

        if (isset($src['File'])) {
            $f = new WatchlistFileInfo();
            $f->Build = $src['File']['Build'] ?? null;
            $f->Custom = (bool)($src['File']['Custom'] ?? false);
            $f->ID = $src['File']['ID'] ?? null;
            $f->Name = $src['File']['Name'] ?? null;
            $f->Published = $src['File']['Published'] ?? null;
            $f->Type = $src['File']['Type'] ?? null;
            $wm->File = $f;
        }

        if (isset($src['MatchXML']['Gender'])) {
            $g = new MatchXmlGender();
            $g->Input = $src['MatchXML']['Gender']['Input'] ?? null;
            $g->List = $src['MatchXML']['Gender']['List'] ?? null;
            $g->Score = $src['MatchXML']['Gender']['Score'] ?? null;

            $mx = new MatchXml();
            $mx->Gender = $g;
            $wm->MatchXML = $mx;
        }

        // Enforcements
        foreach ($src['Enforcements'] ?? [] as $enf) {
            $e = new EnforcementItem();
            $e->Country = $enf['Country'] ?? null;
            $e->Source = $enf['Source'] ?? null;
            $e->SubCategories = $enf['SubCategories'] ?? [];
            $e->DateModified = $enf['DateModified'] ?? null;
            $wm->Enforcements[] = $e;
        }

        // SourceItems
        foreach ($src['SourceItems'] ?? [] as $si) {
            $s = new SourceItem();
            $s->SourceURI = $si['SourceURI'] ?? null;
            $s->DateModified = $si['DateModified'] ?? null;
            $wm->SourceItems[] = $s;
        }

        // PEPs
        foreach ($src['PEPs'] ?? [] as $p) {
            $pp = new PepItem();
            $pp->Country = $p['Country'] ?? null;
            $pp->AdminUnit1 = $p['AdminUnit1'] ?? null;
            $pp->SubCategories = $p['SubCategories'] ?? [];
            $pp->AdminLevel = $p['AdminLevel'] ?? null;
            $pp->DateModified = $p['DateModified'] ?? null;
            $pp->Status = $p['Status'] ?? null;
            $pp->IsPrimary = (bool)($p['IsPrimary'] ?? false);
            $pp->CountryRole = $p['CountryRole'] ?? null;
            $pp->GoverningInstitution = $p['GoverningInstitution'] ?? null;
            $pp->GoverningRole = $p['GoverningRole'] ?? null;
            $pp->EffectiveDateType = $p['EffectiveDateType'] ?? null;
            $pp->EffectiveDate = $p['EffectiveDate'] ?? null;
            $pp->ExpirationDateType = $p['ExpirationDateType'] ?? null;
            $pp->ExpirationDate = $p['ExpirationDate'] ?? null;
            $wm->PEPs[] = $pp;
        }

        // MSBs
        foreach ($src['MSBs'] ?? [] as $m) {
            $mm = new MsbsItem();
            $mm->Type = $m['Type'] ?? null;
            $mm->Source = $m['Source'] ?? null;
            $mm->SubCategories = $m['SubCategories'] ?? [];
            $mm->AuthorizedSignature = $m['AuthorizedSignature'] ?? null;
            $mm->ReceiveDate = $m['ReceiveDate'] ?? null;
            $mm->DateModified = $m['DateModified'] ?? null;
            $mm->RegistrationType = $m['RegistrationType'] ?? null;
            $wm->MSBs[] = $mm;
        }

        // Relationships
        foreach ($src['Relationships'] ?? [] as $r) {
            $rr = new RelationshipItem();
            $rr->Group = $r['Group'] ?? null;
            $rr->Type = $r['Type'] ?? null;
            $rr->EntityId = $r['EntityId'] ?? null;
            $rr->DateModified = $r['DateModified'] ?? null;
            $rr->EntityName = $r['EntityName'] ?? null;
            $rr->OwnershipPercentage = isset($r['OwnershipPercentage']) ? (float)$r['OwnershipPercentage'] : 0.0;
            $rr->Segments = $r['Segments'] ?? null;
            $wm->Relationships[] = $rr;
        }

        // AdverseMedias
        foreach ($src['AdverseMedias'] ?? [] as $a) {
            $am = new AdverseMediaItem();
            $am->Description = $a['Description'] ?? null;
            $am->SubCategories = $a['SubCategories'] ?? [];
            $am->DateModified = $a['DateModified'] ?? null;
            $wm->AdverseMedias[] = $am;
        }

        return $wm;
    }

    private static function mapEntityDetails(array $src): EntityDetails
    {
        $ed = new EntityDetails();

        foreach ($src['AdditionalInfo'] ?? [] as $ai) {
            $item = new AdditionalInfoItem();
            $item->Type = $ai['Type'] ?? null;
            $item->Value = $ai['Value'] ?? null;
            $ed->AdditionalInfo[] = $item;
        }

        foreach ($src['Addresses'] ?? [] as $a) {
            $ea = new EntityAddressItem();
            $ea->City = $a['City'] ?? null;
            $ea->Country = $a['Country'] ?? null;
            $ea->ID = $a['ID'] ?? null;
            $ea->PostalCode = $a['PostalCode'] ?? null;
            $ea->StateProvinceDistrict = $a['StateProvinceDistrict'] ?? null;
            $ea->Street1 = $a['Street1'] ?? null;
            $ea->Street2 = $a['Street2'] ?? null;
            $ea->Type = $a['Type'] ?? null;
            $ea->Category = $a['Category'] ?? null;
            $ed->Addresses[] = $ea;
        }

        foreach ($src['AKAs'] ?? [] as $aka) {
            $ak = new EntityAkaItem();
            $ak->Category = $aka['Category'] ?? null;
            $ak->ID = $aka['ID'] ?? null;
            if (isset($aka['Name'])) {
                $n = new NameDetails();
                $n->Full = $aka['Name']['Full'] ?? null;
                $n->Last = $aka['Name']['Last'] ?? null;
                $ak->Name = $n;
            }
            $ak->Type = $aka['Type'] ?? null;
            $ak->ScriptType = $aka['ScriptType'] ?? null;
            $ed->AKAs[] = $ak;
        }

        $ed->Comments = $src['Comments'] ?? null;
        $ed->DateListed = $src['DateListed'] ?? null;
        $ed->EntityType = $src['EntityType'] ?? null;
        $ed->Gender = $src['Gender'] ?? null;

        foreach ($src['IDs'] ?? [] as $id) {
            $ei = new EntityIdItem();
            $ei->ID = $id['ID'] ?? null;
            $ei->Number = $id['Number'] ?? null;
            $ei->Type = $id['Type'] ?? null;
            $ei->Issuer = $id['Issuer'] ?? null;
            $ei->Label = $id['Label'] ?? null;
            $ed->IDs[] = $ei;
        }

        $ed->ListReferenceNumber = $src['ListReferenceNumber'] ?? null;

        if (isset($src['Name'])) {
            $n = new NameDetails();
            $n->First = $src['Name']['First'] ?? null;
            $n->Full = $src['Name']['Full'] ?? null;
            $n->Last = $src['Name']['Last'] ?? null;
            $ed->Name = $n;
        }

        return $ed;
    }
}
