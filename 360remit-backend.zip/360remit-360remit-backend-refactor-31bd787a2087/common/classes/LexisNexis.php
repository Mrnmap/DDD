<?php

namespace common\classes;

use Exception;
use GuzzleHttp\Client;
use common\models\ComplianceScreening;
use common\classes\ScreeningResponse;
use common\classes\ScreeningMapper;

class LexisNexis
{
    private $clientId;
    private $userId;
    private $password;
    private $apiKey;
    private $baseUrl;

    const COMPLIANCE_CHECK_ENABLED = true;
    const BLOCK_REGISTRATION_ON_FAILURE = false;

    function __construct($config = [])
    {
        // LexisNexis Bridger API credentials
        $this->clientId = $_ENV["LN_CLIENT_ID"];
        $this->userId = $_ENV["LN_USER_ID"];
        $this->password = $_ENV["LN_PASSWORD"];
        $this->apiKey = $_ENV["LN_API_KEY"];
        $this->baseUrl = $_ENV["LN_BASE_URL"];
    }

    /**
     * Perform compliance screening for customer data
     * @param array $customerData Customer information for screening
     * @param int|null $userID User ID for audit logging
     * @return array Compliance screening results
     */
    public function performComplianceScreening(array $customerData, $userID = null): array
    {
        try {
            // Check if compliance checking is enabled
            if (!self::COMPLIANCE_CHECK_ENABLED) {
                \Yii::info("LexisNexis compliance check is disabled", __METHOD__);
                $result = $this->buildComplianceResult('disabled', null, 'Compliance check is disabled', true, 'Compliance check disabled', 'unknown');
                $this->saveComplianceScreening($customerData, $result, $userID);
                return $this->buildResponse('success', $result, 'LexisNexis compliance screening completed (disabled)');
            }

            // Perform LexisNexis search
            $searchResult = $this->performSearch($customerData);
            $complianceResult = $this->checkCompliance($searchResult);
            $result = $this->buildComplianceResult('success', $searchResult, 'Search completed', $complianceResult['passed'], $complianceResult['reason'], $complianceResult['risk_level'], $complianceResult['match_details'] ?? []);

            $this->saveComplianceScreening($customerData, $result, $userID);
            return $this->buildResponse('success', $result, 'LexisNexis compliance screening completed');
        } catch (\Exception $e) {
            \Yii::error("LexisNexis compliance screening failed: " . $e->getMessage(), __METHOD__);

            $result = $this->buildComplianceResult('error', null, 'Compliance check failed: ' . $e->getMessage(), !self::BLOCK_REGISTRATION_ON_FAILURE, 'Compliance check service unavailable', 'unknown');
            $this->saveComplianceScreening($customerData, $result, $userID);

            return $this->buildResponse('error', $result, 'LexisNexis compliance screening failed: ' . $e->getMessage());
        }
    }

    /**
     * Build standardized compliance result structure
     */
    private function buildComplianceResult(string $status, $searchData, string $message, bool $passed, string $reason, string $riskLevel, array $matchDetails = []): array
    {
        return [
            'search_result' => [
                'status' => $status,
                'data' => $searchData,
                'message' => $message
            ],
            'compliance' => [
                'passed' => $passed,
                'reason' => $reason,
                'risk_level' => $riskLevel,
                'match_details' => $matchDetails
            ],
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * Build standardized response structure
     */
    private function buildResponse(string $status, array $data, string $message): array
    {
        return [
            'status' => $status,
            'data' => $data,
            'message' => $message
        ];
    }

    /**
     * Perform a direct search using LexisNexis API
     * @param array $searchParams Search parameters
     * @return array Search results
     */
    public function performSearch(array $searchParams): array
    {
        try {
            $payload = $this->buildSearchPayload($searchParams);
            //$str = json_encode($payload);
            $searchResult = $this->search($payload);

            return [
                'status' => 'success',
                'data' => $searchResult,
                'message' => 'LexisNexis search completed successfully'
            ];
        } catch (\Exception $e) {
            \Yii::error("LexisNexis search failed: " . $e->getMessage(), __METHOD__);
            return [
                'status' => 'error',
                'data' => null,
                'message' => 'LexisNexis search failed: ' . $e->getMessage()
            ];
        }
    }


    /**
     * Build search payload for LexisNexis API
     * @param array $params Search parameters
     * @return array Formatted payload
     */
    private function buildSearchPayload(array $params): array
    {
        // $dobParts = explode('-', $params['dob']);
        // if (count($dobParts) !== 3) {
        //     throw new \InvalidArgumentException("DOB must be in YYYY-MM-DD format.");
        // }

        // list($year, $month, $day) = array_map('intval', $dobParts);

        return [
            'ClientContext' => [
                'ClientReference' => $params['clientReference'],
            ],
            'SearchConfiguration' => [
                'AssignResultTo' => [
                    'Division' => 'Default Division',
                    'EmailNotification' => true,
                    'RolesOrUsers' => [
                        $this->userId
                    ],
                    'Type' => 'User'
                ],
                'DuplicateMatchSuppressionSameDivisionOnly' => true,
                'WriteResultsToDatabase' => true,
                'PredefinedSearchName' => 'Pre-defined Search'
            ],
            'SearchInput' => [
                'Records' => [[
                    'Entity' => [
                        'EntityType' => 'Individual',
                        'Gender' => $params['gender'] ?? 'Male',
                        'Name' => [
                            'First' => $params['firstName'],
                            'Middle' => $params['middleName'] ?? '',
                            'Last' => $params['lastName']
                        ],
                        'AdditionalInfo' => [
                            // [
                            //     'Date' => [
                            //         'Day' => $day,
                            //         'Month' => $month,
                            //         'Year' => $year
                            //     ],
                            //     'Type' => 'DOB'
                            // ],
                            // [
                            //     'Type' => 'PlaceOfBirth',
                            //     'Value' => $params['placeOfBirth']
                            // ]
                        ],
                        'Addresses' => [[
                            'Street1' => $params['street1'],
                            'Street2' => $params['street2'] ?? '',
                            'City' => $params['city'],
                            'PostalCode' => $params['postalCode'],
                            'Type' => 'Current',
                            'Country' => $params['country']
                        ]],
                        'IDs' => [[
                            'Number' => $params['accountNumber'],
                            'Type' => 'Account'
                        ]]
                    ]
                ]]
            ]
        ];
    }

    /**
     * Issue JWT token from LexisNexis API
     * @return string|null Access token
     */
    private function issueToken(): ?string
    {
        $client = new Client();

        $authUser = $this->clientId . '/' . $this->userId;
        $response = $client->post($this->baseUrl . '/Token/Issue', [
            'headers' => [
                'X-API-Key' => $this->apiKey
            ],
            'auth' => [$authUser, $this->password]
        ]);

        $data = json_decode($response->getBody()->getContents(), true);
        return $data['access_token'] ?? null;
    }

    /**
     * Perform search using LexisNexis API
     * @param array $payload Search payload
     * @return array Search results
     */
    private function search(array $payload): array
    {
        $token = $this->issueToken();
        if (!$token) {
            throw new \Exception("Failed to retrieve LexisNexis JWT.");
        }

        $client = new Client();

        $response = $client->post($this->baseUrl . '/Lists/Search', [
            'headers' => [
                'Authorization' => "Bearer {$token}",
                'X-API-Key' => $this->apiKey,
                'Content-Type' => 'application/json'
            ],
            'json' => $payload
        ]);

        return json_decode($response->getBody()->getContents(), true);
    }

    /**
     * Check if customer passes compliance check
     * @param array $searchResult Result from performSearch
     * @return array Compliance status
     */
    private function checkCompliance(array $searchResult): array
    {
        if ($searchResult['status'] !== 'success') {
            return [
                'passed' => false,
                'reason' => 'Search failed: ' . $searchResult['message'],
                'risk_level' => 'high'
            ];
        }

        $data = $searchResult['data'];

        // Check for matches in the search results
        $hasMatches = false;
        $riskLevel = 'low';
        $matchDetails = [];

        if (isset($data['SearchResults']) && is_array($data['SearchResults'])) {
            foreach ($data['SearchResults'] as $result) {
                if (isset($result['Matches']) && !empty($result['Matches'])) {
                    $hasMatches = true;
                    $riskLevel = 'high';
                    $matchDetails[] = $result['Matches'];
                }
            }
        }

        return [
            'passed' => !$hasMatches,
            'reason' => $hasMatches ? 'Customer found in sanctions/watchlists' : 'No adverse findings',
            'risk_level' => $riskLevel,
            'match_details' => $matchDetails
        ];
    }

    /**
     * Save compliance screening results to database
     * @param array $customerData Original customer data
     * @param array $complianceResult Complete compliance result
     * @param int|null $userID User ID who initiated the screening
     */
    private function saveComplianceScreening(array $customerData, array $complianceResult, $userID = null): void
    {
        try {
            // Extract internal reference
            $internalReference = $this->extractInternalReference($complianceResult, $customerData);

            // Check for duplicate
            $existingRecord = ComplianceScreening::find()
                ->where(['internal_reference' => $internalReference])
                ->one();

            if ($existingRecord) {
                \Yii::info("Compliance screening record already exists for reference: $internalReference", __METHOD__);
                return;
            }

            // Extract all compliance data in one pass
            $extractedData = $this->extractComplianceData($complianceResult);

            // Populate model
            $screening = new ComplianceScreening();
            $screening->internal_reference = $internalReference;
            $screening->screened_by = $this->getScreenedBy($userID);
            $screening->screening_timestamp = date('Y-m-d H:i:s');
            $screening->screening_result = $this->determineScreeningResult($complianceResult, $extractedData);
            $screening->entity_type = $extractedData['entity_type'];
            $screening->entity_score = $extractedData['entity_score'];
            $screening->watchlist_source = $extractedData['watchlist_source'];
            $screening->response_summary = $this->generateResponseSummary($complianceResult, $extractedData);
            $screening->raw_response = json_encode($complianceResult, JSON_PRETTY_PRINT);

            // Save & handle failure
            if (!$screening->save()) {
                $errors = $screening->getErrors();
                $jsonErrors = json_encode($errors, JSON_PRETTY_PRINT);
                if ($jsonErrors === false) {
                    \Yii::error("Failed to encode screening errors: " . json_last_error_msg(), __METHOD__);
                    \Yii::error("Raw errors: " . print_r($errors, true), __METHOD__);
                } else {
                    \Yii::error("Failed to save compliance screening record: $jsonErrors", __METHOD__);
                }
            } else {
                \Yii::info("Compliance screening record saved successfully for reference: $internalReference", __METHOD__);
            }
        } catch (\Exception $e) {
            \Yii::error("Error saving compliance screening record: " . $e->getMessage(), __METHOD__);
        }
    }

    /**
     * Extract internal reference from compliance result or customer data
     */
    private function extractInternalReference(array $complianceResult, array $customerData): string
    {
        // Try to get ClientReference from the response
        if (isset($complianceResult['search_result']['data']['ClientReference'])) {
            return $complianceResult['search_result']['data']['ClientReference'];
        }

        // Fallback to clientReference from customer data
        if (isset($customerData['clientReference'])) {
            return $customerData['clientReference'];
        }

        // Generate a fallback reference
        return 'AUTO_' . date('YmdHis') . '_' . substr(md5(json_encode($customerData)), 0, 8);
    }

    /**
     * Determine who performed the screening
     */
    private function getScreenedBy($userID): string
    {
        if ($userID) {
            return "User_ID_{$userID}";
        }

        return "System_360Remit";
    }

    /**
     * Determine the screening result based on compliance data
     */
    private function determineScreeningResult(array $complianceResult, array $extractedData = null): string
    {
        $searchResult = $complianceResult['search_result'] ?? [];
        $compliance = $complianceResult['compliance'] ?? [];

        // Check if there was an error
        if ($searchResult['status'] === 'error') {
            return ComplianceScreening::RESULT_ERROR;
        }

        // Check if compliance check was disabled
        if ($searchResult['status'] === 'disabled') {
            return ComplianceScreening::RESULT_NO_MATCH; // Treat as no match when disabled
        }

        // Check compliance status
        if (!isset($compliance['passed']) || !$compliance['passed']) {
            // Check if there are matches
            if (isset($compliance['match_details']) && !empty($compliance['match_details'])) {
                // Check if it's marked as false positive using extracted data
                if ($extractedData && $extractedData['has_auto_false_positive']) {
                    return ComplianceScreening::RESULT_FALSE_POSITIVE;
                }
                return ComplianceScreening::RESULT_MATCH;
            }
            return ComplianceScreening::RESULT_PENDING_REVIEW;
        }

        return ComplianceScreening::RESULT_NO_MATCH;
    }

    /**
     * Extract all relevant data from compliance result in a single pass
     */
    private function extractComplianceData(array $complianceResult): array
    {
        $data = $complianceResult['search_result']['data'] ?? [];
        $extracted = [
            'entity_type' => 'Individual', // Default fallback
            'entity_score' => null,
            'watchlist_source' => 'LexisNexis WorldCompliance',
            'has_auto_false_positive' => false,
            'total_matches' => 0,
            'false_positives' => 0,
            'max_entity_score' => null
        ];

        if (!isset($data['Records']) || !is_array($data['Records'])) {
            return $extracted;
        }

        foreach ($data['Records'] as $index => $record) {
            // Extract entity type from first record
            if ($index === 0) {
                if (isset($record['RecordDetails']['EntityType'])) {
                    $extracted['entity_type'] = $record['RecordDetails']['EntityType'];
                }
                if (isset($record['RecordDetails']['PredefinedSearch'])) {
                    $extracted['watchlist_source'] = $record['RecordDetails']['PredefinedSearch'];
                }
            }

            // Process matches
            if (isset($record['Watchlist']['Matches'])) {
                $matches = $record['Watchlist']['Matches'];
                $extracted['total_matches'] += count($matches);

                foreach ($matches as $matchIndex => $match) {
                    // Extract entity score
                    if (isset($match['EntityScore'])) {
                        $score = (int)$match['EntityScore'];
                        if ($extracted['max_entity_score'] === null || $score > $extracted['max_entity_score']) {
                            $extracted['max_entity_score'] = $score;
                        }
                    }

                    // Check for auto false positive
                    if (isset($match['AutoFalsePositive']) && $match['AutoFalsePositive'] === true) {
                        $extracted['has_auto_false_positive'] = true;
                        $extracted['false_positives']++;
                    }

                    // Extract watchlist source from first match if not already set
                    if ($index === 0 && $matchIndex === 0 && $extracted['watchlist_source'] === 'LexisNexis WorldCompliance') {
                        if (isset($match['File']['Name'])) {
                            $extracted['watchlist_source'] = $match['File']['Name'];
                        }
                    }
                }
            }
        }

        // Use max_entity_score as entity_score for backward compatibility
        $extracted['entity_score'] = $extracted['max_entity_score'];

        return $extracted;
    }

    /**
     * Generate a human-readable summary of the screening results
     */
    private function generateResponseSummary(array $complianceResult, array $extractedData = null): string
    {
        $compliance = $complianceResult['compliance'] ?? [];
        $searchResult = $complianceResult['search_result'] ?? [];

        $summary = [];

        // Add basic status
        $summary[] = "Status: " . ($compliance['passed'] ? 'PASSED' : 'FAILED');
        $summary[] = "Risk Level: " . strtoupper($compliance['risk_level'] ?? 'unknown');
        $summary[] = "Reason: " . ($compliance['reason'] ?? 'No reason provided');

        // Add match information using extracted data if available
        if ($extractedData) {
            $data = $searchResult['data'] ?? [];
            if (isset($data['Records'])) {
                $totalRecords = count($data['Records']);
                $summary[] = "Records Processed: $totalRecords";
            }

            if ($extractedData['total_matches'] > 0) {
                $summary[] = "Total Matches Found: " . $extractedData['total_matches'];
                if ($extractedData['false_positives'] > 0) {
                    $summary[] = "Auto False Positives: " . $extractedData['false_positives'];
                }
                if ($extractedData['max_entity_score'] !== null) {
                    $summary[] = "Highest Entity Score: " . $extractedData['max_entity_score'];
                }
            }
        }

        // Add timestamp
        $summary[] = "Screened At: " . ($complianceResult['timestamp'] ?? date('Y-m-d H:i:s'));

        return implode(' | ', $summary);
    }
}
