<?php

namespace common\services;

use common\utility\Helpers;
use Yii;
use yii\base\Component;
use yii\base\Exception;
use Smpp\Client;
use Smpp\Pdu\Address;
use Smpp\Transport\SocketTransport;
use Smpp\Configs\SocketTransportConfig;
use Smpp\Utils\Network\Entry;
use Smpp\Smpp;
use yii\db\Expression;

/**
 * SMPP Service for SMS delivery
 * Handles connection to SMPP server and SMS sending
 */
class SmppService extends Component
{

    public $host;
    public $port = 2772;
    public $username;
    public $password;
    public $systemId;
    public $systemType = 'SMS';
    public $timeout = 30;
    public $sourceAddress;
    public $sourceAddressTon = Smpp::TON_ALPHANUMERIC;
    public $sourceAddressNpi = Smpp::NPI_UNKNOWN;
    public $destAddressTon = Smpp::TON_INTERNATIONAL;
    public $destAddressNpi = Smpp::NPI_E164;
    public $dataCoding = Smpp::DATA_CODING_DEFAULT;
    public $validityPeriod = 86400; // 24 hours
    public $enableDeliveryReceipts = true;
    public $debug = false;

    /**
     * @var Client SMPP client instance
     */
    private $client;
    private $connected = false;
    private $stats = [
        'messages_sent' => 0,
        'messages_failed' => 0,
        'connection_errors' => 0,
        'last_activity' => null
    ];

    public function init()
    {
        try {
            parent::init();
            // Load configuration from params
            $this->loadConfig();

            // Validate required configuration
            $this->validateConfig();
        } catch (Expression $e) {
            return Helpers::errorResponse(500, $e->getMessage(), []);
        }
    }

    /**
     * Load SMPP configuration from Yii params
     */
    private function loadConfig()
    {
        $smppConfig = Yii::$app->params['smpp'] ?? [];

        $this->host = $_ENV["SMS_HOST"];
        $this->port = $_ENV["SMS_PORT"];
        $this->username = $_ENV["SMS_USERNAME"];
        $this->password = $_ENV["SMS_PASSWORD"];
        $this->systemId = $_ENV["SMS_SYSTEM_ID"];
        $this->systemType = $smppConfig['system_type'] ?? $this->systemType;
        $this->timeout = $smppConfig['timeout'] ?? $this->timeout;
        $this->sourceAddress = $_ENV["SMS_SOURCE_ADDRESS"];
        $this->sourceAddressTon = $smppConfig['source_address_ton'] ?? $this->sourceAddressTon;
        $this->sourceAddressNpi = $smppConfig['source_address_npi'] ?? $this->sourceAddressNpi;
        $this->destAddressTon = $smppConfig['dest_address_ton'] ?? $this->destAddressTon;
        $this->destAddressNpi = $smppConfig['dest_address_npi'] ?? $this->destAddressNpi;
        $this->dataCoding = $smppConfig['data_coding'] ?? $this->dataCoding;
        $this->validityPeriod = $smppConfig['validity_period'] ?? $this->validityPeriod;
        $this->enableDeliveryReceipts = $smppConfig['enable_delivery_receipts'] ?? $this->enableDeliveryReceipts;
    }

    /**
     * Validate required configuration
     * @throws Exception
     */
    private function validateConfig()
    {
        $required = ['host', 'username', 'password', 'sourceAddress'];

        foreach ($required as $field) {
            if (empty($this->$field)) {
                throw new Exception("SMPP configuration missing required field: {$field}");
            }
        }
    }

    /**
     * Connect to SMPP server
     * @return bool
     */
    public function connect()
    {
        try {
            if ($this->connected) {
                return true;
            }

            if ($this->debug) {
                echo "Connecting to SMPP server: {$this->host}:{$this->port}\n";
            }

            // Create network entry
            $entry = new Entry($this->port, $this->host);

            // Create socket transport config
            $config = new SocketTransportConfig();
            // Create socket transport
            $transport = new SocketTransport([$entry], $config);

            // Create SMPP client
            $this->client = new Client($transport, $this->systemId, $this->password);

            if ($this->debug) {
                echo "Attempting to bind as transmitter\n";
            }

            // --- connect() ---
            // Bind as transmitter (for sending SMS)
            $this->client->bindTransmitter();
            // Bind as transceiver so we can receive deliver_sm & keepalives
            //$this->client->bindTransceiver();

            $this->connected = true;
            $this->stats['last_activity'] = time();

            Yii::info("Successfully connected to SMPP server", __METHOD__);

            return true;
        } catch (\Exception $e) {
            $this->connected = false;
            $this->stats['connection_errors']++;

            Yii::error("SMPP connection failed: " . $e->getMessage(), __METHOD__);
            return false;
        }
    }

    /**
     * Disconnect from SMPP server
     */
    public function disconnect()
    {
        try {
            if ($this->client && $this->connected) {
                $this->client->close();
                $this->connected = false;
                Yii::info("Disconnected from SMPP server", __METHOD__);
            }
        } catch (\Exception $e) {
            Yii::error("Error disconnecting from SMPP server: " . $e->getMessage(), __METHOD__);
        }
    }

    /**
     * Send SMS via SMPP
     * 
     * @param string $phoneNumber Destination phone number
     * @param string $message SMS message content
     * @param string|null $sourceAddress Override source address
     * @return array Result with success status and message ID
     */
    public function sendSms($phoneNumber, $message, $sourceAddress = null)
    {
        try {
            // Ensure connection
            if (!$this->connected) {
                $this->connect();
            }

            // Normalize phone number
            $phoneNumber = $this->normalizePhoneNumber($phoneNumber);

            // Use provided source address or default
            $sourceAddr = $sourceAddress ?? $this->sourceAddress;

            Yii::info("Sending SMS to {$phoneNumber}: " . substr($message, 0, 50) . "...", __METHOD__);

            // Create address objects
            $fromAddress = new Address($sourceAddr, $this->sourceAddressTon, $this->sourceAddressNpi);
            $toAddress = new Address($phoneNumber, $this->destAddressTon, $this->destAddressNpi);
            // Try without delivery receipts first
            $originalDeliveryReceipts = $this->enableDeliveryReceipts;
            $this->enableDeliveryReceipts = false;

            $messageId = $this->client->sendSMS(
                $fromAddress,
                $toAddress,
                $message,
                null, // tags
                $this->dataCoding,
                0x00, // priority
                null, // schedule delivery time
                $this->validityPeriod // validity period
            );
            // Drain a bit so we read submit_sm_resp / enquire_link / early DLRs
            $this->drain(1500);
            $this->enableDeliveryReceipts = $originalDeliveryReceipts;

            if ($messageId === false) {
                throw new Exception("SMS sending failed - server returned false");
            }


            $this->stats['messages_sent']++;
            $this->stats['last_activity'] = time();

            Yii::info("SMS sent successfully with message ID: {$messageId}", __METHOD__);

            return [
                'success' => true,
                'message_id' => $messageId,
                'message' => 'SMS sent successfully',
                'partner_reference' => $messageId
            ];
        } catch (\Exception $e) {
            if ($this->debug) {
                echo "SMS sendSMS exception: " . $e->getMessage() . "\n";
                echo "Exception class: " . get_class($e) . "\n";
                if (method_exists($e, 'getCode')) {
                    echo "Exception code: " . $e->getCode() . "\n";
                }
            }
            $this->stats['messages_failed']++;
            Yii::error("SMS sending failed: " . $e->getMessage(), __METHOD__);
            return [
                'success' => false,
                'message_id' => null,
                'message' => 'SMS sending failed: ' . $e->getMessage(),
                'partner_reference' => null
            ];
        }
    }

    /**
     * Send multiple SMS messages in batch 
     * TODO LATER: test this function
     * 
     * @param array $messages Array of ['phone' => 'number', 'message' => 'text']
     * @return array Results for each message
     */
    public function sendBatchSms($messages)
    {
        $results = [];

        foreach ($messages as $index => $messageData) {
            $phoneNumber = $messageData['phone'] ?? '';
            $message = $messageData['message'] ?? '';

            if (empty($phoneNumber) || empty($message)) {
                $results[$index] = [
                    'success' => false,
                    'message' => 'Invalid message data',
                    'partner_reference' => null
                ];
                continue;
            }

            $results[$index] = $this->sendSms($phoneNumber, $message);
        }

        return $results;
    }

    /**
     * Normalize phone number to international format
     * 
     * @param string $phoneNumber
     * @return string
     */
    private function normalizePhoneNumber($phoneNumber)
    {
        // Remove all non-digit characters except +
        $phoneNumber = preg_replace('/[^\d+]/', '', $phoneNumber);

        // If it doesn't start with +, add default country code
        if (!str_starts_with($phoneNumber, '+')) {
            $defaultCountryCode = Yii::$app->params['sms']['default_country_code'] ?? '+1';
            $phoneNumber = $defaultCountryCode . $phoneNumber;
        }

        // Remove + for SMPP
        return ltrim($phoneNumber, '+');
    }
    public function drain(int $milliseconds = 1200): void
    {
        $end = microtime(true) + ($milliseconds / 1000);
        while (microtime(true) < $end) {
            try {
                $res = $this->client->readSMS();   // returns MO/DLR or false if none
                if ($res === false) {
                    usleep(100_000);
                }
            } catch (\Throwable $e) {
                $msg = $e->getMessage() ?? '';
                // Non-blocking read had no data ready yet — not an error
                if (
                    stripos($msg, 'Resource temporarily unavailable') !== false ||
                    stripos($msg, 'EAGAIN') !== false ||
                    stripos($msg, 'would block') !== false
                ) {
                    usleep(100_000);
                    continue;
                }
                // Anything else: log and break or rethrow
                Yii::warning('SMPP drain warning: ' . $msg, __METHOD__);
                break;
            }
        }
    }

    /**
     * Check if connected to SMPP server
     * 
     * @return bool
     */
    public function isConnected()
    {
        return $this->connected;
    }

    // /**
    //  * Destructor - ensure connection is closed
    //  */
    // public function __destruct()
    // {
    //     $this->disconnect();
    // }
}
