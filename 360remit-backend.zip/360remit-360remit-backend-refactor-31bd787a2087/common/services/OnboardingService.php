<?php

declare(strict_types=1);

namespace common\services;

use common\classes\VisionPoint;
use common\classes\EkycReport;
use common\models\EkycReports;
use common\classes\ScanTab;
use common\classes\NfcTab;
use common\classes\VerificationTab;
use common\models\EkycReportImages;
use common\models\Users;
use common\models\Customers;
use common\classes\EkycEvaluator;
use common\models\Countries;
use common\models\IDTypes;
use common\models\States;
use common\utility\Helpers;
use common\services\ScreeningService;
use Exception;
use Throwable;
use Yii;

final class OnboardingService
{

    /**
     * Fetch, evaluate, and save an eKYC report.
     *
     * @return array{reportId:string,sucess:bool,isReportPassed:bool,reasons:array,data:array}
     */
    public function processReport(string $reportId, int $userId): array
    {
        //TODO: check if this ID document is registered in a different phone number
        // 1️ . Pull & decrypt from API
        $client = new VisionPoint();

        /** @var EkycReport $dto */
        /** @var array $json */
        [$json, $dto] = $client->fetchReport($reportId);

        // first check if the report is saved for this customer to bypass saving it again
        $avaiableReport = EkycReports::find()
            ->where(['UserId' => $userId, 'IsOfficial' => 1])
            ->one();

        if ($avaiableReport != null) {
            $json = json_decode($avaiableReport->RawJson, true);
            $dto = EkycReport::fromArray($json);
            $data = self::getNeededData($dto);
            $decision = $avaiableReport->SystemDecision;
            $isPassed = $decision == EkycEvaluator::DECISION_REVIEW || $decision == EkycEvaluator::DECISION_APPROVED ? true : false;
            return [
                "reportId" => $reportId,
                "sucess" => true,
                "isReportPassed" => $isPassed,
                "reasons" => isset($evaluation["review_reasons"]) ? $evaluation["review_reasons"][0] : [" NOT FOUND!"],
                "data" => $data
            ];
        }



        if ($dto == null) {
            throw new \RuntimeException('Report not found');
        }
        if (!$dto->Success) {
            throw new \RuntimeException('Provider returned Success=false');
        }
        if (!$dto->ReportDetail || $dto->ReportDetail->Status !== 'Complete') {
            throw new \RuntimeException('Report not complete or missing ReportDetail');
        }

        // 2️. Evaluate via external service
        $evaluator = new EkycEvaluator();
        $evaluation = $evaluator->evaluate($dto);

        try {
            // save to DB

            $isPassed = $evaluation["decision"] == EkycEvaluator::DECISION_REVIEW || $evaluation["decision"] == EkycEvaluator::DECISION_APPROVED ? true : false;
            $data = self::getNeededData($dto);
            if ($isPassed) {
                $dbResult = $this->saveFromDto($userId, $dto, $json, $evaluation);
            }
            return [
                "reportId" => $reportId,
                "sucess" => true,
                "isReportPassed" => $isPassed,
                "reasons" => isset($evaluation["review_reasons"]) ? $evaluation["review_reasons"][0] : [" NOT FOUND!"],
                "data" => $data
            ];
        } catch (Throwable $e) {
            return [
                "reportId" => $reportId,
                "sucess" => false,
                "isReportPassed" => false,
                "reasons" => $e->getMessage(),
                "data" => []
            ];
        }
    }

    /**
     * Create or update EkycReports + EkycReportImages from DTO.
     *
     * @param int       $userId     Your Users.Id
     * @param EkycReport $dto        Decrypted & mapped DTO
     * @param string    $rawJson    Original decrypted JSON for RawJson column
     *
     * @return EkycReports The saved/updated AR instance
     * @throws \yii\db\Exception|\Throwable
     */
    public function saveFromDto(int $userId, EkycReport $dto, array $rawJson, array $decision): EkycReports
    {
        if (!$dto->ReportDetail) {
            throw new \InvalidArgumentException('ReportDetail missing in DTO.');
        }

        $rd = $dto->ReportDetail;
        $st = $rd->ScanTab ?? null;
        $vt = $rd->VerificationTab ?? null;

        // Find existing by ProviderReportId (unique) or create new
        $model = EkycReports::findOne(['ProviderReportId' => $rd->Id]) ?? new EkycReports();
        $model->UserId           = $userId;
        $model->ProviderReportId = (string)$rd->Id;

        // Top-level lifecycle
        $model->SessionId      = self::strOrNull($dto->SessionId ?? $rd->SessionId);
        $model->AdminStatus    = EkycReports::ADMINSTATUS_REVIEW;
        $model->ProviderStatus = self::strOrNull($rd->Status);

        // Identity & document info (from ScanTab)
        $model->FullNameEn     = self::strOrNull($st?->FullNameEnglish ?? $st?->FullName);
        $model->FullNameAr     = self::strOrNull($st?->FullNameArabic);
        $model->DocumentNumber = self::strOrNull($st?->DocumentNumber ?? $st?->PrimaryID);
        $model->DocumentType   = self::strOrNull($rd->DocumentType);

        $model->DateOfBirth    = self::dateOrNull($st?->DateOfBirth);
        $model->ExpiryDate     = self::dateOrNull($st?->DateOfExpiry);
        $model->IssuingState   = self::strOrNull($st?->IssuingState);

        $model->MrzFormat         = self::strOrNull($st?->MrzFormat);
        $model->MrzDocumentType   = self::strOrNull($st?->MrzDocumentType);
        $model->MrzGender         = self::strOrNull($st?->MrzGender);
        $model->MrzCountryIso2    = self::strOrNull($st?->MrzCountryIso2);
        $model->MrzCountryIso3    = self::strOrNull($st?->MrzCountryIso3);
        $model->MrzNationalityIso2 = self::strOrNull($st?->MrzNationalityCountryIso2);
        $model->MrzNationalityIso3 = self::strOrNull($st?->MrzNationalityCountryIso3);
        $model->MrzString         = self::strOrNull($st?->MrzString);

        // Derived
        $model->IsExpired         = self::computeIsExpired($model->ExpiryDate);
        $model->MrzChecksumPassed = self::boolOrNull($vt?->MrzChecksumPassed);

        // Verification signals (VerificationTab)
        $model->FaceMatchingScore             = self::numOrNull($vt?->FaceMatchingScore);
        $model->IsFaceMatched                 = self::boolOrNull($vt?->IsFaceMatched);
        $model->IsPassivePassed               = self::boolOrNull($vt?->IsPassivePassed);
        $model->GenuineIdPhotoScore           = self::numOrNull($vt?->GenuineIdPhotoScore);
        $model->NoScreenCaptureScore          = self::numOrNull($vt?->NoScreenCaptureScore);
        $model->NoPrintedCopyScore            = self::numOrNull($vt?->NoPrintedCopyScore);
        $model->DataConsistencyCheckPassed    = self::boolOrNull($vt?->DataConsistencyCheckPassed);
        $model->GenderValidationPassed        = self::boolOrNull($vt?->GenderValidationPassed);
        $model->DocumentNumberValidationPassed = self::boolOrNull($vt?->DocumentNumberValidationPassed);
        $model->DobValidationPassed           = self::boolOrNull($vt?->DateOfBirthValidationPassed);
        $model->NationalityValidationPassed   = self::boolOrNull($vt?->NationalityValidationPassed);
        $model->IsDocumentHashValid           = self::boolOrNull($vt?->IsDocumentNumberHashValid);
        $model->IsDobHashValid                = self::boolOrNull($vt?->IsBirthDateHashValid);
        $model->IsExpiryHashValid             = self::boolOrNull($vt?->IsExpiryDateHashValid);
        $model->OverallCheckValidRaw          = self::strOrNull($vt?->OverallCheckValid);

        // Capture durations
        $model->CaptureDuration       = self::numOrNull($st?->CaptureDuration);
        $model->CaptureDurationFront  = self::numOrNull($st?->CaptureDurationFront);
        $model->CaptureDurationBack   = self::numOrNull($st?->CaptureDurationBack);

        // Device & SDK
        $model->SdkVersion  = self::strOrNull($rd->SdkVersion);
        $model->SdkType     = self::strOrNull($rd->SdkType);
        $model->DeviceId    = self::strOrNull($rd->DeviceId);
        $model->DeviceGuid  = self::strOrNull($rd->DeviceGuid);
        $model->StartedAtRaw = self::strOrNull($rd->StartTime);
        $model->EndedAtRaw  = self::strOrNull($rd->EndTime);

        // Raw JSON (for audit / re-eval)
        $model->RawJson = json_encode($rawJson);

        // save Decision
        $model->SystemDecision = $decision["decision"];
        $model->SystemDecisionReasonsJson = json_encode($decision);
        if ($decision["decision"] == EkycEvaluator::DECISION_APPROVED || $decision["decision"] == EkycEvaluator::DECISION_REVIEW) {
            $model->IsOfficial = 1;
        } else {
            $model->IsOfficial = 0;
        }

        $db = Yii::$app->db;
        return $db->transaction(function () use ($model, $st): EkycReports {
            if (!$model->save(false)) {
                throw new \RuntimeException('Failed to save EkycReports: ' . json_encode($model->getErrors()));
            }

            // Upsert images (simple approach: insert new rows for each frame)
            if ($st && !empty($st->CapturedFrames)) {
                foreach ($st->CapturedFrames as $frame) {
                    // Check if this frame already exists
                    $exists = EkycReportImages::find()
                        ->where([
                            'EkycReportId' => (int)$model->Id,
                            'FrameType'    => self::strOrNull($frame->FrameType)
                        ])
                        ->exists();

                    if ($exists) {
                        // Skip this frame — already saved before
                        continue;
                    }
                    $img = new EkycReportImages();
                    $img->EkycReportId = (int)$model->Id;
                    $img->FrameType    = self::strOrNull($frame->FrameType);
                    $img->ContentType  = self::strOrNull($frame->ContentType);
                    $img->SourceUrl    = self::strOrNull($frame->ImageUrl);
                    $img->SourcePath   = self::strOrNull($frame->ImagePath);
                    // If you later download & store locally/S3, set your StoragePath, Sha256, SizeBytes (extend model)
                    if (!$img->save(false)) {
                        throw new \RuntimeException('Failed to save EkycReportImages: ' . json_encode($img->getErrors()));
                    }
                }
            }

            return $model;
        });
    }

    /**
     * Returns array: ['allowed'=>bool, 'reason'=>string|null ]
     */
    public static function canSubmit(string $userId): array
    {
        $official = EkycReports::find()
            ->where(['UserId' => $userId, 'IsOfficial' => 1])
            ->one();
        // can only submit when there is still no official report saved
        if ($official == null) {
            return ['allowed' => true, 'reason' => null, 'blockingReportId' => null];
        }
        return ['allowed' => false, 'reason' => null, 'blockingReportId' => (int)$official->Id];
        // TODO LATER: make logic after the ekyc approved or rejected by admin. customer
        // can submit again with more detials


    }


    public static function getNeededData(EkycReport $dto): array
    {
        $rd = $dto->ReportDetail ?? null;
        $st = $rd?->ScanTab ?? null;
        $vt = $rd?->VerificationTab ?? null;

        // Map CapturedFrames by type for easy lookup
        $framesByType = [];
        if ($st && !empty($st->CapturedFrames)) {
            foreach ($st->CapturedFrames as $f) {
                $key = (string)($f->FrameType ?? '');
                if ($key === '') continue;
                $framesByType[$key][] = $f;
            }
        }
        $getUrl = function (string $type) use ($framesByType): ?string {
            if (empty($framesByType[$type])) return null;
            $f = $framesByType[$type][0];
            // Prefer URL, fallback to path
            return $f->ImageUrl ?: ($f->ImagePath ?: null);
        };

        $date = fn(?string $s): ?string => self::normalizeDate($s);
        $gender = self::normalizeGender($st?->MrzGender ?? null);

        // Nationality (prefer MRZ nationality; fallback to MRZ country)
        $natIso2  = $st?->MrzNationalityCountryIso2 ?: $st?->MrzCountryIso2;
        $natIso3  = $st?->MrzNationalityCountryIso3 ?: $st?->MrzCountryIso3;
        $natName  = $st?->MrzNationalityCountryName ?: $st?->MrzCountryName;
        // get nationality Id from database
        $nationality = Countries::findOne(["CountryCode" => $natIso2]);
        return [
            // ===== Person =====
            'firstName' => $st?->MrzSurNames,
            'lastName' => $st?->MrzGivenNames,
            'dateOfBirth' => $date($st?->DateOfBirth),
            'gender' => $gender['display'], // 'Male' | 'Female' | null

            // ===== Nationality =====
            'nationalityId' => $nationality->CountryID ?: null,
            'nationalityCode' => $nationality->CountryCode ?: null,
            'nationalityName'     => $nationality->Nationality ?: null,

            // ===== Document =====
            'document' => [
                'type'        => $rd?->DocumentType ?: null,
                'number'      => $st?->DocumentNumber ?: $st?->PrimaryID,
                'expiryDate'  => $date($st?->DateOfExpiry)
            ],
        ];
    }

    public function updateProfile(string $userId, array $data)
    {
        // get the user offcial report
        // get the first name and the last name from incoming data
        // make sure that other data from the report are the same from incoming data
        // dob, gender, nationality, document detials
        // save data to customer table 
        // == example incoming data ==
        // {
        //     "firstName": "Teimur",
        //     "lastName": "Aleskerov",
        //     "dateOfBirth": "1919-01-01",
        //     "gender": "Male",
        //     "nationalityId": 166,
        //     "email": "a_teimur@mail.ru",
        //     "address": {
        //       "cityId": 1234,
        //       "street": "Lenin avenue"
        //     },
        //     "sourceOfFundsId": 1,
        //     "occupationId": 1,
        //     "document": {
        //       "type": "ID",
        //       "number": "23232308",
        //       "expiryDate": "2026-04-26"
        //     }
        //   }

        // initial validation 
        $validate = self::validateRegistrationData($data);

        if ($validate == null || $validate["success"] == false) {
            return Helpers::errorResponse(400, 'Invalid parameters!', $validate["errors"]);
        }
        // check for customer approved report
        $ekycReport = EkycReports::findOne(["UserId" => $userId, "IsOfficial" => 1]);

        // TODO LATER: use this for re-ekyc
        if ($ekycReport == null) {
            return Helpers::errorResponse(409, 'Customer registration is incomplete!', []);
        }

        // save customer information
        $user = Users::findOne(["UserID" => $userId]);
        if ($user == null) {
            return Helpers::errorResponse(404, 'Customer not found', []);
        }
        // check if the incomming information are matching the one in the ekyc report
        //$saveResult = self::saveCustomer($data, $user); TODO: this is not used any more
        $validateParameters = self::validatePayloadAgainstEkyc($ekycReport, $data);
        if (isset($validateParameters["isMatch"]) && $validateParameters["isMatch"] == false) {
            return Helpers::errorResponse(400, 'Could not save customer', ["registration infromation is not matching ekyc"]);
        }
        $saveResult = self::saveCustomerFromEkyc($ekycReport, $user, $data);
        if ($saveResult["success"] == true) {
            $customerRes = $saveResult["customer"];
            try {
                $customer = Customers::find()
                    ->where(['CustomerID' => $customerRes['CustomerID']])
                    ->with(['city', 'state', 'country', 'nationality', 'idType', 'sourceOfFund', 'user'])
                    ->one();

                // Perform LexisNexis compliance screening
                // Gender is validated as required in validateRegistrationData(), so it should always be present
                $screeningService = new ScreeningService();
                $screeningService->scanCustomer($customer, [
                    'gender' => $data['gender'] ?? '' // Fallback to empty string if somehow missing (shouldn't happen after validation)
                ]);

                $customerStatus = $customer->Status == Customers::STATUS_ACTIVATED ? "Approved" : ($customer->Status == Customers::STATUS_UNDER_REVIEW ? "Pending" : "Denied");
                if ($customer->Status == null || $customer->Status == "") {
                    $customerStatus = "Pending";
                }
                return [
                    "userId" => $customer->UserID,
                    "message" => "User created",
                    "userStatus" => $customerStatus,
                ];
            } catch (Exception $e) {
                return Helpers::errorResponse(500, 'Could not generate response', ["customer is null"]);
            }
        } else {
            return Helpers::errorResponse(400, 'Could not save customer', $saveResult["errors"]);
        }
    }
    public static function saveCustomer(array $data, Users $user): array // TODO: not used
    {
        $errors = [];

        if (!empty($errors)) {
            return ['success' => false, 'customer' => null, 'errors' => $errors];
        }

        // Try to find existing customer for this user, else create new
        $customer = Customers::find()
            ->where(['UserID' => $user->UserID])
            ->one();

        if ($customer == null) {
            return ['success' => false, 'customer' => null, 'errors' => ["customer not found"]];
        }


        // Map request → model
        $customer->UserID      = (int)$user->UserID;
        $customer->CountryCode = "OM";

        // Request fields
        $customer->DOB         = $data['dateOfBirth']   ?? null;                      // Y-m-d
        $customer->Nationality = isset($data['nationalityId']) ? (string)$data['nationalityId'] : null; // column is varchar(11)
        $customer->Occupation  = isset($data['occupationId']) ? (int)$data['occupationId'] : null;
        $customer->SourceOfFund  = isset($data['sourceOfFundsId']) ? (int)$data['sourceOfFundsId'] : null;

        // Address (CityID is int FK, Address is short text)
        $addr                  = $data['address'] ?? [];
        $customer->StateID      = 143; // TODO: check oman states
        $customer->CityID      = isset($addr['cityId']) ? (int)$addr['cityId'] : null;
        $customer->Address     = isset($addr['street']) ? trim((string)$addr['street']) : null;

        // Document block
        $doc                   = $data['document'] ?? [];
        $customer->IDType      = isset($doc['type']) ? self::mapDocumentTypeToId((string)$doc['type']) : null;
        $customer->IDNo        = isset($doc['number']) ? (string)$doc['number'] : null;
        $customer->DocExpiry   = isset($doc['expiryDate']) ? (string)$doc['expiryDate'] : null;




        // Housekeeping
        $now = (new \DateTime('now', new \DateTimeZone('Asia/Muscat')))->format('Y-m-d H:i:s');
        if ($customer->isNewRecord) {
            $customer->IsDelete   = 0;
            $customer->OnDate     = $now;
        }
        $customer->UpdatedDate = $now;

        // save user related data
        $user->Name = isset($data['firstName']) ? (string)$data['firstName'] : null;
        $user->Surname = isset($data['lastName']) ? (string)$data['lastName'] : null;
        $user->Email = isset($data['email']) ? (string)$data['email'] : null;;
        $user->UpdatedDate = $now;
        // Save in a transaction for safety (e.g., unique constraints on MobileNo / IDNo)
        /** @var Transaction $tx */
        $tx = Yii::$app->db->beginTransaction();
        try {
            if (!$user->save()) {
                $tx->rollBack();
                return [
                    'success'  => false,
                    'customer' => null,
                    'errors'   => $user->getFirstErrors(), // returns ['Attribute' => 'message']
                ];
            }
            if (!$customer->save()) {
                $tx->rollBack();
                return [
                    'success'  => false,
                    'customer' => null,
                    'errors'   => $customer->getFirstErrors(), // returns ['Attribute' => 'message']
                ];
            }

            $tx->commit();
            return ['success' => true, 'customer' => $customer->attributes, 'errors' => []];
        } catch (Throwable $e) {
            $tx->rollBack();
            Yii::error(['saveFromApi error' => $e->getMessage()], __METHOD__);
            return ['success' => false, 'customer' => null, 'errors' => ['Exception: ' . $e->getMessage()]];
        }
    }

    public static function saveCustomerFromEkyc(
        EkycReports $ekycReport,
        Users $user,
        array $data = []
    ): array {
        // Optional safety: ensure the EkycReports row really belongs to this user
        if ((int)$ekycReport->UserId !== (int)$user->UserID) {
            return [
                'success'  => false,
                'customer' => null,
                'errors'   => ['EKYC report does not belong to this user'],
            ];
        }

        // Find existing customer for this user
        $customer = Customers::find()
            ->where(['UserID' => $user->UserID])
            ->one();

        if ($customer === null) {
            return [
                'success'  => false,
                'customer' => null,
                'errors'   => ['customer not found'],
            ];
        }

        // ===== Extract from $data (frontend payload) =====
        // Example payload:
        // {
        //   "firstName": "Teimur",
        //   "lastName": "Aleskerov",
        //   "dateOfBirth": "1919-01-01",
        //   "gender": "Male",
        //   "nationalityId": 166,
        //   "email": "a_teimur@mail.ru",
        //   "address": {
        //     "cityId": 1234,
        //     "street": "Lenin avenue"
        //   },
        //   "sourceOfFundsId": 1,
        //   "occupationId": 1,
        //   "document": {
        //     "type": "ID",
        //     "number": "23232308",
        //     "expiryDate": "2026-04-26"
        //   }
        // }

        $occupationId    = isset($data['occupationId'])    ? (int)$data['occupationId']    : null;
        $sourceOfFundsId = isset($data['sourceOfFundsId']) ? (int)$data['sourceOfFundsId'] : null;
        $addr            = $data['address'] ?? null;

        $explicitFirstName = isset($data['firstName']) ? (string)$data['firstName'] : null;
        $explicitLastName  = isset($data['lastName'])  ? (string)$data['lastName']  : null;
        $explicitEmail     = isset($data['email'])     ? (string)$data['email']     : null;

        // ===== Map EKYC → Customer =====
        $customer->UserID      = (int)$user->UserID;
        $customer->CountryCode = 'OM';

        // Date of birth from EKYC (if null you can fall back to $data['dateOfBirth'] if you want)
        $customer->DOB = $ekycReport->DateOfBirth ?? ($data['dateOfBirth'] ?? null);

        // Nationality from EKYC (MRZ nationality codes)
        $customer->Nationality = (string)self::pickNationalityFromEkyc($ekycReport);

        // Occupation / SourceOfFund from payload
        if ($occupationId !== null) {
            $customer->Occupation = $occupationId;
        }

        if ($sourceOfFundsId !== null) {
            $customer->SourceOfFund = $sourceOfFundsId;
        }

        // Address
        $state = States::findOne(["MCStatID" => "OMA"]);
        $stateId = $state != null ? $state->StateID : "";
        if (is_array($addr)) {
            $customer->StateID = $stateId;
            $customer->CityID  = isset($addr['cityId']) ? (int)$addr['cityId'] : null;
            $customer->Address = isset($addr['street']) ? trim((string)$addr['street']) : null;
        }

        // Document info – prefer EKYC; if missing, can fall back to payload["document"]
        $docFromRequest = $data['document'] ?? [];

        // IDType from EKYC->DocumentType or request->document.type
        $docType = $ekycReport->DocumentType ?? ($docFromRequest['type'] ?? null);
        if ($docType !== null) {
            $customer->IDType = self::mapDocumentTypeToId((string)$docType);
        }

        // ID number
        $idNumber = $ekycReport->DocumentNumber;
        if ($idNumber !== null) {
            $customer->IDNo = (string)$idNumber;
        }

        // Expiry date
        $expiry = $ekycReport->ExpiryDate;
        if ($expiry !== null) {
            $customer->DocExpiry = $expiry;
        }

        // ===== Map EKYC / payload → Users (names & email) =====
        [$firstFromEkyc, $lastFromEkyc] = self::pickNamesFromEkyc($ekycReport);

        $finalFirstName = $firstFromEkyc;
        $finalLastName  = $lastFromEkyc;

        $now = (new \DateTime('now', new \DateTimeZone('Asia/Muscat')))
            ->format('Y-m-d H:i:s');

        if ($finalFirstName !== null) {
            $user->Name = $finalFirstName;
        }
        if ($finalLastName !== null) {
            $user->Surname = $finalLastName;
        }
        if ($explicitEmail !== null) {
            $user->Email = $explicitEmail;
        }

        $user->UpdatedDate = $now;

        // Housekeeping on customer
        if ($customer->isNewRecord) {
            $customer->IsDelete = 0;
            $customer->OnDate   = $now;
        }
        $customer->UpdatedDate = $now;

        // ===== Save in transaction =====
        $tx = Yii::$app->db->beginTransaction();
        try {
            if (!$user->save()) {
                $tx->rollBack();
                return [
                    'success'  => false,
                    'customer' => null,
                    'errors'   => $user->getFirstErrors(),
                ];
            }

            if (!$customer->save()) {
                $tx->rollBack();
                return [
                    'success'  => false,
                    'customer' => null,
                    'errors'   => $customer->getFirstErrors(),
                ];
            }

            $tx->commit();
            return [
                'success'  => true,
                'customer' => $customer->attributes,
                'errors'   => [],
            ];
        } catch (\Throwable $e) {
            $tx->rollBack();
            Yii::error(['saveCustomerFromEkyc error' => $e->getMessage()], __METHOD__);
            return [
                'success'  => false,
                'customer' => null,
                'errors'   => ['Exception: ' . $e->getMessage()],
            ];
        }
    }

    /**
     * Validate that registration payload matches EKYC data.
     *
     * @param EkycReports $ekyc
     * @param array       $data  registration payload
     *
     * @return array [
     *   'isMatch'    => bool,
     *   'mismatches' => [
     *       'firstName' => ['payload' => 'Teimur', 'ekyc' => 'Teymoor'],
     *       ...
     *   ],
     * ]
     */
    public static function validatePayloadAgainstEkyc(EkycReports $ekyc, array $data): array
    {
        $mismatches = [];

        // ---- 1) Names ----
        $payloadFirst = isset($data['firstName']) ? trim((string)$data['firstName']) : null;
        $payloadLast  = isset($data['lastName'])  ? trim((string)$data['lastName'])  : null;

        [$ekycFirst, $ekycLast] = self::pickNamesFromEkyc($ekyc);

        if (
            $payloadFirst !== null && $ekycFirst !== null &&
            !self::strEqualsInsensitive($payloadFirst, $ekycFirst)
        ) {
            $mismatches['firstName'] = [
                'payload' => $payloadFirst,
                'ekyc'    => $ekycFirst,
            ];
        }

        if (
            $payloadLast !== null && $ekycLast !== null &&
            !self::strEqualsInsensitive($payloadLast, $ekycLast)
        ) {
            $mismatches['lastName'] = [
                'payload' => $payloadLast,
                'ekyc'    => $ekycLast,
            ];
        }

        // ---- 2) Date of birth ----
        $payloadDob = $data['dateOfBirth'] ?? null;
        $ekycDob    = $ekyc->DateOfBirth;

        if (
            $payloadDob !== null && $ekycDob !== null &&
            !self::datesEqualYmd($payloadDob, $ekycDob)
        ) {
            $mismatches['dateOfBirth'] = [
                'payload' => $payloadDob,
                'ekyc'    => $ekycDob,
            ];
        }

        // ---- 3) Gender ----
        $payloadGender = $data['gender'] ?? null;        // e.g. "Male" / "Female" / "M" / "F"
        $ekycGender    = $ekyc->MrzGender ?? null;       // usually "M" / "F"

        if ($payloadGender !== null && $ekycGender !== null) {
            $p = self::normalizeGender($payloadGender);
            $e = self::normalizeGender($ekycGender);

            if ($p !== null && $e !== null && $p !== $e) {
                $mismatches['gender'] = [
                    'payload' => $payloadGender,
                    'ekyc'    => $ekycGender,
                ];
            }
        }

        // ---- 4) Nationality ----
        $payloadNationalityId = $data["nationalityId"]; // ISO2 or ISO3, uppercased
        $ekycNationalityId    = self::pickNationalityFromEkyc($ekyc);

        if ($payloadNationalityId !== null && ($ekycNationalityId !== null)) {
            if (
                $payloadNationalityId !== $ekycNationalityId
            ) {
                $mismatches['nationality'] = [
                    'payload' => $payloadNationalityId,
                    'ekyc'    => [
                        'nationality' => $ekycNationalityId,
                    ],
                ];
            }
        }

        // ---- 5) Document number ----
        $payloadDocNumber = $data['document']['number'] ?? null;
        $ekycDocNumber    = $ekyc->DocumentNumber;

        if (
            $payloadDocNumber !== null && $ekycDocNumber !== null &&
            !self::strEqualsInsensitive((string)$payloadDocNumber, (string)$ekycDocNumber)
        ) {
            $mismatches['documentNumber'] = [
                'payload' => $payloadDocNumber,
                'ekyc'    => $ekycDocNumber,
            ];
        }

        // ---- 6) Document expiry date ----
        $payloadExpiry = $data['document']['expiryDate'] ?? null;
        $ekycExpiry    = $ekyc->ExpiryDate;

        if (
            $payloadExpiry !== null && $ekycExpiry !== null &&
            !self::datesEqualYmd($payloadExpiry, $ekycExpiry)
        ) {
            $mismatches['expiryDate'] = [
                'payload' => $payloadExpiry,
                'ekyc'    => $ekycExpiry,
            ];
        }

        return [
            'isMatch'    => empty($mismatches),
            'mismatches' => $mismatches,
        ];
    }

    /**
     * Map API document.type to your IDTypes table IDs.
     * Adjust these IDs to match your DB seed.
     * e.g., 
     */
    private static function mapDocumentTypeToId(string $nationalityCode): ?int
    {
        // TODO:
        $key = strtoupper(trim($nationalityCode));
        $idType = null;
        if ($key == "OM") {
            $idType = IDTypes::findOne(["MCIdTypeID" => "NI"]); // national id for omanis
        } else {
            $idType = IDTypes::findOne(["MCIdTypeID" => "G2"]); // government id for expats
        }
        return $idType?->IDTypeID ?? null;
    }
    /* ----------------------------- Helpers ----------------------------- */

    /**
     * Case- and whitespace-insensitive string equality.
     */
    private static function strEqualsInsensitive(string $a, string $b): bool
    {
        $na = strtolower(trim(preg_replace('/\s+/', ' ', $a)));
        $nb = strtolower(trim(preg_replace('/\s+/', ' ', $b)));
        return $na === $nb;
    }

    /**
     * Compare two date strings as Y-m-d (any parsable format).
     */
    private static function datesEqualYmd(string $a, string $b): bool
    {
        try {
            $da = (new \DateTime($a))->format('Y-m-d');
            $db = (new \DateTime($b))->format('Y-m-d');
            return $da === $db;
        } catch (\Exception $e) {
            // fallback to raw compare if parsing fails
            return trim($a) === trim($b);
        }
    }
    /**
     * Choose nationality to store into Customers.Nationality.
     * Prefer MRZ ISO3, then MRZ ISO2.
     */
    private static function pickNationalityFromEkyc(EkycReports $ekyc): ?int
    {

        $country = Countries::findOne(["CountryCode" => $ekyc->MrzNationalityIso2]);
        if ($country != null) {
            return $country->CountryID;
        }


        return null;
    }

    /**
     * Split FullNameEn into first/last name.
     */
    private static function pickNamesFromEkyc(EkycReports $ekyc): array
    {
        $array = Json_decode($ekyc->RawJson, $array = true);
        $dto = EkycReport::fromArray($array);
        $details = $dto->ReportDetail->ScanTab;

        return [$details->MrzSurNames, $details->MrzGivenNames];
    }

    /**
     * @return array{
     *   success:bool
     */
    public static function validateRegistrationData(array $data): array
    {
        $errors = [];

        // ===== Required Top-Level Fields =====
        $requiredFields = [
            'firstName',
            'lastName',
            'dateOfBirth',
            'gender',
            'nationalityId',
            'email',
            'address',
            'sourceOfFundsId',
            'occupationId',
            'document'
        ];
        $isLastNameRequied = false;
        foreach ($requiredFields as $field) {
            if ($field == "lastName" || $field == "email") {
                continue;
            }
            if (empty($data[$field])) {
                $errors[] = "Missing required field: {$field}";
            }
        }

        // ===== Basic Format Checks =====
        if (!empty($data['firstName']) && !preg_match('/^[A-Za-z\s\'-]{2,50}$/', $data['firstName'])) {
            $errors[] = "Invalid firstName format";
        }

        if ($isLastNameRequied && !empty($data['lastName']) && !preg_match('/^[A-Za-z\s\'-]{2,50}$/', $data['lastName'])) {
            $errors[] = "Invalid lastName format";
        }

        if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        }

        if (!empty($data['dateOfBirth'])) {
            $dob = strtotime($data['dateOfBirth']);
            if (!$dob || $dob > time() || !self::isValidDateOnly($data['dateOfBirth'])) {
                $errors[] = "Invalid dateOfBirth value";
            }
        }

        if (!empty($data['gender']) && !in_array(strtolower($data['gender']), ['male', 'female', 'other'], true)) {
            $errors[] = "Invalid gender value";
        }

        if (!empty($data['nationalityId']) && !is_numeric($data['nationalityId'])) {
            $errors[] = "nationality must be a numeric ID";
        }

        if (!empty($data['sourceOfFundsId']) && !is_numeric($data['sourceOfFundsId'])) {
            $errors[] = "sourceOfFundsId must be numeric";
        }

        if (!empty($data['occupationId']) && !is_numeric($data['occupationId'])) {
            $errors[] = "occupationId must be numeric";
        }

        // ===== Address Validation =====
        if (!empty($data['address'])) {
            $address = $data['address'];

            if (empty($address['cityId']) || !is_numeric($address['cityId'])) {
                $errors[] = "address.cityId must be numeric";
            }

            if (empty($address['street']) || strlen(trim($address['street'])) < 3) {
                $errors[] = "address.street must be at least 3 characters long";
            }
        }

        // ===== Document Validation =====
        if (!empty($data['document'])) {
            $doc = $data['document'];
            $requiredDocFields = ['type', 'number', 'expiryDate'];

            foreach ($requiredDocFields as $field) {
                if (empty($doc[$field])) {
                    $errors[] = "Missing document field: {$field}";
                }
            }

            if (!empty($doc['type']) && !in_array(strtoupper($doc['type']), ['ID'])) {
                $errors[] = "document.type must be ID";
            }

            if (!empty($doc['number']) && !preg_match('/^[A-Za-z0-9]{5,20}$/', $doc['number'])) {
                $errors[] = "Invalid document.number format";
            }

            if (!empty($doc['expiryDate'])) {
                $expiry = strtotime($doc['expiryDate']);
                if (!$expiry || $expiry <= time()) {
                    $errors[] = "document.expiryDate must be a valid future date";
                }

                if (!self::isValidDateOnly($doc['expiryDate'])) {
                    $errors[] = "document.expiryDate invalid format";
                }
            }
        }

        // ===== Return Result =====
        if (!empty($errors)) {
            return [
                'success' => false,
                'errors' => $errors
            ];
        }

        return [
            'success' => true,
            'message' => 'Validation passed'
        ];
    }

    private static function strOrNull(?string $v): ?string
    {
        $v = is_string($v) ? trim($v) : null;
        return ($v === '') ? null : $v;
    }

    private static function numOrNull($v): ?float
    {
        return is_numeric($v) ? (float)$v : null;
    }

    private static function boolOrNull($v): ?int
    {
        // Your AR uses integer(0/1) for booleans; normalize here.
        if ($v === null) return null;
        return (bool)$v ? 1 : 0;
    }

    private static function dateOrNull(?string $iso): ?string
    {
        if (!$iso) return null;
        try {
            // Accepts ISO strings like "2026-12-26T00:00:00Z" or "1999/3/12"
            $iso = str_replace('/', '-', $iso);
            $dt  = new \DateTimeImmutable($iso);
            // Store as DATE in DB; adjust if your column is DATETIME
            return $dt->format('Y-m-d');
        } catch (Throwable $e) {
            return null;
        }
    }
    private static function normalizeDate(?string $s): ?string
    {
        if (!$s) return null;
        try {
            // Accept "1999/3/12", "2026-12-26T00:00:00Z", etc.
            $s = str_replace('/', '-', $s);
            $dt = new \DateTimeImmutable($s);
            return $dt->format('Y-m-d');
        } catch (\Throwable $e) {
            return null;
        }
    }

    private static function normalizeGender(?string $g): array
    {
        if (!$g) return ['code' => null, 'display' => null];
        $t = strtolower(trim($g));
        // Accept MRZ style ('M','F') and words
        if ($t === 'm' || $t === 'male')   return ['code' => 'M', 'display' => 'Male'];
        if ($t === 'f' || $t === 'female') return ['code' => 'F', 'display' => 'Female'];
        // Unknown or other
        return ['code' => null, 'display' => $g];
    }

    private static function computeIsExpired(?string $dateYmd): ?int
    {
        if (!$dateYmd) return null;
        try {
            $exp = new \DateTimeImmutable($dateYmd);
            return ($exp < new \DateTimeImmutable('today')) ? 1 : 0;
        } catch (Throwable $e) {
            return null;
        }
    }
    private static function isValidDateOnly(string $date): bool
    {
        $d = \DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }
}
