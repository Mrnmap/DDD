<?php

namespace common\services;

use Yii;
use common\classes\LexisNexis;
use common\classes\ScreeningMapper;
use common\classes\ScreeningRecord;
use common\classes\ScreeningResponse;
use common\classes\ScreeningRiskEvaluator;
use common\models\Beneficiaries;
use common\models\Customers;

/**
 * ScreeningService
 *
 * Lightweight wrapper around LexisNexis->performSearch() that prepares person data
 * for either Customers or Beneficiaries, then executes the search.
 *
 * Inputs ($customer/$beneficiary) can be arrays or AR models/DTOs with public props/getters.
 */
class ScreeningService
{
    /** @var LexisNexis */
    private $ln;

    public function __construct(?LexisNexis $lexisNexis = null)
    {
        $this->ln = $lexisNexis ?? new LexisNexis();
    }

    /**
     * Scan a CUSTOMER using LexisNexis->performSearch()
     *
     * @param array|object $customer  Array or object (AR/DTO) containing person data
     * @param array        $opts      Optional overrides: [
     *   'clientReference' => 'string',
     *   'accountNumber'   => 'string',
     *   'gender'          => 'Male|Female|...'
     * ]
     * @return array  Standardized result from LexisNexis->performSearch()
     */
    public function scanCustomer($customer, array $opts = []): array
    {
        date_default_timezone_set('Asia/Muscat');
        try {
            $params = $this->buildPersonParams($customer, $opts, 'customer');
            $result = $this->ln->performSearch($params);

            if ($result["data"] != null) {
                if (isset($result["data"]["ClientReference"])) {
                    $searchResult = ScreeningMapper::fromJson(json_encode($result["data"]));
                    $decision = ScreeningRiskEvaluator::evaluate($searchResult);
                    $customer->LastSceeningAt = date('Y-m-d H:i:s');
                    $customer->ScreeningResult = (string)json_encode($decision);
                    $customer->SceeningReference = $searchResult->ClientReference;
                    // All customers are set to under review after screening
                    $customer->Status = Customers::STATUS_UNDER_REVIEW;
                    if (!$customer->save(false)) {
                        return [
                            'sucess'  => false,
                            'data'    => $result["data"],
                            'message' => 'scanCustomer failed: could not save the updates',
                        ];
                    }

                    return [
                        'sucess'  => true,
                        'data'    => null,
                        'message' => 'Customer scanned',
                    ];
                }

                return [
                    'sucess'  => true,
                    'data'    => $result["data"],
                    'message' => 'scanCustomer sucess: no response from Lexis Nexis',
                ];
            } else {
                // keep the result null but the date is updated
                $customer->ScreeningResult = $result["message"];
                $customer->LastSceeningAt = date('Y-m-d H:i:s');
                $customer->Status = Customers::STATUS_UNDER_REVIEW;
                $saveMsg = "";
                if (!$customer->save(false)) {
                    $saveMsg = 'scanCustomer failed: could not save the updates';
                }
                return [
                    'sucess'  => false,
                    'data'    => $result["message"] . $saveMsg,
                    'message' => 'scanCustomer failed: no response from Lexis Nexis ' . $saveMsg,
                ];
            }
        } catch (\Throwable $e) {
            Yii::error('scanCustomer error: ' . $e->getMessage(), __METHOD__);
            return [
                'status'  => 'error',
                'data'    => null,
                'message' => 'scanCustomer failed: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Scan a BENEFICIARY using LexisNexis->performSearch()
     *
     * @param array|object $beneficiary  Array or object (AR/DTO) containing person data
     * @param array        $opts         Optional overrides (same keys as scanCustomer)
     * @return array
     */
    public function scanBeneficiary($beneficiary, array $opts = []): array
    {
        date_default_timezone_set('Asia/Muscat');
        try {
            $params = $this->buildPersonParams($beneficiary, $opts, 'beneficiary');
            $result = $this->ln->performSearch($params);

            // TODO: use this for now to bypass the error.
            // for later treat it as error
            //$result["data"] = null;
            if ($result["data"] != null) {
                // save beneficiary scanning result
                // there is an error
                if (isset($result["data"]["ClientReference"])) {
                    $searchResult = ScreeningMapper::fromJson(json_encode($result["data"]));
                    // this function determine the risk of this beneficiary
                    //$logic = $this->isBeneficiaryCleared($searchResult);
                    $decision = ScreeningRiskEvaluator::evaluate($searchResult);
                    $beneficiary->LastSceeningAt = date('Y-m-d H:i:s');
                    $beneficiary->ScreeningResult = (string)json_encode($decision);
                    $beneficiary->SceeningReference = $searchResult->ClientReference; // TODO: 'BENEFICIARY_' . $src->BeneficiaryID
                    $beneficiary->Status = $decision["risk"] == ScreeningRiskEvaluator::RISK_LOW ? Beneficiaries::STATUS_ACTIVATED : Beneficiaries::STATUS_UNDER_REVIEW;
                    if (!$beneficiary->save(false)) {
                        return [
                            'sucess'  => false,
                            'data'    => $result["data"],
                            'message' => 'scanBeneficiary failed: could not save the updates',
                        ];
                    }

                    return [
                        'sucess'  => true,
                        'data'    => null,
                        'message' => 'Beneficiary scanned',
                    ];
                }

                return [
                    'sucess'  => true,
                    'data'    => $result["data"],
                    'message' => 'scanBeneficiary sucess: no response from Lexis Nexis',
                ];
            } else {
                // keep the result null but the date is updated
                $beneficiary->ScreeningResult = $result["message"];
                $beneficiary->LastSceeningAt = date('Y-m-d H:i:s');
                $beneficiary->Status = null;
                $saveMsg = "";
                if (!$beneficiary->save(false)) {
                    $saveMsg = 'scanBeneficiary failed: could not save the updates';
                }
                return [
                    'sucess'  => false, // just for now later must be false
                    'data'    => $result["message"] . $saveMsg,
                    'message' => 'scanBeneficiary failed: no response from Lexis Nexis ' . $saveMsg,
                ];
            }
        } catch (\Throwable $e) {
            Yii::error('scanBeneficiary error: ' . $e->getMessage(), __METHOD__);
            return [
                'status'  => 'error',
                'data'    => null,
                'message' => 'scanBeneficiary failed: ' . $e->getMessage(),
            ];
        }
    }

    /* =========================================================
       Helpers
       ========================================================= */

    private function buildPersonParams($src, array $opts, string $kind): array
    {

        // -------- Beneficiary: only need these inputs --------
        if ($kind === 'beneficiary') {


            $clientRef = 'BENEFICIARY_' . $src->BeneficiaryID;

            // The rest of the LN payload fields are filled with benign defaults so performSearch() won't fail.
            return [
                'clientReference' => $clientRef,
                'gender'          => (string)$src->Gender ?? '',
                'firstName'       => (string)$src->FirstName ?? '',
                'middleName'      => (string)$src->MiddleName ?? '',
                'lastName'        => (string)$src->LastName ?? '',

                // Required by current buildSearchPayload (kept safe/default)
                //'dob'             => '1900-01-01',
                //'placeOfBirth'    => '',

                // Address defaults (not required per your beneficiary needs)
                'street1'         => '',
                'street2'         => '',
                'city'            => '',
                'postalCode'      => '',

                // Required per your list
                'country'         => (string)$src->nationality->CountryName,    // ISO2
                'accountNumber'   => (string)$src->IDNo ?? '', // maps your "Id No"
            ];
        }

        // -------- Customer: map from Customers model and Users relationship --------
        if ($kind === 'customer') {
            $clientRef = isset($opts['clientReference']) ? $opts['clientReference'] : 'CUSTOMER_' . $src->CustomerID;

            // Get user information - load if not already loaded
            $user = null;
            if (isset($src->user) && $src->user) {
                $user = $src->user;
            } else {
                // Load user if relationship not eager loaded
                $user = $src->getUser()->one();
            }

            $firstName = '';
            $lastName = '';
            $middleName = '';

            if ($user) {
                $firstName = (string)($user->Name ?? '');
                $lastName = (string)($user->Surname ?? '');
                $middleName = (string)($user->MiddleName ?? '');
            }

            // Get gender from options (passed from updateProfile) or default
            $gender = isset($opts['gender']) ? (string)$opts['gender'] : '';

            // Get address information
            $street1 = (string)($src->Address ?? '');
            $street2 = '';
            $city = '';
            $postalCode = '';

            // Get city name if relationship is loaded
            if (isset($src->city) && $src->city) {
                $city = (string)($src->city->CityName ?? '');
            }

            // Get country from nationality relationship
            $country = '';
            if (isset($src->nationality) && $src->nationality) {
                $country = (string)($src->nationality->CountryName ?? '');
            }

            // Get account number from IDNo
            $accountNumber = (string)($src->IDNo ?? '');

            return [
                'clientReference' => $clientRef,
                'gender'          => $gender,
                'firstName'       => $firstName,
                'middleName'      => $middleName,
                'lastName'        => $lastName,
                'street1'         => $street1,
                'street2'         => $street2,
                'city'            => $city,
                'postalCode'      => $postalCode,
                'country'         => $country,
                'accountNumber'   => $accountNumber,
            ];
        }

        return [];
    }


    private function isBeneficiaryCleared(ScreeningResponse $screeningResult)
    {
        if (count($screeningResult->Records) == 0) {
            return true;
        }
        // add logic of risk and match score
        return false;
    }
}
