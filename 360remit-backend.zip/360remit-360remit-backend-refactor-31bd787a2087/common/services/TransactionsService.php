<?php

namespace common\services;

use Yii;
use yii\db\Query;
use yii\helpers\ArrayHelper;
use api\models\TransactionsSearch;
use Codeception\Attribute\Env;
use common\models\AmlPolicies;
use common\models\Beneficiaries;
use common\models\Transactions;
use common\models\BeneficiaryBankAccounts;
use common\utility\Helpers;
use common\classes\DeliveryMethod;
use common\classes\Mastercard;
use common\classes\PaymentGateway;
use common\models\TransactionLogs;
use common\models\DeliveryTime;
use common\models\PaymentGatewayTransaction;
use common\models\TransactionDetails;
use common\models\Users;
use common\jobs\ProcessDataJob;
use DateTime;

class TransactionsService
{
    public function getTransactions($params)
    {
        $sort = $params['sort'] ?? null;
        $userId = $params['user_id'] ?? null;
        $date_from = $params['date_from'] ?? null;
        $date_to = $params['date_to'] ?? null;
        $page = intval($params['page']);
        $page = $page > 0 ? $page - 1 : 0;
        $limit = intval($params['limit']); // make default as all list



        $params = [
            "userId" => $userId,
            "pageSize" => $limit,
            "TransactionsSearch" => [
                "date_from" => $date_from,
                "date_to" => $date_to,
            ]

        ];

        $searchModel = new TransactionsSearch();
        $search = $searchModel->search($params);

        $search->pagination->page = $page;
        $transactions = $search->getModels();

        $transactionsList = [];
        foreach ($transactions as $transaction) {
            $names = [$transaction->beneficiary->FirstName ?? null, $transaction->beneficiary->MiddleName ?? null, $transaction->beneficiary->LastName ?? null];
            $date = new DateTime($transaction->CreatedAt);
            $formattedDate = $date->format('Y-m-d H:i:s');
            $item = [
                'id' => $transaction->TransactionID,
                'status' => $transaction->transactionStatus->Name,
                'beneficiaryName' => implode(" ", array_filter($names)),
                'date' => $formattedDate,
                'dateFormat' => "Y-m-d H:i:s",
                'amountSent' => number_format($transaction->transactionDetails->SendingAmount, 3, '.', ''),
                'currencySent' => $transaction->transactionDetails->SendingCurrencyCode,
                'amountGet' => number_format($transaction->transactionDetails->ReceivedAmount, 3, '.', ''),
                'currencyGet' => $transaction->transactionDetails->ReceivingCurrencyCode
            ];
            $transactionsList[] = $item;
        }
        $pagination = $search->getPagination();
        return [
            "transactions" => $transactionsList,
            "totalElements" => $search->getTotalCount(),
            "totalPages" => $pagination->getPageCount(),
            "currentPage" => (int)($pagination->getPage() + 1)
        ];
    }

    public function validateTransaction($params)
    {
        // validate parameters

        // {
        //     "userId": "1",
        //     "beneficiaryId": "116",
        //     "transaction": {
        //       "deliveryMethod": "bank",
        //       "sourceCurrency": "OMR",
        //       "sourceCountryId": "166",
        //       "receivingCurrency": "INR",
        //       "receivingCountryId": "100",
        //       "sendingAmount": "100.000",
        //       "receivingAmount": "260.08",
        //       "transferPurpose": "5",
        //       "sourceOfFunds": "1", // not there any more
        //       "paymentProfileId": "143",
        //       "rate": "2.60",
        //       "fee": "2.000",
        //       "vat": "0.100",
        //       "finalFee": "2.100",
        //       "finalPrice": "102.100"
        //     }
        //   }




        // validate parameters
        $result = $this->validateTransactionParams($params);
        if (!isset($result["ok"])) {
            return $result;
        }
        // check if the customer can do a transaction in the first place
        $user = Users::findOne(["UserID" => $params["userId"]]);
        if ($user != null && !$user->isTransactionStatusActive()) {
            return Helpers::errorResponse(403, "customer not allowed to perform transactions", []);
        }

        // ---------- Conditional checks for Bank Deposit ----------
        // $transactionObj = $params["transaction"];
        // $dmEnum = DeliveryMethod::fromName($transactionObj["deliveryMethod"]);
        $transactionObj = $result["transaction"];
        $dmEnum = $result["deliveryMethodEnum"];
        if ($dmEnum == DeliveryMethod::BankDeposit) {
            // Require beneficiary & payment profile for bank deposits
            if (!is_numeric($params["beneficiaryId"]) || !is_numeric($transactionObj["paymentProfileId"])) {
                return Helpers::errorResponse(400, "beneficiaryId and paymentProfileId are required for bank deliveryMethod", []);
            }

            // Ensure beneficiary belongs to user (if that’s your rule)
            $beneficiary = Beneficiaries::findOne(["BeneficiaryID" => (int)$params["beneficiaryId"], "UserID" => (int)$params["userId"]]);
            if ($beneficiary === null) {
                return Helpers::errorResponse(400, "beneficiary not found for this user", []);
            }

            $bankAccount = BeneficiaryBankAccounts::findOne([
                "UserId" => (int)$params["userId"],
                "BeneficiaryId" => (int)$params["beneficiaryId"],
                "BeneficiaryBankAccountId" => (int)$transactionObj["paymentProfileId"],
                "CountryId" => (int)$transactionObj["receivingCountryId"],
            ]);
            if ($bankAccount === null) {
                return Helpers::errorResponse(400, "payment profile not found for the receiving country", []);
            }

            // Ensure mapping to a Mastercard payer exists
            $payerId = $bankAccount->branch->MCBankID ?? '';
            if ($payerId === null || trim($payerId) === '') {
                return Helpers::errorResponse(400, "Mastercard payer not found for this bank", []);
            }
        }


        $result = $this->checkTransactionLimits($params["userId"], (float)$transactionObj["sendingAmount"]);
        // check the transaction limits
        // if error is not set mean there is an error happend
        if (!isset($result['error'])) {
            return $result;
        }
        // save transaction as new
        $createTrnResult = TransactionsHandler::create($params);
        if (isset($createTrnResult["ok"]) && $createTrnResult["ok"] == false) {
            return Helpers::errorResponse(400, $createTrnResult['message'], $createTrnResult['errors']);
        }
        // validate from mastercard
        $mc = new MasterCard();
        $validateResult = $mc->validateTransaction($createTrnResult["transactionId"], $params);

        if ($validateResult["ok"] == false) {
            // the validation failed
            $opts = [
                "statusName" => "Failed",
                "internal" => TransactionLogs::INTERNALSATUS_INITIATED_IN_MASTERCARD,
                "source" => TransactionLogs::SOURCE_SYSTEM,
                "comment" => $validateResult["message"] . implode(" ", $validateResult["errors"]),
                "updateTransactionStatus" => true
            ];
            $saveUpdateResult = TransactionsHandler::logTransaction($createTrnResult["transactionId"], $opts);
            if ($saveUpdateResult["ok"] == false) {
                return Helpers::errorResponse(
                    400,
                    $saveUpdateResult["message"],
                    $saveUpdateResult["errors"]
                );
            }
            return Helpers::errorResponse(
                400,
                $validateResult["message"],
                $validateResult["errors"]
            );
        } else if ($validateResult["ok"] == true) {
            // the validation passed
            $opts = [
                "statusName" => "",
                "internal" => TransactionLogs::INTERNALSATUS_INITIATED_IN_MASTERCARD,
                "source" => TransactionLogs::SOURCE_PARTNER,
                "comment" => "transaction was initiated in mastercard",
                "updateTransactionStatus" => true,
            ];
            $saveUpdateResult = TransactionsHandler::logTransaction($createTrnResult["transactionId"], $opts);
            if ($saveUpdateResult["ok"] == false) {
                return Helpers::errorResponse(
                    400,
                    $saveUpdateResult["message"],
                    $saveUpdateResult["errors"]
                );
            }
            // get delivery estimation
            $deliveryTime = DeliveryTime::findOne(["CountryId" => $transactionObj["receivingCountryId"], "CurrencyCode" => $transactionObj["receivingCurrency"], "DeliveryMethodId" => $dmEnum->system()]);
            $estimation = "";
            if ($deliveryTime != null) {
                $estimation = $deliveryTime->Estimation;
            }

            return [
                "transactionId" => $createTrnResult["transactionId"],
                "expectedTime" => $estimation
            ];
        }
    }

    public function checkPaymentStatus($transactionId)
    {
        // check from payment gateway
        if (empty($transactionId)) {
            return Helpers::errorResponse(400, "transaction id is empty", []);
        }
        // check if the transaction is registered

        $trnDetails = TransactionDetails::findOne(["TransactionID" => $transactionId]);
        if ($trnDetails == null) {
            return Helpers::errorResponse(400, "transaction id is invalid", []);
        }
        $paymentGW = new PaymentGateway();
        // $params = [
        //     "amount" => (string)$trnDetails->CollectedAmount,
        //     "transactionId" => $transactionId
        // ];
        //$result = $paymentGW->inquiryRequest($params); // TODO: this function has a problem where I cannot diffrenciate between canceled and timedout transaction
        $result = $paymentGW->getSavedTrn($transactionId); // this a temporary solution to determine the exact satus of the payment
        if ($result == null || $result == "") {
            return Helpers::errorResponse(400, "error in payment gateway", []);
        } else if ((isset($result["success"]) && $result["success"] == false)) {
            return Helpers::errorResponse(400, $result["error"], $result["data"]);
        }

        if (isset($result["success"]) && $result["success"] == true) {
            $data = json_decode($result["data"], true);
            if (isset($data["status"]) && $data["status"] == "0") {
                // when the status is 0 means the transaction is still not yet finished
                return [
                    "paymentIsDone" => false,
                    "paymentIsSucessfull" => false,
                    "transactionId" => $transactionId,
                    "status" => "waiting",
                    "message" => "Transaction waiting for customer action",
                ];
            } else if (isset($data["PG_Transaction_Status"])) {
                // when there is data like PG_Transaction_Status it means the payment was finished
                // TODO: use this function for production
                $paymentStatus = $this->isSuccessfulPayment($data["PG_Transaction_Status"]);

                // TODO: allow this function only for testing and bypassing failure payment
                if (APP_DEV) {
                    if ($trnDetails->SendingAmount == 1.235) {
                        $paymentStatus = true;
                    }
                    if ($paymentStatus) {
                        $data["PG_Transaction_Status"] = "CAPTURED";
                    }
                }

                $customerStatus =  $this->cleanStatusText($data["PG_Transaction_Status"]);
                // log the payment
                $log = [
                    'statusName' => $paymentStatus ? "In Progress" : "Failed",
                    'internal'   => $paymentStatus ? TransactionLogs::INTERNALSATUS_FUNDS_CAPTURED : TransactionLogs::INTERNALSATUS_FUNDS_NOT_CAPTURED,
                    'source'     => TransactionLogs::SOURCE_GATEWAY,
                    'comment'    => 'Gateway response',
                    'requestJson'    => $data,
                    'gateway'    => [
                        'reference' => $data["Payment_ID"],            // required
                        'status'    => strtoupper(trim($data["PG_Transaction_Status"])),         // required
                        'message'   => '',
                        'raw'       => $data,  // array or string; checksum auto
                    ],
                ];
                // the transaction was not saved before in the payment gateway then save it
                $paymentTrn = PaymentGatewayTransaction::findOne(["TransactionId" => $transactionId]);
                // for testing allow this
                if (APP_DEV) {
                    $paymentTrn = null;
                }

                if ($paymentTrn == null) {
                    $logResult = TransactionsHandler::logPayment($transactionId, $log);
                    if ($paymentStatus) {
                        // log tranaction submission
                        $opts = [
                            "statusName" => "",
                            "internal" => TransactionLogs::INTERNALSATUS_SUBMITTED,
                            "source" => TransactionLogs::SOURCE_SYSTEM,
                            "comment" => json_encode($result),
                            "updateTransactionStatus" => false
                        ];
                        $saveUpdateResult = TransactionsHandler::logTransaction($transactionId, $opts); // TODO LATER: log this information to confirm process sanity
                        $runProcessTransaction = filter_var($_ENV["PT_ACTIVECRON"] ?? false, FILTER_VALIDATE_BOOLEAN); // check if we want to activate cron job here
                        if ($runProcessTransaction) {
                            $this->runProcessTransaction();
                        }
                    } else {
                        // cancel the transaction with mastercard if funds not captured
                        $mc = new Mastercard();
                        $cancelationResult = $mc->cancelTransaction($transactionId, "user");

                        if (isset($cancelationResult["sucess"]) && $cancelationResult["sucess"] == true) {
                            $saved = TransactionsHandler::saveCancelTransaction($transactionId, $cancelationResult);
                            if ($saved["ok"] == false) {
                                return Helpers::errorResponse(400, $saved["message"], $saved["errors"]);
                            }
                        }
                        if (isset($logResult) && $logResult["ok"] == false) {
                            return Helpers::errorResponse(400, $logResult["message"], $logResult["errors"]);
                        }
                    }
                }

                return [
                    "paymentIsDone" => true,
                    "paymentIsSucessfull" => $paymentStatus,
                    "transactionId" => $transactionId,
                    "status" => "done",
                    "message" => $customerStatus,
                ];
            }

            return Helpers::errorResponse(400, "unexpected error in payment status", []);
        }
    }

    function isSuccessfulPayment(?string $result): bool
    {
        if (empty($result)) {
            return false;
        }

        // Normalize spacing and case
        $result = strtoupper(trim($result));

        // Success result codes according to OmanNet documentation (Section 3.6 - Result)
        $successCodes = ['CAPTURED', 'APPROVED', 'SUCCESS'];

        return in_array($result, $successCodes, true);
    }
    function cleanStatusText(string $text): string
    {
        // Trim first
        $text = trim($text);

        // Case 1: text starts with IPAYxxxx — remove that part and any following dash/space
        if (preg_match('/^IPAY\d+\s*-\s*(.+)$/i', $text, $m)) {
            return trim($m[1]);
        }

        // Case 2: starts with IPAY but without dash
        if (preg_match('/^IPAY\d+\s+(.+)$/i', $text, $m)) {
            return trim($m[1]);
        }

        // Case 3: no IPAY code, just return cleaned text
        return trim($text);
    }
    public function checkTransactionLimits($userId, $amount)
    {
        //  transactions of today
        $TodayTx = Transactions::find()
            ->where(['UserId' => $userId])->joinWith(["transactionDetails"])
            ->andWhere(['>=', 'Transactions.CreatedAt', new \yii\db\Expression('NOW() - INTERVAL 24 HOUR')]);

        // transactions of this month
        $MonthTx = Transactions::find()
            ->where(['Transactions.UserId' => $userId])->joinWith(["transactionDetails"])
            ->andWhere(['>=', 'Transactions.CreatedAt', new \yii\db\Expression('NOW() - INTERVAL 1 MONTH')]);
        // get number of transactions
        $countTodayTx = $TodayTx->count();
        $countMonthTx = $MonthTx->count();

        // get volume of transactions
        $todayVolume = (float) ((clone $TodayTx)->sum('TransactionDetails.SendingAmount') ?? 0);
        $monthVolume = (float) ((clone $MonthTx)->sum('TransactionDetails.SendingAmount') ?? 0);

        // counting after the current Transaction
        $countTodayTx = $countTodayTx + 1;
        $countMonthTx = $countMonthTx + 1;

        $todayVolume = $todayVolume + $amount;
        $monthVolume = $monthVolume + $amount;

        // get the limits conditions
        $transactionslimits = AmlPolicies::find()->where(["Enable" => 1])->one();

        if ($amount > $transactionslimits->AmountPerTransaction) {
            return Helpers::errorResponse(
                400,
                "Transaction amount limit exceeded",
                [
                    "Allowed per transaction" => $transactionslimits->AmountPerTransaction,
                    "Attempted amount" => $amount
                ]
            );
        }

        if ($countTodayTx > $transactionslimits->TrnCountPerDay) {
            return Helpers::errorResponse(
                400,
                "Daily transaction count limit exceeded",
                [
                    "Allowed per day" => $transactionslimits->TrnCountPerDay,
                    "Attempted today" => $countTodayTx
                ]
            );
        }

        if ($countMonthTx > $transactionslimits->TrnCountPerMonth) {
            return Helpers::errorResponse(
                400,
                "Monthly transaction count limit exceeded",
                [
                    "Allowed per month" => $transactionslimits->TrnCountPerMonth,
                    "Attempted this month" => $countMonthTx
                ]
            );
        }

        if ($todayVolume > $transactionslimits->TotalAmountPerDay) {
            return Helpers::errorResponse(
                400,
                "Daily transaction amount limit exceeded",
                [
                    "Allowed per day" => $transactionslimits->TotalAmountPerDay,
                    "Attempted today" => $todayVolume
                ]
            );
        }

        if ($monthVolume > $transactionslimits->TotalAmountPerMonth) {
            return Helpers::errorResponse(
                400,
                "Monthly transaction amount limit exceeded",
                [
                    "Allowed per month" => $transactionslimits->TotalAmountPerMonth,
                    "Attempted this month" => $monthVolume
                ]
            );
        }


        return ['error' => false];
    }
    public function runProcessTransaction(): void
    {
        $absUrl = Yii::$app->urlManager->createAbsoluteUrl(['/cron/process-transaction']); // https://dev.example.com/...
        $host   = parse_url($absUrl, PHP_URL_HOST);
        $ip     = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1'; // from your env it was 10.8.84.22
        $token  = Yii::$app->params['cronSecret'];

        $ch = curl_init($absUrl);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST        => 'GET',
            CURLOPT_HTTPHEADER           => [
                'X-Api-Key: ' . $token,
                'Accept: application/json',
            ],
            CURLOPT_RESOLVE              => ["{$host}:443:{$ip}"], // skip DNS, keep SNI/Host
            CURLOPT_RETURNTRANSFER       => true,   // capture (don’t print)
            CURLOPT_HEADER               => false,
            CURLOPT_CONNECTTIMEOUT_MS    => 1500,
            CURLOPT_TIMEOUT_MS           => 1500,
            CURLOPT_NOSIGNAL             => true,
            CURLOPT_FRESH_CONNECT        => true,
            CURLOPT_FORBID_REUSE         => true,
            CURLOPT_SSL_VERIFYPEER       => true,  // keep ON in prod
            CURLOPT_SSL_VERIFYHOST       => 2,
        ]);
        $ok = @curl_exec($ch);
        Yii::info('cron after TRN: ' . $ok, 'cron_calls');
        if ($ok === false) {
            Yii::error('cron after TRN: failed ' . curl_error($ch), 'cron_calls');
        }
        @curl_close($ch);
    }
    /**
     * Submit a validated transaction to Omannet to get payment URL
     * 
     * @param string $transactionId The transaction ID to submit
     * @return array Response array with payment URL or error
     */
    public function submitTransaction($transactionId)
    {
        // Validate transactionId parameter
        if (empty($transactionId)) {
            return Helpers::errorResponse(400, "Validation failed: transactionId is required.");
        }

        // Find the transaction
        $transaction = Transactions::find()
            ->where(['TransactionID' => $transactionId])
            ->one();

        if (!$transaction) {
            return Helpers::errorResponse(400, "Validation failed: transaction not found.");
        }

        // Check if transaction status is valid for submission
        // Transaction must NOT be in: completed or rejected states
        // "new" status is considered validated and ready for submission
        if (in_array($transaction->transactionStatus->Name, ['Rejected', 'Failed', 'Delivered', 'In Progress'])) {
            return Helpers::errorResponse(409, "The transaction is not in a valid state for submission.");
        }

        // Get payment URL from Omannet using PaymentGateway class
        try {
            $paymentGateway = new \common\classes\PaymentGateway();
            $amount = $transaction->transactionDetails->CollectedAmount;

            $paymentData = [
                'amount' => $amount,
                'trackId' => $transactionId,
                'requestType' => 'payment',
                'action' => '1'
            ];

            $result = $paymentGateway->createPayment($paymentData);


            if (!$result['success']) {
                // Log payment information failed
                $opts = [
                    "statusName" => "Failed",
                    "internal" => TransactionLogs::INTERNALSATUS_INITIATE_PAYMENT_WITH_OMANNET,
                    "source" => TransactionLogs::SOURCE_USER,
                    "requestJson" => $result,
                    "comment" => "try to get payment gateway",
                    "updateTransactionStatus" => true
                ];
                TransactionsHandler::createPayment($transactionId, $opts);
                return Helpers::errorResponse(502, "The Omannet service is unavailable.");
            }



            // Parse the payment URL from response
            $paymentUrl = $result['data'] ?? null;

            if (empty($paymentUrl)) {
                return Helpers::errorResponse(502, "The Omannet service is unavailable.");
            }
            // Log payment information failed
            $opts = [
                "statusName" => "New",
                "internal" => TransactionLogs::INTERNALSATUS_INITIATE_PAYMENT_WITH_OMANNET,
                "source" => TransactionLogs::SOURCE_USER,
                "requestJson" => $result,
                "comment" => "try to get payment gateway",
                "updateTransactionStatus" => true
            ];
            TransactionsHandler::createPayment($transactionId, $opts);
            // Return success response with payment URL
            return [
                'paymentUrl' => $paymentUrl,
                'transactionId' => $transactionId,
                'message' => 'Submission to Omannet completed successfully.'
            ];
        } catch (\Exception $e) {
            \Yii::error("Omannet submission failed: " . $e->getMessage(), __METHOD__);
            return Helpers::errorResponse(502, "The Omannet service is unavailable.");
        }
    }

    /**
     * Validate transaction parameters and their values.
     *
     * @param array $params
     * @return array success: ['ok'=>true,'transaction'=>array,'deliveryMethodEnum'=>DeliveryMethod]
     *               error:   Helpers::errorResponse(...)
     */
    private function validateTransactionParams(array &$params): array
    {
        // --- REQUIRED FIELDS (top-level & transaction) -------------------------
        $required = ['userId', 'beneficiaryId'];
        $transactionRequired = [
            'deliveryMethod',
            'sourceCurrency',
            'receivingCurrency',
            'receivingCountryId',
            'sendingAmount',
            'receivingAmount',
            'transferPurpose',
            'paymentProfileId',
            'rate',
            'fee',
            'vat',
            'finalFee',
            'finalPrice'
        ];

        foreach ($required as $k) {
            if (!array_key_exists($k, $params)) {
                return Helpers::errorResponse(400, "missing parameter: {$k}", []);
            }
            if ($params[$k] === null || $params[$k] === '') {
                return Helpers::errorResponse(400, "empty parameter: {$k}", []);
            }
        }

        if (!array_key_exists("transaction", $params)) {
            return Helpers::errorResponse(400, "missing parameter: {transaction}", []);
        }

        $transactionObj = $params["transaction"];

        foreach ($transactionRequired as $k) {
            if (!array_key_exists($k, $transactionObj)) {
                return Helpers::errorResponse(400, "missing parameter: {$k}", []);
            }
            if ($transactionObj[$k] === null || $transactionObj[$k] === '') {
                return Helpers::errorResponse(400, "empty parameter: {$k}", []);
            }
        }

        // --- VALUE-LEVEL VALIDATIONS ------------------------------------------
        // Top-level numeric IDs
        $intTopLevel = ['userId', 'beneficiaryId'];
        foreach ($intTopLevel as $k) {
            if (!ctype_digit((string)$params[$k]) || (int)$params[$k] <= 0) {
                return Helpers::errorResponse(400, "invalid value for {$k}", []);
            }
        }

        // Transaction integer-like fields (IDs / enums)
        $intTransFields = ['receivingCountryId', 'transferPurpose', 'paymentProfileId'];
        foreach ($intTransFields as $k) {
            if (!ctype_digit((string)$transactionObj[$k]) || (int)$transactionObj[$k] <= 0) {
                return Helpers::errorResponse(400, "invalid value for {$k}", []);
            }
        }

        // Currency codes: 3 uppercase letters (simple sanity check)
        $currencyFields = ['sourceCurrency', 'receivingCurrency'];
        foreach ($currencyFields as $k) {
            $val = strtoupper(trim($transactionObj[$k]));
            if (!preg_match('/^[A-Z]{3}$/', $val)) {
                return Helpers::errorResponse(400, "invalid currency code for {$k}", []);
            }
            $transactionObj[$k] = $val;
        }

        // Amount fields must be numeric and > 0
        $numericPositiveFields = ['sendingAmount', 'receivingAmount', 'rate', 'fee', 'vat', 'finalFee', 'finalPrice'];
        foreach ($numericPositiveFields as $k) {
            if (!is_numeric($transactionObj[$k])) {
                return Helpers::errorResponse(400, "invalid numeric value for {$k}", []);
            }
        }

        // Amount cannot be zero
        $numericPositiveFields = ['sendingAmount', 'receivingAmount', 'rate', 'finalPrice'];
        foreach ($numericPositiveFields as $k) {
            if ((float)$transactionObj[$k] <= 0) {
                return Helpers::errorResponse(400, "{$k} must be greater than 0", []);
            }
        }

        // deliveryMethod must map to a known enum
        $dmEnum = DeliveryMethod::fromName($transactionObj["deliveryMethod"]);
        if ($dmEnum === null) {
            return Helpers::errorResponse(400, "invalid deliveryMethod", []);
        }

        // Arithmetic consistency checks (with tolerance)
        $sendingAmount   = (float)$transactionObj['sendingAmount'];
        $receivingAmount = (float)$transactionObj['receivingAmount'];
        $rate            = (float)$transactionObj['rate'];
        $fee             = (float)$transactionObj['fee'];
        $vat             = (float)$transactionObj['vat'];
        $finalFee        = (float)$transactionObj['finalFee'];
        $finalPrice      = (float)$transactionObj['finalPrice'];

        $tolerance = 0.05; // adjust as you like

        // finalFee ≈ fee + vat
        $calcFinalFee = $fee + $vat;
        if (abs($calcFinalFee - $finalFee) > $tolerance) {
            return Helpers::errorResponse(400, "finalFee does not match fee + vat", [
                // 'expectedFinalFee' => $calcFinalFee,
                // 'providedFinalFee' => $finalFee,
            ]);
        }

        // finalPrice ≈ sendingAmount + finalFee
        $calcFinalPrice = $sendingAmount + $finalFee;
        if (abs($calcFinalPrice - $finalPrice) > $tolerance) {
            return Helpers::errorResponse(400, "finalPrice does not match sendingAmount + finalFee", [
                // 'expectedFinalPrice' => $calcFinalPrice,
                // 'providedFinalPrice' => $finalPrice,
            ]);
        }

        // receivingAmount ≈ sendingAmount * rate
        $calcReceiving = $sendingAmount * $rate;
        if (abs($calcReceiving - $receivingAmount) > $tolerance) {
            return Helpers::errorResponse(400, "receivingAmount does not match sendingAmount * rate", [
                // 'expectedReceivingAmount' => $calcReceiving,
                // 'providedReceivingAmount' => $receivingAmount,
            ]);
        }

        $user = Users::findOne(["UserID" => $params["userId"]]);
        if ($user == null) {
            return Helpers::errorResponse(404, "User not found", []);
        }
        // Optionally normalize back into $params (if you want)
        $params['userId']        = (int)$params['userId'];
        $params['beneficiaryId'] = (int)$params['beneficiaryId'];
        $transactionObj['receivingCountryId'] = (int)$transactionObj['receivingCountryId'];
        $transactionObj['transferPurpose']    = (int)$transactionObj['transferPurpose'];
        $transactionObj['paymentProfileId']   = (int)$transactionObj['paymentProfileId'];

        // Re-assign normalized transaction back
        $params['transaction'] = $transactionObj;

        return [
            'ok'                 => true,
            'transaction'        => $transactionObj,
            'deliveryMethodEnum' => $dmEnum,
        ];
    }
}
