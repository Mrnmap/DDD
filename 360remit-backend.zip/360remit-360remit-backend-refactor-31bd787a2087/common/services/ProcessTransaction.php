<?php

namespace common\services;

use Yii;
use Throwable;
use common\classes\Mastercard;
use common\utility\Helpers;
use common\models\PartnersTransaction;
use common\models\TransactionCompliance;
use common\models\TransactionLogs;
use common\models\Transactions;

class ProcessTransaction
{

    public function process()
    {
        // to process a transaction it must have the following rules:
        // 1. in Transactions column SubmittedAt must not be null and column CurrentStatus must be "In Progress"
        // 3. in PaymentGatewayTransactions column Status must be at least one of these "CAPTURED","APPROVED","SUCESS"
        // 4. in PartnerTransaction column Satus must be "Pending Release"
        // 5. in Beneficiary column Status must be null or activiated 
        // 6. in TransactionCompliance Satus must be null or cleared
        $txnProcess = Transactions::find()
            ->alias('t')
            // 2. CurrentStatus = "In Progress"
            ->innerJoin('TransactionStatus ts', 'ts.Id = t.CurrentStatus')
            // 3. PaymentGatewayTransaction.Status in CAPTURED, APPROVED, SUCCESS
            ->innerJoin('PaymentGatewayTransaction pgt', 'pgt.TransactionID = t.TransactionID')
            // 4. PartnerTransaction.Status = Pending Release
            ->innerJoin('PartnersTransaction pt', 'pt.TransactionID = t.TransactionID')
            // 5. Beneficiary.Status = NULL or Activated
            ->innerJoin('Beneficiaries b', 'b.BeneficiaryID = t.BeneficiaryId')
            // 6. TransactionCompliance optional — may not exist
            ->leftJoin('TransactionCompliance tc', 'tc.TransactionId = t.TransactionID')
            // 1. SubmittedAt NOT NULL
            ->where(['not', ['t.SubmittedAt' => null]])
            ->andWhere(['ts.Name' => 'In Progress'])
            ->andWhere(['in', 'pgt.GatewayStatus', ['CAPTURED', 'APPROVED', 'SUCCESS']])
            ->andWhere(['pt.Status' => 'PENDING RELEASE'])
            ->andWhere([
                'or',
                ['b.Status' => null],
                ['b.Status' => 'activated']
            ])
            ->andWhere([
                'or',
                ['tc.TransactionId' => null],          //  no compliance record
                ['tc.Status' => null],                 //  existing but null
                ['tc.Status' => 'cleared'],             //  or cleared
                ['tc.Status' => 'under review']             //  or under review
            ])
            ->distinct()
            ->all();

        $count =  count($txnProcess);
        if ($count > 0) {
            Yii::info(['found' => $count, 'timestamp' => date('Y-m-d H:i:s'), "started" => true], 'cron_result');
            foreach ($txnProcess as $txn) {
                $result = $this->proceed($txn);
                Yii::info(['timestamp' => date('Y-m-d H:i:s'), 'transactionId' => $txn->TransactionID, 'data' => $result], 'process_transaction_result');
            }
        } else {
            Yii::info(['found' => $count, 'timestamp' => date('Y-m-d H:i:s')], 'process_transaction_result');
        }


        // process transactions that are going to be cancelled
        // 1. transaction must be on "New" status
        // 2. has passed 5 mintues since created
        // 3. has partner transaction on "Pending Release" status

        $stuckTxns = Transactions::find()
            ->alias('t')
            // current status = "New"
            ->innerJoin('TransactionStatus ts', 'ts.Id = t.CurrentStatus')
            // these can be missing, so LEFT JOIN
            ->leftJoin('PaymentGatewayTransaction pgt', 'pgt.TransactionID = t.TransactionID')
            ->leftJoin('PartnersTransaction pt', 'pt.TransactionID = t.TransactionID')
            ->leftJoin('TransactionCompliance tc', 'tc.TransactionId = t.TransactionID')
            ->where(['ts.Name' => 'New'])
            // must NOT be submitted yet
            ->andWhere(['t.SubmittedAt' => null])
            // must be older than 5 minutes
            ->andWhere(['<', 't.CreatedAt', new \yii\db\Expression('NOW() - INTERVAL 5 MINUTE')])
            ->andWhere([
                'or',
                // 1) NOT recorded in PG table
                ['pgt.TransactionID' => null],

                // 2) recorded but funds NOT captured/approved/success
                ['not in', 'pgt.GatewayStatus', ['CAPTURED', 'APPROVED', 'SUCCESS']],

                // 3) NOT recorded in partner transaction
                ['pt.TransactionID' => null],

                // 4) recorded but still pending release
                ['pt.Status' => 'PENDING RELEASE'],

                // 5) NOT recorded in transaction compliance
                ['tc.TransactionId' => null],
            ])
            ->distinct()
            ->all();

        $countStuck =  count($stuckTxns);
        if ($countStuck > 0) {
            Yii::info(['found' => $countStuck, 'timestamp' => date('Y-m-d H:i:s'), "started" => true], 'discontinued_transaction_result');
            foreach ($stuckTxns as $txn) {
                $result = $this->discontinueTransaction($txn);
                Yii::info(['timestamp' => date('Y-m-d H:i:s'), 'transactionId' => $txn->TransactionID, 'data' => $result], 'discontinued_transaction_result');
            }
        } else {
            Yii::info(['found' => $countStuck, 'timestamp' => date('Y-m-d H:i:s')], 'discontinued_transaction_result');
        }



        // TODO: process the transactions that are still in non final state in partner transaction and 
    }

    public function proceed($txn)
    {

        // screen beneficiary
        $beneficiary = $txn->beneficiary;
        if ($beneficiary == null) {
            return "beneficiary not found";
        }
        try {


            // check fisrt if need to screen the beneficiary
            if ($this->doScreenBeneficiary($beneficiary)) {
                $svc = new \common\services\ScreeningService();
                $result = $svc->scanBeneficiary($beneficiary);
                $opts = [
                    "statusName" => "",
                    "internal" => TransactionLogs::INTERNALSATUS_COMPLIANCE_SCREENING,
                    "source" => TransactionLogs::SOURCE_PARTNER,
                    "comment" => "",
                    "requestJson" => $result,
                    "updateTransactionStatus" => true
                ];
                $saveUpdateResult = TransactionsHandler::logTransaction($txn->TransactionID, $opts);
                if ($result["sucess"] == false || $saveUpdateResult["ok"] == false) {
                    return $this::fail("failed to scan beneficiary", [$result, $saveUpdateResult]);
                }
            }

            // update transaction compliance wheather beneficiary screened or not
            $result = TransactionsHandler::createOrUpdateTransactionCompliance($txn->TransactionID, ["reason" => "beneficiary screening"]);
            if ($result["ok"] == false) {
                return $this::fail($result["message"], $result["errors"]);
            }

            // now to release the transaction with mastercard, beneficiary and transaction compliance must be cleared
            $txnCompliance = TransactionCompliance::findOne(["TransactionId" => $txn->TransactionID]);
            if (!($beneficiary->isStatusActivated() && $txnCompliance->isStatusCleared())) {
                return $this::fail("beneficiary is not activated or transaction is not cleared", []);
            }
            // release in mastercard
            $mc = new Mastercard();
            $releaseResult = $mc->releaseTransaction($txn->TransactionID);
            if ($releaseResult != null && $releaseResult["sucess"] == true) {
                $data = $releaseResult["data"];
                $saveResult = TransactionsHandler::createOrUpdatePartnerTransaction($txn->TransactionID, $data["TfPin"], $data["StatusName"], null, $data);
                if (isset($saveResult["ok"]) && $saveResult["ok"] == true) {
                    //log sucess 
                    $opts = [
                        "statusName" => $saveResult["transactionStatus"],
                        "internal" => TransactionLogs::INTERNALSATUS_RELEASED_IN_MASTERCARD,
                        "source" => TransactionLogs::SOURCE_SYSTEM,
                        "requestJson" => $data,
                        "comment" => "release in mastercard",
                        "updateTransactionStatus" => true
                    ];
                    TransactionsHandler::logTransaction($txn->TransactionID, $opts);
                } else {
                    $opts = [
                        "statusName" => $saveResult["transactionStatus"],
                        "internal" => TransactionLogs::INTERNALSATUS_RELEASED_IN_MASTERCARD,
                        "source" => TransactionLogs::SOURCE_SYSTEM,
                        "requestJson" => $data,
                        "comment" => "falied to save release in mastercard",
                        "updateTransactionStatus" => true
                    ];
                    TransactionsHandler::logTransaction($txn->TransactionID, $opts);
                    return self::fail('Could save the partner transaction', []);
                }
            } else {
                $opts = [
                    "statusName" => "",
                    "internal" => TransactionLogs::INTERNALSATUS_RELEASED_IN_MASTERCARD,
                    "source" => TransactionLogs::SOURCE_SYSTEM,
                    "requestJson" => $releaseResult,
                    "comment" => "falied to release in mastercard",
                    "updateTransactionStatus" => false
                ];
                TransactionsHandler::logTransaction($txn->TransactionID, $opts);
                return $releaseResult;
            }
        } catch (Throwable $e) {
            return self::fail('Exception while creating transaction: ' . $e->getMessage(), []);
        }
    }

    public function discontinueTransaction($txn)
    {
        //
        // check if it is on pending release
        // canel from mastercard
        // log cancel and update status

        $txnPartner = PartnersTransaction::findOne(["TransactionID" => $txn->TransactionID]);
        if ($txnPartner != null) {
            $mc = new Mastercard();
            if ($txnPartner->Status == "PENDING RELEASE") {
                $result = $mc->cancelTransaction($txn->TransactionID, "system");
                $saved = TransactionsHandler::saveCancelTransaction($txn->TransactionID, $result);
                if ($saved["ok"] == false) {
                    return Helpers::errorResponse(400, $saved["message"], $saved["errors"]);
                }
            }
        } else {
            $opts = [
                "statusName" => "Failed",
                "internal" => TransactionLogs::INTERNALSATUS_CANCELED_BY_SYSTEM,
                "source" => TransactionLogs::SOURCE_SYSTEM,
                "comment" => "transaction was canceled by system",
                "updateTransactionStatus" => true,
            ];
            TransactionsHandler::logTransaction($txn->TransactionID, $opts);
        }
    }
    public function doScreenBeneficiary($beneficiary): bool
    {
        // to screen beneficiary LastSceeningAt should be null
        // TODO LATER: add more conditions later for scaning on period

        if ($beneficiary->LastSceeningAt == null || $beneficiary->Status == null) {
            return true;
        }

        return false;
    }

    public static function fail($message, array $errors)
    {
        return Helpers::errorResponse(400, $message, $errors);
    }
}
