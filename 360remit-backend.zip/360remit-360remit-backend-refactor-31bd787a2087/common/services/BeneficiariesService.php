<?php

namespace common\services;

use api\models\BeneficiariesSearch;
use common\models\Beneficiaries;
use common\models\BeneficiaryBankAccounts;
use common\models\Banks;
use common\utility\Helpers;
use Symfony\Component\CssSelector\Parser\Handler\WhitespaceHandler;
use Yii;
use yii\db\Query;
use yii\helpers\ArrayHelper;
use DateTime;
use DateTimeZone;
use Exception;

class BeneficiariesService
{
    public function getBeneficiaries($params)
    {
        $sort = $params['sort'] ?? null;
        $page = intval($params['page']);
        $page = $page > 0 ? $page - 1 : 0;
        $limit = intval($params['limit']);

        if ($limit <= 0) {
            return Helpers::errorResponse(400, "limit must be more than 0 !", []);
        }
        $userID = $params['user_id'] ?? null;
        $params = [
            "pageSize" => $limit,
            "BeneficiariesSearch" => [
                "UserID" => $userID
            ]

        ];
        $searchModel = new BeneficiariesSearch();
        $search = $searchModel->search($params);

        $search->pagination->page = $page;
        $beneficiaries = $search->getModels();

        $beneficiariesList = [];
        foreach ($beneficiaries as $beneficiary) {
            $item = [
                'id' => $beneficiary->BeneficiaryID,
                'countryId' => $beneficiary->nationality->CountryID,
                'beneficiaryName' => $beneficiary->FirstName . " " . $beneficiary->LastName,
                'phoneNumber' => $beneficiary->Phone
            ];
            $beneficiariesList[] = $item;
        }
        $pagination = $search->getPagination();
        return [
            "beneficiaries" => $beneficiariesList,
            "totalElements" => $search->getTotalCount(),
            "totalPages" => $pagination->getPageCount(),
            "currentPage" => ($pagination->getPage() + 1)
        ];
    }
    public function getBankAccounts($userId, $beneficiaryId) {}
    public function getWallets($userId, $beneficiaryId) {}
    public function addBeneficiary($userId, $beneficiaryObject)
    {
        try {
            // Normalize input to array
            $data = is_object($beneficiaryObject) ? (array)$beneficiaryObject : $beneficiaryObject;

            $beneficiary = new Beneficiaries();
            $beneficiary->UserID = $userId;

            // Required names
            $beneficiary->FirstName  = $this->toStringOrEmpty($data['firstName'] ?? null);
            $beneficiary->LastName   = $this->toStringOrEmpty($data['lastName']  ?? null);

            // Optionals (empty string -> NULL)
            $beneficiary->MiddleName = $this->toNullString($data['middleName'] ?? null);
            $beneficiary->Phone      = $this->toNullString($data['phone']      ?? null);

            // Cast numerics from body strings like "19" / "1"
            $beneficiary->Nationality = $this->toNullInt($data['nationality'] ?? null);
            $beneficiary->Relation    = $this->toNullInt($data['relation']    ?? null);

            // Gender: normalize case and validate against enum keys
            $genderIn = $this->toNullString($data['gender'] ?? null);
            if ($genderIn !== null) {
                $genderNorm = ucfirst(strtolower($genderIn)); // "Male" / "Female"
                if (array_key_exists($genderNorm, Beneficiaries::optsGender())) {
                    $beneficiary->Gender = $genderNorm;
                } else {
                    // Let validation catch invalid gender with model rule
                    $beneficiary->Gender = $genderNorm;
                }
            }

            // Timestamps (Asia/Muscat)
            $now = (new \DateTimeImmutable('now', new \DateTimeZone('Asia/Muscat')))->format('Y-m-d H:i:s');
            $beneficiary->OnDate      = $now;
            $beneficiary->UpdatedDate = $now;

            // (Optional) set initial status if you want a default
            // $beneficiary->Status = Beneficiaries::STATUS_UNDER_REVIEW;

            // Validate before save to return 422 instead of generic DB error
            if (!$beneficiary->validate()) {
                return Helpers::errorResponse(422, 'Validation failed', $beneficiary->getErrors());
            }

            if (!$beneficiary->save(false)) {
                return Helpers::errorResponse(500, 'Could not save beneficiary');
            }

            // Return something useful on success (you can switch back to "" if you prefer)
            return [
                'beneficiaryId' => (int)$beneficiary->BeneficiaryID,
                'userId'        => (int)$beneficiary->UserID,
                'firstName'     => $beneficiary->FirstName,
                'middleName'    => $beneficiary->MiddleName,
                'lastName'      => $beneficiary->LastName,
                'phone'         => $beneficiary->Phone,
                'nationality'   => $beneficiary->Nationality,
                'relation'      => $beneficiary->Relation,
                'gender'        => $beneficiary->Gender,
                'status'        => $beneficiary->Status,
                'createdAt'     => $beneficiary->OnDate,
            ];
            // If you strictly want your original behavior:
            // return "";
        } catch (\Throwable $e) {
            Yii::error(['msg' => $e->getMessage(), 'trace' => $e->getTraceAsString()], __METHOD__);
            return Helpers::errorResponse(500, 'Unexpected error while creating beneficiary');
        }
    }
    public function addBankAccount($userId, $beneficiaryId, $data)
    {
        $bankAccount = new BeneficiaryBankAccounts();
        try {
            $bankAccount->UserId = $userId;
            $bankAccount->CreateUId = $userId;
            $bankAccount->UpdateUId = $userId;
            $bankAccount->CountryId = $data["countryId"];
            $bankAccount->OnDate = date('Y-m-d H:i:s');
            $bankAccount->BankId = $data["bankId"];
            $bankAccount->BranchId = $data["branchId"];
            $bankAccount->AccountNumber = $data["account"];
            $bankAccount->BankingIdentifier = $data["accountReference"];
            $bankAccount->BeneficiaryId = $beneficiaryId;
            $bankAccount->AccountPhone = $data["accountPhone"];
            
            $addressString = $data["address"] ?? null;
            
            if (is_array($addressString)) {
                $bankAccount->AddressRegion = $addressString["region"] ?? null;
                $bankAccount->AddressCity = $addressString["city"] ?? null;
                $bankAccount->AddressStreet = $addressString["street"] ?? null;
                $bankAccount->AddressHouse = $addressString["house"] ?? null;
                $bankAccount->Address = $this->combineAddress(
                    $addressString["city"] ?? null,
                    $addressString["street"] ?? null,
                    $addressString["house"] ?? null,
                    $addressString["region"] ?? null
                );
            } else {
                $bankAccount->Address = $addressString;
                $bankAccount->AddressRegion = null;
                $bankAccount->AddressCity = null;
                $bankAccount->AddressStreet = null;
                $bankAccount->AddressHouse = null;
            }
        } catch (Exception $ex) {
            return Helpers::errorResponse(400, $ex->getMessage(), []);
        }

        if (!$bankAccount->save()) {
            return Helpers::errorResponse(400, "", $bankAccount->getErrors());
        } else {
            return Yii::$app->response->statusCode = 201;
        }
    }
    public function updateBeneficiary($userId, $beneficiaryId, $beneficiaryObject)
    {

        $beneficiary = Beneficiaries::find()->where(["BeneficiaryID" => $beneficiaryId, "UserID" => $userId, "IsDelete" => 0])->one();
        if ($beneficiary !== null) {
            // set up attributes
            $newArray = [];
            foreach ($beneficiaryObject as $key => $object) {
                $newKey = ucfirst($key);
                $newArray[$newKey] = $object;
            }
            // set values
            $beneficiary->setAttributes($newArray);

            $attributesToValidate = array_keys($newArray);
            if (!$beneficiary->save(true, $attributesToValidate)) {
                return Helpers::errorResponse(400, "", $beneficiary->getErrors());
            }
        } else {
            //beneficiary not found
            return Helpers::errorResponse(404, "beneficiary not found", []);
        }
        return Yii::$app->response->statusCode = 204;
    }
    public function updateBankAccount($userId, $beneficiaryId, $bankAccountId, $data)
    {
        $bankAccount = BeneficiaryBankAccounts::find()->where(["BeneficiaryId" => $beneficiaryId, "UserId" => $userId, "IsDelete" => 0, "BeneficiaryBankAccountId" => $bankAccountId])->one();
        if ($bankAccount !== null) {
            $addressString = $data['address'] ?? null;
            
            $newArray = [
                'CountryId'         => $data['countryId'],
                'BankId'            => $data['bankId'],
                'BranchId'          => $data['branchId'],
                'AccountNumber'     => $data['account'],
                'BankingIdentifier' => $data['accountReference'],
                'BeneficiaryId'     => $beneficiaryId,
                'AccountPhone'      => $data['accountPhone'] ?? null,
            ];
            
            if (is_array($addressString)) {
                $newArray['AddressRegion'] = $addressString['region'] ?? null;
                $newArray['AddressCity'] = $addressString['city'] ?? null;
                $newArray['AddressStreet'] = $addressString['street'] ?? null;
                $newArray['AddressHouse'] = $addressString['house'] ?? null;
                $newArray['Address'] = $this->combineAddress(
                    $addressString['city'] ?? null,
                    $addressString['street'] ?? null,
                    $addressString['house'] ?? null,
                    $addressString['region'] ?? null
                );
            } else {
                $newArray['Address'] = $addressString;
                $newArray['AddressRegion'] = null;
                $newArray['AddressCity'] = null;
                $newArray['AddressStreet'] = null;
                $newArray['AddressHouse'] = null;
            }
            
            $bankAccount->setAttributes($newArray);
            $attributesToValidate = array_keys($newArray);
            $bankAccount->UpdatedDate = date('Y-m-d H:i:s');

            if (!$bankAccount->save(true, $attributesToValidate)) {
                return Helpers::errorResponse(400, "", $bankAccount->getErrors());
            }
        } else {
            //beneficiary not found
            return Helpers::errorResponse(404, "bankAccount not found", []);
        }
        return Yii::$app->response->statusCode = 204;
    }
    public function updateWallet($userId, $beneficiaryObject) {}
    public function deleteBeneficiary($userId, $beneficiaryId)
    {
        $beneficiary = Beneficiaries::find()->where(["BeneficiaryID" => $beneficiaryId, "UserID" => $userId, "IsDelete" => 0])->one();
        if ($beneficiary !== null) {
            $beneficiary->IsDelete = 1;
            if (!$beneficiary->save(false)) {
                return Helpers::errorResponse(400, "", $beneficiary->getErrors());
            }
        } else {
            //beneficiary not found
            return Helpers::errorResponse(404, "beneficiary not found", []);
        }
        return Yii::$app->response->statusCode = 204;
    }

    public function deleteBankAccount($userID, $beneficiaryId, $bankAccountId)
    {
        $model = BeneficiaryBankAccounts::findOne(['BeneficiaryBankAccountId' => $bankAccountId, 'BeneficiaryId' => $beneficiaryId, 'UserId' => $userID, "IsDelete" => 0]);

        if ($model == null) {
            return Helpers::errorResponse(404, 'Beneficiary\'s bank account not found');
        }

        $model->IsDelete = 1;
        $model->UpdatedDate = date('Y-m-d H:i:s');
        if (!$model->save()) {
            return Helpers::errorResponse(400, "", $model->getErrors());
        }
        return Yii::$app->response->statusCode = 204;
    }
    public function deleteWallet($userId, $beneficiaryId) {}
    public function getBeneficiariesByTransactions($userId, $transactionsLimit) {}

    public function getBeneficiaryDetails($id, $userId = null)
    {
        $query = Beneficiaries::find()
            ->with('beneficiaryBankAccounts')->joinWith('relations')->joinWith('nationality')
            ->where(['BeneficiaryID' => $id, 'Beneficiaries.IsDelete' => 0]);

        // Add user filter if userId is provided
        if ($userId !== null) {
            $query->andWhere(['UserID' => $userId]);
        }

        $beneficiary = $query->one();

        if (!$beneficiary) {
            return null;
        }

        // Format the response
        $result = [
            'beneficiaryId' => $beneficiary->BeneficiaryID,
            'firstName' => $beneficiary->FirstName,
            'middleName' => $beneficiary->MiddleName,
            'lastName' => $beneficiary->LastName,
            'email' => $beneficiary->Email,
            'phone' => $beneficiary->Phone,
            'nationalityId' => $beneficiary->Nationality,
            'nationalityName' => $beneficiary->nationality->Nationality,
            'gender' => $beneficiary->Gender,
            'relationId' => $beneficiary->Relation,
            'relationName' => $beneficiary->relations->RelationName,
        ];

        // Format bank accounts
        $bankAccounts = [];
        foreach ($beneficiary->beneficiaryBankAccounts as $bankAccount) {
            $flagName = strtolower($bankAccount->country->CountryName);
            $flagName = str_replace(' ', '-', $flagName);
            $imagePath = Yii::getAlias('@flagsDirectory') . "/" . $flagName . '.png';
            $imageBase64 = Helpers::imageToBase64($imagePath);

            $bankAccounts[] = [
                'bankAccountId' => $bankAccount->BeneficiaryBankAccountId,
                'bankId' => $bankAccount->BankId,
                'bankName' => $bankAccount->bank->Name,
                'branchId' => $bankAccount->BranchId,
                'branchName' => $bankAccount->branch->Branch ?? $bankAccount->branch->ID ?? "",
                'account' => $bankAccount->AccountNumber,
                'accountReference' => $bankAccount->BankingIdentifier,
                'countryId' => $bankAccount->CountryId,
                'countryName' => $bankAccount->country->CountryName,
                'countryFlag' => $imageBase64,
                'accountPhone' => $bankAccount->AccountPhone,
                'address' => $bankAccount->Address ?? $this->combineAddress(
                    $bankAccount->AddressCity,
                    $bankAccount->AddressStreet,
                    $bankAccount->AddressHouse,
                    $bankAccount->AddressRegion
                )
            ];
        }

        $result['bankAccounts'] = $bankAccounts;
        $result['wallets'] = []; // Empty for MVP

        return $result;
    }


    /**
     * Helpers
     */
    private function toNullString($v): ?string
    {
        if ($v === null) return null;
        $s = is_string($v) ? trim($v) : (string)$v;
        return $s === '' ? null : $s;
    }

    private function toStringOrEmpty($v): string
    {
        if ($v === null) return '';
        $s = is_string($v) ? trim($v) : (string)$v;
        return $s;
    }

    private function toNullInt($v): ?int
    {
        if ($v === null || $v === '') return null;
        if (is_numeric($v)) return (int)$v;
        return null;
    }

    /**
     * Combines address parts into a single address string
     * Format: "City, Street, House" (e.g., "Moscow, Main street, 1")
     * 
     * @param string|null $city
     * @param string|null $street
     * @param string|null $house
     * @param string|null $region
     * @return string|null
     */
    private function combineAddress(?string $city, ?string $street, ?string $house, ?string $region = null): ?string
    {
        $parts = [];
        
        if (!empty($city)) {
            $parts[] = $city;
        }
        if (!empty($street)) {
            $parts[] = $street;
        }
        if (!empty($house)) {
            $parts[] = $house;
        }
        
        // If no parts, return null
        if (empty($parts)) {
            return null;
        }
        
        // Join with comma and space
        return implode(', ', $parts);
    }
}
