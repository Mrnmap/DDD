<?php

namespace common\services;

use Yii;
use Exception;
use yii\db\Query;
use yii\helpers\ArrayHelper;
use common\classes\Mastercard;
use common\models\Beneficiaries;
use common\models\Transactions;
use common\models\Currencies;
use common\utility\Helpers;
use yii\db\Expression;
use common\classes;
use common\classes\DeliveryMethod;
use common\models\Banks;
use common\models\BeneficiaryBankAccounts;
use common\models\Countries;
use common\models\CountryCurrencies;
use common\models\FeeRules;
use common\models\MarkupRules;

class PricingService
{
    public $beneficiaryId;
    public $userId;
    public function getPricingCalculations(array $params)
    {


        // ---------- 1) Required params (base) ----------
        $required = ['sourceCurrency', 'receivingCurrency', 'receivingCountryId', 'deliveryMethod', 'sendingAmount'];
        foreach ($required as $k) {
            if (!array_key_exists($k, $params)) {
                return Helpers::errorResponse(400, "missing parameter: {$k}", []);
            }
            if ($params[$k] === null || $params[$k] === '') {
                return Helpers::errorResponse(400, "empty parameter: {$k}", []);
            }
        }

        // ---------- 2) Normalize & basic format checks ----------
        $rateProvider     = $params['rateProvider'] ?? 'Mastercard';
        $deliveryMethod   = trim((string)$params['deliveryMethod']);
        $beneficiaryId    = $params['beneficiaryId'] ?? null;
        $paymentProfileId = $params['paymentProfileId'] ?? null;
        $sendingAmountStr = (string)$params['sendingAmount'];
        $srcCurrency      = strtoupper(trim((string)$params['sourceCurrency']));
        $rcvCurrency      = strtoupper(trim((string)$params['receivingCurrency']));
        $rcvCountryId     = $params['receivingCountryId'];
        $this->userId     = $params['user_id'];
        $this->beneficiaryId = $beneficiaryId;

        if (!preg_match('/^[A-Z]{3}$/', $srcCurrency)) {
            return Helpers::errorResponse(400, "invalid sourceCurrency (ISO 4217, e.g. 'OMR')", []);
        }
        if (!preg_match('/^[A-Z]{3}$/', $rcvCurrency)) {
            return Helpers::errorResponse(400, "invalid receivingCurrency (ISO 4217, e.g. 'INR')", []);
        }
        if (!is_numeric($rcvCountryId)) {
            return Helpers::errorResponse(400, "receivingCountryId must be numeric", []);
        }
        if (!is_numeric($this->userId)) {
            return Helpers::errorResponse(400, "user_id must be numeric", []);
        }

        // For now only Mastercard is supported; reject other providers explicitly
        if (strcasecmp($rateProvider, 'Mastercard') !== 0) {
            return Helpers::errorResponse(400, "unsupported rateProvider: {$rateProvider}", []);
        }

        // ---------- 3) Resolve delivery method ----------
        $mc = new Mastercard();
        $dmEnum = DeliveryMethod::fromName($deliveryMethod);
        if ($dmEnum === null) {
            return Helpers::errorResponse(400, "invalid deliveryMethod", []);
        }

        // ---------- 4) Load country & currency metadata ----------
        $country = Countries::find()->where(["CountryID" => (int)$rcvCountryId, "Enable" => 1])->one();
        if ($country === null) {
            return Helpers::errorResponse(400, "receiving country not found or disabled", []);
        }

        $srcCurRow = Currencies::find()->where(["CurrencyCode" => $srcCurrency])->one();
        if ($srcCurRow === null) {
            return Helpers::errorResponse(400, "source currency not supported", []);
        }
        $rcvCurRow = Currencies::find()->where(["CurrencyCode" => $rcvCurrency])->one();
        if ($rcvCurRow === null) {
            return Helpers::errorResponse(400, "receiving currency not supported", []);
        }

        $srcDec = (int)$srcCurRow->DecimalDigits;
        $rcvDec = (int)$rcvCurRow->DecimalDigits;

        // Optional: corridor constraint (if your partner forbids same-currency corridors)
        // if ($srcCurrency === $rcvCurrency) {
        //     return Helpers::errorResponse(400, "sourceCurrency and receivingCurrency must differ", []);
        // }

        // ---------- 5) Validate sendingAmount as numeric-string & decimals vs currency ----------
        if (!$this->isNumericString($sendingAmountStr)) {
            return Helpers::errorResponse(400, "sendingAmount must be numeric", []);
        }
        if (!$this->hasValidDecimals($sendingAmountStr, $srcDec)) {
            return Helpers::errorResponse(400, "sendingAmount has more than {$srcDec} decimal places", []);
        }
        $sendingAmount = (string)$this->bc_trunc($sendingAmountStr, $srcDec); // keep as string for BCMath

        // Min/Max (configure as needed)
        // $minAmt = isset(Yii::$app->params['minSendingAmount']) ? (string)Yii::$app->params['minSendingAmount'] : '1';
        // $maxAmt = isset(Yii::$app->params['maxSendingAmount']) ? (string)Yii::$app->params['maxSendingAmount'] : '1000';

        if (bccomp($sendingAmount, 1, $srcDec) < 0) {
            return Helpers::errorResponse(400, "sendingAmount below minimum (1)", []);
        }
        if (bccomp($sendingAmount, 1000, $srcDec) > 0) {
            return Helpers::errorResponse(400, "sendingAmount above maximum (1000)", []);
        }

        // ---------- 6) Conditional checks for Bank Deposit ----------
        $payerId = '';
        if ($dmEnum == DeliveryMethod::BankDeposit) {
            // Require beneficiary & payment profile for bank deposits
            if (!is_numeric($beneficiaryId) || !is_numeric($paymentProfileId)) {
                return Helpers::errorResponse(400, "beneficiaryId and paymentProfileId are required for bank deliveryMethod", []);
            }

            // Ensure beneficiary belongs to user (if that’s your rule)
            $beneficiary = Beneficiaries::findOne(["BeneficiaryID" => (int)$beneficiaryId, "UserID" => (int)$this->userId]);
            if ($beneficiary === null) {
                return Helpers::errorResponse(400, "beneficiary not found for this user", []);
            }

            $bankAccount = BeneficiaryBankAccounts::findOne([
                "UserId" => (int)$this->userId,
                "BeneficiaryId" => (int)$this->beneficiaryId,
                "BeneficiaryBankAccountId" => (int)$paymentProfileId,
                "CountryId" => (int)$rcvCountryId,
            ]);
            if ($bankAccount === null) {
                return Helpers::errorResponse(400, "payment profile not found for the receiving country", []);
            }

            // Ensure mapping to a Mastercard payer exists
            $payerId = $bankAccount->bank->MCBankID ?? '';
            if ($payerId === null || trim($payerId) === '') {
                return Helpers::errorResponse(400, "Mastercard payer not found for this bank", []);
            }
        }

        // ---------- 7) (Optional) check currency allowed for country ----------
        // If you maintain a Countries<->Currencies mapping, validate here.
        // if (!CountryCurrencies::isAllowed($country->CountryID, $rcvCurrency)) {
        //     return Helpers::errorResponse(400, "receivingCurrency not allowed for selected country", []);
        // }

        // ---------- 8) Partner quote ----------

        $quote = $mc->getCalculation($dmEnum, $rcvCurrency, $country->CountryCode, $srcCurrency, $sendingAmount, $payerId);
        if (!$quote || !isset($quote["TransactionRate"])) {
            return Helpers::errorResponse(400, "error in partner connection", []);
        }

        // Sanity check on rate
        if (!is_numeric($quote["TransactionRate"]) || (float)$quote["TransactionRate"] <= 0) {
            return Helpers::errorResponse(400, "partner returned invalid rate", []);
        }

        // ---------- 9) Markup ----------
        $rawRateFloat = (float)$quote["TransactionRate"];
        $rawRate = (string)$this->calculateMarkup($rawRateFloat, $rcvCurrency, (int)$rcvCountryId, $dmEnum->system());
        if ($rawRate === '-1') {
            return Helpers::errorResponse(400, "error in calculation (markup rules not found)", []);
        }
        // Display rate (4 d.p.)
        $rateDisplay = $this->bc_round($rawRate, 4);
        if (bccomp($rateDisplay, '0', 4) <= 0) {
            return Helpers::errorResponse(400, "calculated rate is invalid", []);
        }

        // ---------- 10) Receiving amount ----------
        $recvCalc        = bcmul($sendingAmount, $rateDisplay, $rcvDec + 6);
        $receivingAmount = $this->bc_trunc($recvCalc, $rcvDec);
        if (bccomp($receivingAmount, '0', $rcvDec) <= 0) {
            return Helpers::errorResponse(400, "calculated receiving amount is invalid", []);
        }

        // Inverse rate from displayed rate
        // Guard against divide-by-zero even though we checked > 0
        $inverseRate = $this->bc_round(bcdiv('1', $rateDisplay, 12), 8);

        // ---------- 11) Fee & VAT ----------
        $feeBase = $this->calculateFee("0", $sendingAmount, (int)$rcvCountryId, $dmEnum->system());
        if ($feeBase === -1 || $feeBase === '-1') {
            return Helpers::errorResponse(400, "error in fee calculation", []);
        }
        $feeFinalStr = $this->bc_trunc((string)$feeBase, $srcDec);

        // VAT rate from config (validate)
        $vatRate = isset(Yii::$app->params['vatRate']) ? (string)Yii::$app->params['vatRate'] : '0.05';
        if (!$this->isNumericString($vatRate) || bccomp($vatRate, '0', 4) < 0 || bccomp($vatRate, '1', 4) > 0) {
            return Helpers::errorResponse(500, "misconfigured vatRate", []);
        }

        $vatAmount  = $this->bc_round(bcmul($feeFinalStr, $vatRate, $srcDec + 6), $srcDec);
        $finalFee   = $this->bc_trunc(bcadd($feeFinalStr, $vatAmount, $srcDec + 2), $srcDec);
        $finalPrice = $this->bc_trunc(bcadd($sendingAmount, $finalFee, $srcDec + 2), $srcDec);

        // ---------- 12) Success payload ----------
        date_default_timezone_set('Asia/Muscat');
        return [
            "deliveryMethod" => $deliveryMethod,
            "rateProvider"   => $rateProvider,
            "corridor"       => $srcCurrency . " -> " . $rcvCurrency,
            "asOf"           => date('Y-m-d H:i:s'),
            "rate"           => $rateDisplay,     // string, 4 d.p.
            "inverseRate"    => $inverseRate,     // string, 8 d.p.
            "source" => [
                "currency" => $srcCurrency,
                "amount"   => $this->bc_trunc($sendingAmount, $srcDec),
                "decimals" => $srcDec,
            ],
            "receiving" => [
                "currency" => $rcvCurrency,
                "amount"   => $receivingAmount,
                "decimals" => $rcvDec,
            ],
            "fee"        => $feeFinalStr,         // base fee
            "vat"        => $vatAmount,
            "finalFee"   => $finalFee,            // fee + vat
            "finalPrice" => $finalPrice,          // amount + finalFee
        ];
    }

    /** Helpers **/
    private function isNumericString(string $v): bool
    {
        // accepts plain decimal or integer; rejects non-numeric
        $v = trim($v);
        if ($v === '') return false;
        // Disallow scientific notation for pricing inputs
        return preg_match('/^-?\d+(\.\d+)?$/', $v) === 1;
    }
    public function calculateFee($currentFee, $sentAmount, $receiveCountryId, $deliveryMethodId)
    {
        $country = Countries::find()->where(["CountryID" => $receiveCountryId, "Enable" => 1])->one();
        if ($country->CountryCode == "PK" && $this->isZeroRating($sentAmount)) {
            return 0;
        } else {
            return $this->appliedFee($currentFee, $receiveCountryId, "1");
        }
    }

    public function isZeroRating($amount)
    {
        // this function is to determine is this transaction elgible for zero fees.
        // TODO LATER: include bank account check and name check in the query 
        $beneficiary = Beneficiaries::find()->where(['UserId' => $this->userId, 'BeneficiaryId' => $this->beneficiaryId])->one();
        if ($beneficiary == null) {
            return false;
        }
        $countDailyTx = Transactions::find()
            ->where(['UserId' => $this->userId, 'BeneficiaryId' => $this->beneficiaryId])
            ->andWhere(['>=', 'CreatedAt', new \yii\db\Expression('NOW() - INTERVAL 24 HOUR')])->count();

        $countMonthlyTx = Transactions::find()
            ->where(['UserId' => $this->userId, 'BeneficiaryId' => $this->beneficiaryId])
            ->andWhere(['>=', 'CreatedAt', new \yii\db\Expression('NOW() - INTERVAL 1 MONTH')])->count();

        // Conditions:
        // first condition one transaction per sender/beneficiary combination
        // second condition less than or equal to 5 transaction per sender/beneficiary combination 
        // third condition is the amount is more than or equal to 77 OMR or $200

        // TODO LATER: find a way to calculate the amount sent if it's not within the parameters
        if ($countDailyTx == 0  && $countMonthlyTx <= 5 && $amount >= 77) {
            return true;
        } else {
            return false;
        }
    }

    public function appliedFee($currentFee, $receiveCountryId, $deliveryMethodId)
    {
        $rule = FeeRules::find()->joinWith(["country"])
            ->where(["DeliveryMethodId" => $deliveryMethodId, "Countries.CountryID" => $receiveCountryId])->one();


        // LATER: determine if the $currentFee is less than the fee from the rules to count the loss
        if ($rule != null) {
            if ($currentFee > $rule->FixedFee) {
                return $currentFee;
            } else {
                return $rule->FixedFee;
            }
        }

        return -1;
    }

    public function calculateMarkup($currentRate, $currencyCode, $receiveCountryId, $deliveryMethodId)
    {
        $rule = MarkupRules::find()->joinWith(["country"])
            ->where(["CurrencyCode" => $currencyCode, "DeliveryMethodId" => $deliveryMethodId, "Countries.CountryID" => $receiveCountryId])->one();

        if ($rule != null) {
            $markup = (float) $rule->MarkupValuePercent;
            $markupAmount = $currentRate * ($markup / 100);
            $newExchangeRate = $currentRate - $markupAmount;

            return $newExchangeRate;
        }
        return -1;
    }

    public function getExchangeRate(array $params)
    {
        // ---------- Basic required params ----------
        $required = ['sourceCurrency', 'receivingCurrency', 'receivingCountryId', 'deliveryMethod', 'sendingAmount'];
        foreach ($required as $k) {
            if (!array_key_exists($k, $params)) {
                return Helpers::errorResponse(400, "missing parameter: {$k}", []);
            }
            if ($params[$k] === null || $params[$k] === '') {
                return Helpers::errorResponse(400, "empty parameter: {$k}", []);
            }
        }

        // ---------- Types & simple format checks ----------
        $params['sourceCurrency']     = strtoupper(trim($params['sourceCurrency']));
        $params['receivingCurrency']  = strtoupper(trim($params['receivingCurrency']));
        $params['deliveryMethod']     = trim($params['deliveryMethod']);

        if (!preg_match('/^[A-Z]{3}$/', $params['sourceCurrency'])) {
            return Helpers::errorResponse(400, "invalid sourceCurrency (must be ISO 4217, e.g. 'OMR')", []);
        }
        if (!preg_match('/^[A-Z]{3}$/', $params['receivingCurrency'])) {
            return Helpers::errorResponse(400, "invalid receivingCurrency (must be ISO 4217, e.g. 'INR')", []);
        }
        if (!is_numeric($params['receivingCountryId'])) {
            return Helpers::errorResponse(400, "receivingCountryId must be numeric", []);
        }
        if (!is_numeric($params['sendingAmount'])) {
            return Helpers::errorResponse(400, "sendingAmount must be numeric", []);
        }

        $sendingAmount = (float)$params['sendingAmount'];
        if ($sendingAmount <= 0) {
            return Helpers::errorResponse(400, "sendingAmount must be more than 0", []);
        }

        // Optional: reasonable upper-bound to prevent overflow / abuse
        if ($sendingAmount > 1000) {
            return Helpers::errorResponse(400, "sendingAmount must be or less than 1000", []);
        }

        // ---------- Resolve delivery method ----------
        $mastercard = new Mastercard();
        $deliveryMethod = DeliveryMethod::fromName($params['deliveryMethod'] ?? null);
        if ($deliveryMethod === null) {
            return Helpers::errorResponse(400, "invalid deliveryMethod", []);
        }

        // ---------- Validate currencies exist ----------
        $sourceCurrency = Currencies::find()->where(["CurrencyCode" => $params["sourceCurrency"]])->one();
        if ($sourceCurrency === null) {
            return Helpers::errorResponse(400, "source currency not supported", []);
        }
        $receiveCurrency = Currencies::find()->where(["CurrencyCode" => $params["receivingCurrency"]])->one();
        if ($receiveCurrency === null) {
            return Helpers::errorResponse(400, "receiving currency not supported", []);
        }

        // ---------- Decimal precision validation for sendingAmount ----------
        if (!$this->hasValidDecimals((string)$params['sendingAmount'], (int)$sourceCurrency->DecimalDigits)) {
            return Helpers::errorResponse(400, "sendingAmount has more than {$sourceCurrency->DecimalDigits} decimal places", []);
        }

        // ---------- Receiving country validation ----------
        $receiveCountry = Countries::find()
            ->where(["CountryID" => (int)$params["receivingCountryId"], "Enable" => 1])
            ->one();
        if ($receiveCountry === null) {
            return Helpers::errorResponse(400, "receiving country not found or disabled", []);
        }
        // ---------- Receiving currency validation ----------
        $receiveCurrencyValidation = CountryCurrencies::find()
            ->where(["CountryID" => (int)$params["receivingCountryId"], "CurrencyCode" => $params["receivingCurrency"]])
            ->one();
        if ($receiveCurrencyValidation === null) {
            return Helpers::errorResponse(400, "receiving currency is not related to the receiving country", []);
        }


        // ---------- Partner call ----------

        $exchangeRateArray = $mastercard->getBestExchangeRate(
            $params["sourceCurrency"],
            $receiveCountry->CountryCode,
            $params["receivingCurrency"],
            $deliveryMethod
        );

        if (empty($exchangeRateArray) || !isset($exchangeRateArray["StartRate"])) {
            return Helpers::errorResponse(400, "error in partner connection", []);
        }

        // ---------- Markup & fee ----------
        $exchangeRate = $this->calculateMarkup(
            (float)$exchangeRateArray["StartRate"],
            $params["receivingCurrency"],
            (int)$params["receivingCountryId"],
            $deliveryMethod->system()
        );
        $fee = $this->appliedFee(0, (int)$params["receivingCountryId"], $deliveryMethod->system());
        $vatRate = isset(Yii::$app->params['vatRate']) ? (string)Yii::$app->params['vatRate'] : '0.05';
        $vatAmount  = $this->bc_round(bcmul($fee, $vatRate, (int)$sourceCurrency->DecimalDigits + 6), (int)$sourceCurrency->DecimalDigits);
        $finalFee   = $this->bc_trunc(bcadd($fee, $vatAmount, (int)$sourceCurrency->DecimalDigits + 2), (int)$sourceCurrency->DecimalDigits);

        if ($exchangeRate === -1 || $fee === -1) {
            return Helpers::errorResponse(400, "error in markup and fees", []);
        }

        // ---------- Compute receiving amount ----------
        $formattedRate   = number_format((float)$exchangeRate, 4, '.', '');
        $receivingAmount = number_format(
            ((float)$formattedRate) * $sendingAmount,
            (int)$receiveCurrency->DecimalDigits,
            ".",
            ""
        );

        // Guard against divide-by-zero
        if ((float)$receivingAmount <= 0.0) {
            return Helpers::errorResponse(400, "calculated receiving amount is invalid", []);
        }

        $inverseRate = (float)$sendingAmount / (float)$receivingAmount;

        $source = [
            "currency" => $params["sourceCurrency"],
            "amount"   => number_format($sendingAmount, (int)$sourceCurrency->DecimalDigits, '.', ''),
            "decimals" => (int)$sourceCurrency->DecimalDigits,
        ];

        $receiving = [
            "currency" => $params["receivingCurrency"],
            "amount"   => $receivingAmount,
            "decimals" => (int)$receiveCurrency->DecimalDigits,
        ];

        date_default_timezone_set('Asia/Muscat');

        return [
            "rateProvider"   => "mastercard",
            "corridor"       => $params["sourceCurrency"] . " -> " . $params["receivingCurrency"],
            "asOf"           => date('Y-m-d H:i:s'), // Muscat time
            "rate"           => $formattedRate,
            "inverseRate"    => number_format(round($inverseRate, 8), 8, '.', ''),
            "source"         => $source,
            "receiving"      => $receiving,
            "bank"           => $exchangeRateArray["PayerName"] ?? null,
            "deliveryMethod" => $params['deliveryMethod'],
            "fee"            => number_format((float)$finalFee, (int)$sourceCurrency->DecimalDigits, '.', ''),
        ];
    }

    /**
     * Validate that a numeric-string does not exceed a certain number of decimal places.
     */
    private function hasValidDecimals(string $number, int $maxDecimals): bool
    {
        // Normalize scientific notation & trim
        $normalized = $this->normalizeNumberString($number);
        if (!preg_match('/^-?\d+(\.(\d+))?$/', $normalized)) {
            return false;
        }
        $parts = explode('.', $normalized, 2);
        return count($parts) === 1 || strlen(rtrim($parts[1], '0')) <= $maxDecimals;
    }

    /**
     * Normalize numeric string (e.g., handle scientific notation) to plain decimal.
     */
    private function normalizeNumberString(string $number): string
    {
        if (stripos($number, 'e') !== false) {
            // Convert scientific notation to a non-scientific decimal string
            $float = (float)$number;
            // Use max 18 decimals to avoid float artifacts; trim trailing zeros/dot
            $s = number_format($float, 18, '.', '');
            $s = rtrim($s, '0');
            $s = rtrim($s, '.');
            // Edge case: "-0" -> "0"
            if ($s === '-0') $s = '0';
            return $s;
        }
        return trim($number);
    }


    private function bc_trunc(string $n, int $scale): string
    {
        return bcdiv($n, '1', $scale);
    }

    private function bc_round(string $n, int $scale): string
    {
        if ($scale < 0) {
            $scale = 0;
        }
        // Round-half-up with BCMath
        $sign = (strpos($n, '-') === 0) ? '-' : '';
        $bump = '0.' . str_repeat('0', $scale) . '5';
        $adj  = ($sign === '-') ? '-' . $bump : $bump;
        return bcadd($n, $adj, $scale);
    }
}
