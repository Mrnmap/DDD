<?php

declare(strict_types=1);

namespace common\services;

use DateInterval;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Exception;
use Throwable;
use Yii;
use common\models\Users;
use common\models\Customers;
use common\models\OtpSessions;
use common\models\EkycReports;
use common\classes\Tamimah;
use common\utility\Helpers;
use yii\web\User;

use function Symfony\Component\VarDumper\Dumper\esc;

class AuthService
{
    private const OTP_MAX_ATTEMPTS   = 3;
    private const PIN_MAX_ATTEMPTS   = 4; // it is 5 but reduced one because we are starting from zero

    /**
     * Send OTP to phone (E.164) and create/update OTP session on Users
     */
    public static function sendOtp(array $payload): array
    {
        date_default_timezone_set('Asia/Muscat');
        $phone = self::normalizePhone($payload['phone'] ?? null);

        $termsAccepted  = self::toBool($payload['termsConditionsAccepted'] ?? null);
        $privacyAccepted = self::toBool($payload['privacyPolicyAccepted'] ?? null);

        if ($phone === null) {
            return Helpers::errorResponse(400, 'Phone number is required');
        }
        if (!self::isValidE164($phone)) {
            return Helpers::errorResponse(400, 'Invalid phone number format');
        }

        if (!$termsAccepted || !$privacyAccepted) {
            return Helpers::errorResponse(400, 'User must accept all mandatory agreements');
        }
        $otpCode   = self::generateOtpCode();
        $otpHash   = hash('sha256', $otpCode);
        $createdAt = date('Y-m-d H:i:s');
        $expiresAt = date('Y-m-d H:i:s', strtotime('+5 minutes'));


        $otpSession = OtpSessions::find()
            ->where(['Phone' => $phone])
            ->andWhere(['Status' => OtpSessions::STATUS_PENDING])   // optional but recommended
            ->andWhere(['IS NOT', 'ExpiresAt', null])               // ensure set
            ->andWhere(['>', 'ExpiresAt', new \yii\db\Expression('NOW()')]) // not expired
            ->orderBy(['Id' => SORT_DESC])                          // latest first
            ->one();

        if ($otpSession != null && $otpSession->IsDelivered == 1) {
            // when the otp session is active return the session id and expiry like the response of creating a new one
            return [
                'sessionId' => $otpSession->Id,
                'expiresIn' => $otpSession->ExpiresAt
            ];
        } else if ($otpSession != null && $otpSession->IsDelivered == 0) {
        } else {
            $otpSession = new OtpSessions();
            $otpSession->Phone = $phone;
            $otpSession->CreatedAt = $createdAt;
            $otpSession->ExpiresAt = $expiresAt;
            $otpSession->OtpCodeHash = $otpHash;
            $otpSession->AttemptsRemaining = self::OTP_MAX_ATTEMPTS;
            $otpSession->Status = OtpSessions::STATUS_PENDING;
            $otpSession->IsDelivered = 0;
        }


        if (!$otpSession->save()) {
            return Helpers::errorResponse(400, 'Could not save session', $otpSession->getErrors());
        }

        $result = self::dispatchOtp($phone, $otpCode);
        if (isset($result["success"]) && $result["success"] == true) {
            $otpSession->IsDelivered = 1;
            $otpSession->DeliveredAt = date('Y-m-d H:i:s');
            // save the new otp on other tries
            $otpSession->OtpCodeHash = $otpHash;
            if (!$otpSession->save(false)) {
                return Helpers::errorResponse(400, 'Could not save session');
            }
            return [
                'sessionId' => $otpSession->Id,
                'expiresIn' => $expiresAt,
            ];
        } else {
            $otpSession->UndeliveredCount = ($otpSession->UndeliveredCount ?? 0) + 1;
            $otpSession->LastDeliveryError = json_encode($result);
            // save the new otp on other tries
            $otpSession->LastErrorAt = $otpHash;
            $otpSession->OtpCodeHash = date('Y-m-d H:i:s');
            if (!$otpSession->save(false)) {
                return Helpers::errorResponse(400, 'Could not save session');
            }
            Yii::error(['message' => $result], __METHOD__);
            return Helpers::errorResponse(502, 'Error in SMS', ["sessionId" => $otpSession->Id, "data" => $result]);
        }
    }

    /**
     * Verify OTP using sessionId + phone
     */

    public static function verifyOtp(array $payload): array
    {
        $phone          = self::normalizePhone($payload['phone'] ?? null);
        $otpCode        = isset($payload['otpCode']) ? trim((string) $payload['otpCode']) : '';
        $sessionId        = isset($payload['sessionId']) ? trim((string) $payload['sessionId']) : '';
        $termsAccepted  = self::toBool($payload['termsConditionsAccepted'] ?? null);
        $privacyAccepted = self::toBool($payload['privacyPolicyAccepted'] ?? null);

        // validate parameters
        if ($phone === null) {
            return Helpers::errorResponse(400, 'Phone number is required');
        }

        if (!preg_match('/^\d{6}$/', $otpCode)) {
            return Helpers::errorResponse(400, 'Invalid OTP code format');
        }

        if (!$termsAccepted || !$privacyAccepted) {
            return Helpers::errorResponse(400, 'User must accept all mandatory agreements');
        }


        $now = self::parseDate(date('Y-m-d H:i:s'));

        // get session
        $session = OtpSessions::findOne(["Id" => $sessionId, "Phone" => $phone]);
        if ($session == null) {
            return Helpers::errorResponse(404, 'Session not found');
        }
        $expiresAt = self::parseDate($session->ExpiresAt);
        // check session expiry
        if ($session->isStatusExpired() || $expiresAt <= $now) {
            $session->setStatusToExpired();
            if (!$session->save(false)) {
                return Helpers::errorResponse(500, 'Session could not be saved');
            }
            return Helpers::errorResponse(401, 'Session Expired!');
        }
        // check for if otp is already verfied
        if ($session->isStatusVerified()) {
            return Helpers::errorResponse(401, 'Session already verifired!');
        }

        if ($session->isStatusFailed()) {
            return Helpers::errorResponse(401, 'Session Failed!');
        }
        // chech for over attempts
        if ((int) $session->AttemptsRemaining == 0) {
            $session->setStatusToFailed();
            $session->save(false);
            return Helpers::errorResponse(429, 'OTP verification attempts exceeded');
        }

        $expectedOtp  = (string) $session->OtpCodeHash;
        $otpHash   = hash('sha256', $otpCode);
        if ($expectedOtp === null || $expectedOtp === '' || !hash_equals($expectedOtp, $otpHash)) {
            $attemptsRemaining = (int) $session->AttemptsRemaining - 1;
            // check if this is the last attempt
            if ($attemptsRemaining < 0) {
                $session->setStatusToFailed();
                $session->AttemptsRemaining = 0;
                $session->save(false);
                return Helpers::errorResponse(429, 'OTP verification attempts exceeded');
            } else {
                // save the remaing tries
                $session->AttemptsRemaining  = $attemptsRemaining;
                $session->save(false);
            }

            return Helpers::errorResponse(401, 'Invalid OTP code', [
                'attemptsRemaining' => $attemptsRemaining,
            ]);
        }


        if (hash_equals($expectedOtp, $otpHash)) {
            $user = null;
            $isNew = false;

            $session->setStatusToVerified();
            $session->save(false);
            try {
                [$user, $isNew] = self::findOrCreateUser($phone);
            } catch (Throwable $exception) {
                Yii::error(['message' => $exception->getMessage()], __METHOD__);
                return Helpers::errorResponse(500, 'Could not create customer');
            }

            if ($user === null) {
                return Helpers::errorResponse(404, 'User not found');
            }

            // Check eKYC completion (IsOfficial = 1)
            $ekycReport = EkycReports::find()->where(['UserId' => $user->UserID, 'IsOfficial' => 1])->one();
            $isEkycCompleted = ($ekycReport !== null);
            // Check profile completion
            $isProfileCompleted = self::isProfileCompleted($user->UserID);
            $reportId = "";
            // get report id if the customer has completed ekyc to redirect them to registration form
            if ($isEkycCompleted) {
                // get report id
                $reportId = $ekycReport->ProviderReportId;
            }
            // check customer current status
            $customer = $user->customer;
            $customerStatus = $customer->Status == Customers::STATUS_ACTIVATED ? "Approved" : ($customer->Status == Customers::STATUS_UNDER_REVIEW ? "Pending" : "Denied");
            if ($customer->Status == null || $customer->Status == "") {
                $customerStatus = "Pending";
            }

            // check user lock
            $userPinStatus = ($user->PinStatus == Users::PINSTATUS_ACTIVE || $user->PinStatus == "" || $user->PinStatus == null) ? "Approved" : "Denied";


            if ($isNew) {
                Yii::$app->response->statusCode = 201;
                return [
                    'userId'           => (string) $user->UserID,
                    'phone'            => $phone,
                    'registeredAt'     => $user->OnDate,
                    'isEkycCompleted'  => $isEkycCompleted,
                    'isProfileCompleted' => $isProfileCompleted,
                ];
            } else {
                Yii::$app->response->statusCode = 200;
                // if user is block on PIN return locked response
                if ($userPinStatus == "Denied") {
                    return Helpers::errorResponse(423, 'Your PIN has been blocked due to multiple failed attempts. Please contact customer support on +96892725631 to restore access');
                }
                $hasPin =  $user->MPIN == "" || $user->MPIN == null ? false : true;
                return [
                    'userId'           => (string) $user->UserID,
                    'passwordCreated'  => $hasPin,
                    'isEkycCompleted'  => $isEkycCompleted,
                    'reportId'         => $reportId,
                    'userStatus'         => $customerStatus,
                    'otpVerified'      => true,
                    'message'           => 'OTP verified. User exists.',
                    'isProfileCompleted' => $isProfileCompleted,
                    "pinLockStatus" => $userPinStatus
                ];
            }
        }

        return Helpers::errorResponse(400, 'Invalid OTP code', []);
    }
    // compare otp 
    public static function compareOtpCode(string $expectedOtp, string $submittedOtp): bool
    {
        if ($expectedOtp !== null && $expectedOtp !== '' && hash_equals($expectedOtp, $submittedOtp)) {
            return true;
        }

        return false;
    }


    /*** ===== PIN / CREDENTIALS SECTION ===== ***/

    /**
     * JWT validator stub (ready for future wiring).
     * Return signature kept for compatibility; currently returns null.
     */
    public static function validateJwtToken(?string $authHeader)
    {
        // When you implement JWT:
        // 1) Parse "Bearer <token>"
        // 2) Decode & verify with secret/keys
        // 3) Find user from `sub` claim
        // 4) return ['user_id' => $user->UserID, 'user' => $user];
        return null;
    }
    private static function toBool($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_string($value)) {
            $normalized = strtolower(trim($value));
            return in_array($normalized, ['1', 'true', 'yes'], true);
        }

        if (is_int($value)) {
            return $value === 1;
        }

        return false;
    }
    /**
     * Validate PIN format: exactly 6 numeric digits
     */
    public static function validatePinFormat(?string $pin): ?array
    {
        if ($pin === null || $pin === '' || strlen($pin) !== 6 || !ctype_digit($pin)) {
            return ['message' => 'Pin must be exactly 6 numeric digits.', 'error' => 'Missing or invalid pin.'];
        }
        return null;
    }

    /**
     * Check if PIN is weak (repeating, sequential, easy to guess)
     */
    public static function isWeakPin(string $pin): bool
    {
        // Check for repeating digits (e.g., 000000, 111111)
        if (preg_match('/^(\d)\1{5}$/', $pin)) {
            return true;
        }

        // Check for sequential ascending (e.g., 123456)
        $isSequentialAsc = true;
        for ($i = 0; $i < 5; $i++) {
            if ((int)$pin[$i + 1] !== (int)$pin[$i] + 1) {
                $isSequentialAsc = false;
                break;
            }
        }
        if ($isSequentialAsc) {
            return true;
        }

        // Check for sequential descending (e.g., 654321)
        $isSequentialDesc = true;
        for ($i = 0; $i < 5; $i++) {
            if ((int)$pin[$i + 1] !== (int)$pin[$i] - 1) {
                $isSequentialDesc = false;
                break;
            }
        }
        if ($isSequentialDesc) {
            return true;
        }

        // Check for common patterns
        // Alternating pattern (e.g., 121212, 212121)
        if (preg_match('/^(\d)(\d)(\1\2){2}$/', $pin)) {
            return true;
        }

        // Repeating pairs (e.g., 112233, 223344, 334455)
        if (preg_match('/^(\d)\1(\d)\2(\d)\3$/', $pin)) {
            return true;
        }

        return false;
    }


    /**
     * Check if a user already has an MPIN set
     */
    public static function checkPinExists(int $userId): bool
    {
        $user = Users::findOne($userId);
        if (!$user) {
            return false;
        }

        $mpinValue = $user->MPIN ?? null;
        if ($mpinValue === null || $mpinValue === '' || $mpinValue === 0 || $mpinValue === '0') {
            return false;
        }

        $mpinString = (string)$mpinValue;
        // prefer bcrypt string
        if (str_starts_with($mpinString, '$2')) {
            return true;
        }

        // legacy non-zero numeric value
        return true;
    }

    /**
     * Hash PIN using bcrypt
     */
    public static function hashPin(string $pin, int $cost = 11): string
    {
        $cost = max(10, min(12, $cost));
        return password_hash($pin, PASSWORD_BCRYPT, ['cost' => $cost]);
    }

    /**
     * Create MPIN for a user with validations
     */
    public static function createPin(int $userId, string $pin): array
    {
        if (($e = self::validatePinFormat($pin)) !== null) {
            return ['success' => false, 'status' => 400, 'message' => $e['message'], 'error' => $e['error']];
        }

        // Check for weak PIN patterns
        if (self::isWeakPin($pin)) {
            return ['success' => false, 'status' => 400, 'message' => 'Pin is too weak or not allowed.', 'error' => 'Pin is too weak or not allowed.'];
        }

        if (self::checkPinExists($userId)) {
            return ['success' => false, 'status' => 409, 'message' => 'Pin already set for this user.', 'error' => 'Pin already set for this user.'];
        }

        $user = Users::findOne($userId);
        if (!$user) {
            return ['success' => false, 'status' => 404, 'message' => 'User not found.', 'error' => 'User not found.'];
        }

        $user->MPIN = self::hashPin($pin);

        if (!$user->save(false)) {
            $errors = $user->getErrors();
            $msgs = [];
            foreach ($errors as $attr => $errs) {
                $msgs[] = $attr . ': ' . implode(', ', $errs);
            }
            return [
                'success' => false,
                'status'  => 500,
                'message' => 'Failed to save PIN.',
                'error'   => 'Failed to save PIN. ' . (!empty($msgs) ? implode(' | ', $msgs) : ''),
                'validation_errors' => $errors
            ];
        }

        return [
            'success' => true,
            'status'  => 201,
            'userId'  => (string)$user->UserID,
            'message' => 'Pin created successfully.'
        ];
    }

    /**
     * Verify a PIN against a stored hash
     */
    public static function verifyPin(string $pin, string $hash): bool
    {
        return password_verify($pin, $hash);
    }

    /**
     * Verify a user's MPIN main function
     */
    public static function verifyUserPin(int $userId, string $pin)
    {
        try {
            $user = Users::findOne($userId);

            if (!$user) {
                return [
                    'success' => false,
                    'code' => 404,
                    'message' => 'User not found.',
                    'error' => 'User not found.'
                ];
            }
            if (empty($user->MPIN)) {
                return [
                    'success' => false,
                    'code' => 409,
                    'message' => 'There is no PIN for this user.',
                    'error' => 'PIN not set for this user.'
                ];
            }
            //check if the customer already blocked so ne need to calculate the remaining attempts
            if ($user->isPinStatusBlocked() || $user->isPinStatusTemplocked()) {
                return [
                    'success' => false,
                    'code' => 423,
                    'message' => 'Your PIN has been blocked due to multiple failed attempts. Please contact customer support on +96892725631 to restore access',
                    'error' => ''
                ];
            }

            $storedHash = (string)$user->MPIN;

            // Check if stored hash looks like a bcrypt hash
            if (strpos($storedHash, '$2') !== 0) {
                return [
                    'success' => false,
                    'code' => 500,
                    'message' => 'Invalid PIN format in database.',
                    'error' => 'Invalid PIN format in database.'
                ];
            }

            // Verify the PIN against the stored hash
            $isValid = self::verifyPin($pin, $storedHash);
            // sort out the pin attempt that affect remaining attempts
            $remaining  = self::managePinAttempts($user,  $isValid);
            if ($isValid) {
                return [
                    'success' => true,
                    'message' => 'PIN authentication successful',
                    'pinLockStatus' => $user->isPinStatusActive() ? "Approved" : "Denied"
                ];
            } else {

                if ($remaining["exceeded"] == true) {
                    return [
                        'success' => false,
                        'code' => 429,
                        'message' => 'Your PIN has been blocked due to multiple failed attempts. Please contact customer support on +96892725631 to restore access',
                        'error' => 'PIN verification failed.',
                        'verified' => false
                    ];
                }
                return [
                    'success' => false,
                    'code' => 400,
                    'message' => 'You have ' . $remaining["remainingAttempts"] . ' attempts.',
                    'remainingAttempts' => $remaining["remainingAttempts"],
                    'error' => 'PIN verification failed.',
                    'verified' => false
                ];
            }
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Error verifying PIN.',
                'error' => $e->getMessage()
            ];
        }
    }



    /*** ===== INTERNAL HELPERS ===== ***/
    /**
     * handle pin attempts in the database
     * 
     * @param bool $isPinValid 
     * @param Users $user 
     * @return array 
     */

    private static function managePinAttempts(Users $user, bool $isPinValid)
    {

        if ($isPinValid) {
            // reset on sucessfull attempts
            $user->PinFailedAttempts = 0;
            $user->setPinStatusToActive();
        } else {
            $user->PinFailedAttempts = $user->PinFailedAttempts ?? 0;
            // check if reach max which is 5
            if ($user->PinFailedAttempts >= self::PIN_MAX_ATTEMPTS) {
                $user->setPinStatusToBlocked();
            } else {
                // increase pinFailedAttempts
                $num  = $user->PinFailedAttempts;
                $user->PinFailedAttempts = $num + 1;
            }
        }
        // save user
        $user->save(false);

        // return remaining tries, if the customer is blocked because of too many tries
        return [
            "exceeded" => $user->isPinStatusBlocked(),
            "remainingAttempts" => (self::PIN_MAX_ATTEMPTS - $user->PinFailedAttempts + 1)
        ];
    }

    /**
     * Check if user profile is completed by verifying all required fields are populated
     * 
     * @param int $userId User ID to check
     * @return bool True if all required profile fields are filled
     */
    private static function isProfileCompleted(int $userId): bool
    {
        $user = Users::findOne($userId);
        if ($user === null) {
            return false;
        }

        $customer = Customers::findOne(['UserID' => $userId]);
        if ($customer === null) {
            return false;
        }

        // Check Users.Name (firstName) - required
        if (empty($user->Name)) {
            return false;
        }

        // Check Customers required fields
        if (empty($customer->DOB)) {
            return false;
        }
        if (empty($customer->Nationality)) {
            return false;
        }
        if ($customer->Occupation === null) {
            return false;
        }
        if ($customer->SourceOfFund === null) {
            return false;
        }
        if ($customer->CityID === null) {
            return false;
        }
        if (empty($customer->Address)) {
            return false;
        }
        if ($customer->IDType === null) {
            return false;
        }
        if (empty($customer->IDNo)) {
            return false;
        }
        if (empty($customer->DocExpiry)) {
            return false;
        }

        return true;
    }

    private static function findOrCreateUser(string $phone): array
    {
        $user = Users::find()->joinWith('customer')
            ->where(['Customers.MobileNo' => $phone])
            ->one();
        $db = Yii::$app->db;
        $tx = $db->beginTransaction();
        $isNew = false;
        if ($user !== null) {
            $customer = Customers::findOne(['UserID' => $user->UserID]);
            if ($customer === null) {
                $customer = new Customers();
                $customer->UserID = $user->UserID;
                $customer->MobileNo = $phone;
                $customer->OnDate = date('Y-m-d H:i:s');
                if (!$customer->save(false)) {
                    throw new Exception("Could not create Customer");
                }
            }
        } else {
            $user = new Users();
            $user->OnDate = date('Y-m-d H:i:s');

            if (!$user->save(false)) {
                throw new Exception("Could not create Customer");
            }
            $customer = new Customers();
            $customer->UserID = $user->UserID;
            $customer->MobileNo = $phone;
            $customer->OnDate = date('Y-m-d H:i:s');
            if (!$customer->save(false)) {
                throw new Exception("Could not create Customer");
            }
            $isNew = true;
        }
        $tx->commit();
        return [$user, $isNew];
    }

    private static function success(int $status, array $body): array
    {
        return ['status' => $status, 'body' => $body];
    }

    private static function error(int $status, string $message, array $extra = []): array
    {

        return ['status' => $status, 'body' => array_merge(['message' => $message], $extra)];
    }

    private static function generateOtpCode(): string
    {
        return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }


    private static function dispatchOtp(string $phone, string $otpCode)
    {
        try {
            file_put_contents(__DIR__ . '/../../otp/runtime/logs/otp.txt', json_encode(['date' => date('Y-m-d H:i:s'), 'phone' => $phone, 'otp' => $otpCode]) . PHP_EOL, FILE_APPEND);
        } catch (Exception $e) {
            Yii::error(['otp_error' => $e->getMessage()], __METHOD__);
        }
        $smpp = Yii::$container->get('smpp');
        if ($smpp == null) {
            return [
                'success' => false,
                'message' => "SMS connection Provider error",
            ];
        }
        $result = $smpp->sendSms($phone, "Your verification code is " . $otpCode . ". Do not share this code with anyone.");
        return $result;
    }

    private static function normalizePhone(?string $phone): ?string
    {
        $trimmed = trim((string) $phone);
        return $trimmed === '' ? null : $trimmed;
    }

    private static function isValidE164(string $phone): bool
    {
        return (bool) preg_match('/^\+968[97]\d{7}$/', $phone);
    }


    private static function parseDate(?string $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }

        $date = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $value);
        if ($date !== false) {
            return $date;
        }

        try {
            return new DateTimeImmutable($value);
        } catch (Exception $exception) {
            Yii::warning(['message' => $exception->getMessage()], __METHOD__);
            return null;
        }
    }
}
