<?php

namespace common\services;

use Yii;
use Throwable;
use common\models\Transactions;
use common\models\TransactionDetails;
use common\models\TransactionLogs;
use common\models\TransactionStatus;
use common\models\PartnersTransaction;
use common\models\PaymentGatewayTransaction;
use common\models\BeneficiaryBankAccounts;
use common\classes\DeliveryMethod;
use common\classes\Mastercard;
use common\models\Countries;
use common\models\TransactionCompliance;
use common\models\MarkupRules;
use common\services\BeneficiarySnapshotService;

class TransactionsHandler
{
    /**
     * Creates a transaction with details and an initial log entry.
     *
     * @param array|object $input  // your validated payload (array or object)
     * @return array               // ['ok'=>true,'transactionId'=>..] OR ['ok'=>false,'message'=>..,'errors'=>[..]]
     */
    public static function create(array|object $input): array
    {
        // allow object or array
        // {
        //     "userId": "1",
        //     "beneficiaryId": "116",
        //     "transaction": {
        //       "deliveryMethod": "bank",
        //       "sourceCurrency": "OMR",
        //       "sourceCountryId": "166",
        //       "receivingCurrency": "INR",
        //       "receivingCountryId": "100",
        //       "sendingAmount": "100.000",
        //       "receivingAmount": "260.08",
        //       "transferPurpose": "5",
        //       "sourceOfFunds": "1",
        //       "paymentProfileId": "143",
        //       "rate": "2.60",
        //       "fee": "2.000",
        //       "vat": "0.100",
        //       "finalFee": "2.100",
        //       "finalPrice": "102.100"
        //     }
        //   }
        $data = is_object($input) ? json_decode(json_encode($input), true) : $input;

        $db = Yii::$app->db;
        $tx = $db->beginTransaction();

        try {
            // 1) MAIN: Transactions

            $t = new Transactions();
            $status = TransactionStatus::findOne(["Name" => "New"]);
            date_default_timezone_set('Asia/Muscat');
            $timeStamp = date('Y-m-d H:i:s');
            $t->UserID               = (int)($data['userId'] ?? 0);
            //$t->OrginalTransactionId = (int)($data['originalTransactionId'] ?? null); // required by your rules
            $t->BeneficiaryId        = (int)($data['beneficiaryId'] ?? 0);
            $t->Direction            = $data['direction'] ?? Transactions::DIRECTION_CREDIT; // or 'credit'
            $t->CurrentStatus        = (int)($data['currentStatus'] ?? $status->Id);
            $t->CreatedAt            = $timeStamp;
            $t->SubmittedAt          = null; // set when funds are captured
            $t->UpdatedAt            = $timeStamp;

            if (!$t->save()) {
                return self::fail('Could not save transaction', $t->getErrors());
            }

            // 2) DETAILS: TransactionDetails (hasOne by TransactionID)
            $td = new TransactionDetails();
            // map whatever fields you have in details:
            // examples below — adjust to your schema:
            $details = $data['transaction'];
            $deliverMethod = DeliveryMethod::fromName($details["deliveryMethod"]);
            // Core foreign key
            $td->TransactionID = $t->TransactionID;

            // get transaction calculations
            // partner fee
            // base exchange rate
            // base recieved amount
            // markup percent
            // markup amount
            self::calculatePricing($td, $input);

            // Map according to your TransactionDetails table
            $td->SendingCountryId      = (int)($details['sourceCountryId'] ?? 0);
            $td->SendingCurrencyCode   = $details['sourceCurrency']    ?? null;
            $td->ReceivingCountryId    = (int)($details['receivingCountryId'] ?? 0);
            $td->ReceivingCurrencyCode = $details['receivingCurrency'] ?? null;
            $td->DeliveryMethodId      = $deliverMethod->system();

            $td->SendingAmount         = (float)($details['sendingAmount'] ?? 0);
            $td->ReceivedAmount        = (float)($details['receivingAmount'] ?? 0);
            $td->CustomerExchangeRate  = (float)($details['rate']);
            $td->CustomerFee           = (float)($details['fee'] ?? 0);
            $td->VatAmount             = (float)($details['vat'] ?? 0);
            $td->TotalFees             = (float)($details['finalFee'] ?? 0);
            $td->CollectedAmount       = (float)($details['finalPrice'] ?? 0);


            if (!$td->save()) {
                // if you prefer relation linking (auto-sets FK):
                // $t->link('transactionDetails', $td);
                return self::fail('Could not save transaction details', $td->getErrors());
            }

            // 3) LOG: TransactionLogs (hasMany)
            $log = new TransactionLogs();
            $log->TransactionID = $t->TransactionID;
            $log->TransactionStatus = $t->CurrentStatus;
            $log->InternalSatus = TransactionLogs::INTERNALSATUS_NEW;
            $log->Source = TransactionLogs::SOURCE_USER;
            $log->Comment = $data['logComment'] ?? 'Transaction created';
            $log->ProviderRawJsonRequest = "";
            $log->CreatedAt = $timeStamp;

            if (!$log->save()) {
                return self::fail('Could not save transaction log', $log->getErrors());
            }

            // 4) SNAPSHOT: Create beneficiary snapshot
            $paymentProfileId = isset($details['paymentProfileId']) ? (int)$details['paymentProfileId'] : null;
            $snapshotResult = BeneficiarySnapshotService::createSnapshot(
                $t->TransactionID,
                $t->BeneficiaryId,
                $deliverMethod,
                $paymentProfileId
            );

            if (!$snapshotResult['ok']) {
                return self::fail('Could not create beneficiary snapshot: ' . ($snapshotResult['message'] ?? 'Unknown error'), $snapshotResult['errors'] ?? []);
            }

            $tx->commit();

            return [
                'ok' => true,
                'transactionId' => $t->TransactionID,
            ];
        } catch (Throwable $e) {
            $tx->rollBack();
            return self::fail('Exception while creating transaction: ' . $e->getMessage());
        }
    }
    /**
     * Creates a transaction with details and an initial log entry.
     *
     * @param array|object $input  // your validated payload (array or object)
     * @return array               // ['ok'=>true,'transactionId'=>..] OR ['ok'=>false,'message'=>..,'errors'=>[..]]
     */
    public static function logTransaction($transactionId, array $opts = [])
    {

        /**
         * $opts:
         * - 'statusName'  => string|null         // e.g. "Submitted", "In Progress" (used if statusId not given)
         * - 'internal'    => string              // one of TransactionLogs::INTERNALSATUS_* (required)
         * - 'source'      => string              // one of TransactionLogs::SOURCE_* (default: system)
         * - 'comment'     => string|null         // optional comment
         * - 'requestJson' => string|null         // optional raw request JSON
         * - 'updateTransactionStatus' => bool    // default: true (updates Transactions.CurrentStatus)
         */
        date_default_timezone_set('Asia/Muscat');
        $updateTxnStatus = array_key_exists('updateTransactionStatus', $opts) ? (bool)$opts['updateTransactionStatus'] : true;
        $txn = Transactions::findOne(['TransactionID' => $transactionId]);
        if (!$txn) {
            return self::fail('Transaction not found for logging', ['TransactionID' => $transactionId]);
        }

        $statusId = null;
        if (!empty($opts['statusName'])) {
            $statusModel = TransactionStatus::findOne(['Name' => $opts['statusName']]);
            if (!$statusModel) {
                return self::fail('Invalid statusName; not found in TransactionStatus', ['statusName' => $opts['statusName']]);
            }
            $statusId = (int)$statusModel->Id;
        } else {
            // fallback: keep current status
            $statusId = (int)$txn->CurrentStatus;
        }

        $internal = $opts['internal'] ?? null;
        if (!$internal || !array_key_exists($internal, TransactionLogs::optsInternalSatus())) {
            return self::fail('Invalid or missing internal status', ['internal' => $internal]);
        }

        $source = $opts['source'] ?? TransactionLogs::SOURCE_SYSTEM;
        if (!array_key_exists($source, TransactionLogs::optsSource())) {
            return self::fail('Invalid source', ['source' => $source]);
        }


        $comment   = $opts['comment']     ?? null;
        $reqJson   = $opts['requestJson'] ?? null;
        $createdAt = date('Y-m-d H:i:s');


        $db = Yii::$app->db;
        $tx = $db->beginTransaction();
        try {
            // 4) Insert log row
            $log = new TransactionLogs();
            $log->TransactionID          = $txn->TransactionID;
            $log->TransactionStatus      = $statusId;
            $log->InternalSatus          = $internal;
            $log->Source                 = $source;
            $log->Comment                = $comment;
            $log->ProviderRawJsonRequest = $reqJson;
            $log->CreatedAt              = $createdAt;

            if (!$log->save()) {
                $tx->rollBack();
                return self::fail('Could not save transaction log', $log->getErrors());
            }

            // 5) Optionally update the transaction’s current status + UpdatedAt
            if ($updateTxnStatus) {
                if ($txn->CurrentStatus !== $statusId) {
                    $txn->CurrentStatus = $statusId;
                }

                $txn->UpdatedAt     = $createdAt;
                if (!$txn->save(false, ['CurrentStatus', 'UpdatedAt'])) {
                    $tx->rollBack();
                    return self::fail('Could not update transaction status', $txn->getErrors());
                }
            }

            $tx->commit();
            return ['ok' => true, 'logId' => $log->ID, 'transactionId' => $txn->TransactionID, 'statusId' => $statusId];
        } catch (Throwable $e) {
            $tx->rollBack();
            return self::fail('Exception while saving log: ' . $e->getMessage());
        }
    }
    /**
     * Creates a transaction with details and an initial log entry.
     *
     * @param array|object $input  // your validated payload (array or object)
     * @return array               // ['ok'=>true,'transactionId'=>..] OR ['ok'=>false,'message'=>..,'errors'=>[..]]
     */
    public static function createOrUpdatePartnerTransaction($transactionId, $partnerReference = null, $status = null, $requestJson = null, $responseJson = null): array
    {
        date_default_timezone_set('Asia/Muscat');
        $timeStamp = date('Y-m-d H:i:s');

        // Try to find existing partner transaction
        $t = PartnersTransaction::findOne(['TransactionID' => $transactionId]);

        if ($t === null) {
            // Create new if not exists
            $t = new PartnersTransaction();
            $t->TransactionID = $transactionId;
            $t->PartnerID = "1"; // Mastercard
            $t->CreatedAt = $timeStamp;
        }

        // Update only non-empty values
        if (!empty($partnerReference)) {
            $t->PartnerTransactionReference = $partnerReference;
        }
        if (!empty($status)) {
            $t->Status = $status;
        }
        if (!empty($requestJson)) {
            $t->RawRequestJson = $requestJson;
        }
        if (!empty($responseJson)) {
            $t->RawResponseJson = $responseJson;
        }

        $t->UpdatedAt = $timeStamp;

        if (!$t->save()) {
            return self::fail('Could not save or update partner transaction', $t->getErrors());
        }
        $transactionStatus = "";
        if ($status != null) {
            if ($status == "CANCEL") {
                $transactionStatus = "Failed";
            } else if ($status == "PAID") {
                $transactionStatus = "Delivered";
            } else {
                $transactionStatus = "In Progress";
            }
        }
        return [
            'ok' => true,
            'transactionStatus' => $transactionStatus
        ];
    }
    /**
     * to log initiaed payment
     *
     * @param array|object $input  // your validated payload (array or object)
     * @return array               // ['ok'=>true,'transactionId'=>..] OR ['ok'=>false,'message'=>..,'errors'=>[..]]
     */
    public static function createPayment($transactionId, array $opts = [])
    {
        /**
         * $opts:
         * - 'statusName'  => string|null         // e.g. "Submitted", "In Progress" (used if statusId not given)
         * - 'internal'    => string              // one of TransactionLogs::INTERNALSATUS_* (required)
         * - 'source'      => string              // one of TransactionLogs::SOURCE_* (default: system)
         * - 'comment'     => string|null         // optional comment
         * - 'requestJson' => string|null         // optional raw request JSON
         * - 'updateTransactionStatus' => bool    // default: true (updates Transactions.CurrentStatus)
         */
        date_default_timezone_set('Asia/Muscat');
        $updateTxnStatus = array_key_exists('updateTransactionStatus', $opts) ? (bool)$opts['updateTransactionStatus'] : true;
        $txn = Transactions::findOne(['TransactionID' => $transactionId]);
        if (!$txn) {
            return self::fail('Transaction not found for logging', ['TransactionID' => $transactionId]);
        }

        $statusId = null;
        if (!empty($opts['statusName'])) {
            $statusModel = TransactionStatus::findOne(['Name' => $opts['statusName']]);
            if (!$statusModel) {
                return self::fail('Invalid statusName; not found in TransactionStatus', ['statusName' => $opts['statusName']]);
            }
            $statusId = (int)$statusModel->Id;
        } else {
            // fallback: keep current status
            $statusId = (int)$txn->CurrentStatus;
        }

        $internal = $opts['internal'] ?? null;
        if (!$internal || !array_key_exists($internal, TransactionLogs::optsInternalSatus())) {
            return self::fail('Invalid or missing internal status', ['internal' => $internal]);
        }

        $source = $opts['source'] ?? TransactionLogs::SOURCE_SYSTEM;
        if (!array_key_exists($source, TransactionLogs::optsSource())) {
            return self::fail('Invalid source', ['source' => $source]);
        }


        $comment   = $opts['comment']     ?? null;
        $reqJson   = $opts['requestJson'] ?? null;
        $createdAt = date('Y-m-d H:i:s');


        $db = Yii::$app->db;
        $tx = $db->beginTransaction();
        try {
            // 4) Insert log row
            $log = new TransactionLogs();
            $log->TransactionID          = $txn->TransactionID;
            $log->TransactionStatus      = $statusId;
            $log->InternalSatus          = $internal;
            $log->Source                 = $source;
            $log->Comment                = $comment;
            $log->ProviderRawJsonRequest = $reqJson;
            $log->CreatedAt              = $createdAt;

            if (!$log->save()) {
                $tx->rollBack();
                return self::fail('Could not save transaction log', $log->getErrors());
            }

            // 5) Optionally update the transaction’s current status + UpdatedAt
            if ($updateTxnStatus) {
                if ($txn->CurrentStatus !== $statusId) {
                    $txn->CurrentStatus = $statusId;
                }

                $txn->UpdatedAt     = $createdAt;
                if (!$txn->save(false, ['CurrentStatus', 'UpdatedAt'])) {
                    $tx->rollBack();
                    return self::fail('Could not update transaction status', $txn->getErrors());
                }
            }

            $tx->commit();
            return ['ok' => true, 'logId' => $log->ID, 'transactionId' => $txn->TransactionID, 'statusId' => $statusId];
        } catch (Throwable $e) {
            $tx->rollBack();
            return self::fail('Exception while saving log: ' . $e->getMessage());
        }
    }
    /**
     * Creates a transaction with details and an initial log entry.
     *
     * @param array|object $input  // your validated payload (array or object)
     * @return array               // ['ok'=>true,'transactionId'=>..] OR ['ok'=>false,'message'=>..,'errors'=>[..]]
     */
    public static function logPayment($transactionId, array $opts = [])
    {
        /**
         * $opts:
         * - 'statusName'  => string|null         // e.g. "Submitted", "In Progress" (used if statusId not given)
         * - 'internal'    => string              // one of TransactionLogs::INTERNALSATUS_* (required)
         * - 'source'      => string              // one of TransactionLogs::SOURCE_* (default: system)
         * - 'comment'     => string|null         // optional comment
         * - 'requestJson' => string|array|null   // optional raw request JSON (array will be json_encoded)
         * - 'updateTransactionStatus' => bool    // default: true (updates Transactions.CurrentStatus)
         *
         * - 'gateway' => [                       // OPTIONAL: if provided, will save/update PaymentGatewayTransaction
         *       'reference'   => string,         // PaymentGatewayTransaction.GatewayReference   (required for gateway save)
         *       'status'      => string,         // PaymentGatewayTransaction.GatewayStatus      (required)
         *       'amount'      => float|null,     // PaymentGatewayTransaction.Amount             (defaults to txn amount if null)
         *       'message'     => string|null,    // PaymentGatewayTransaction.GatewayMessage     (default: '')
         *       'raw'         => string|array,   // PaymentGatewayTransaction.RawResponseJson    (required)
         *       // advanced (optional):
         *       'checksum'    => string|null,    // if not provided, computed from 'raw' (SHA256)
         *       'upsert'      => bool            // default: true (update existing by TransactionId+reference)
         *   ]
         */
        date_default_timezone_set('Asia/Muscat');

        $updateTxnStatus = array_key_exists('updateTransactionStatus', $opts) ? (bool)$opts['updateTransactionStatus'] : true;

        $txn = Transactions::findOne(['TransactionID' => $transactionId]);
        if (!$txn) {
            return self::fail('Transaction not found for logging', ['TransactionID' => $transactionId]);
        }

        $statusId = null;
        if (!empty($opts['statusName'])) {
            $statusModel = TransactionStatus::findOne(['Name' => $opts['statusName']]);
            if (!$statusModel) {
                return self::fail('Invalid statusName; not found in TransactionStatus', ['statusName' => $opts['statusName']]);
            }
            $statusId = (int)$statusModel->Id;
        } else {
            $statusId = (int)$txn->CurrentStatus; // fallback
        }

        $internal = $opts['internal'] ?? null;
        if (!$internal || !array_key_exists($internal, TransactionLogs::optsInternalSatus())) {
            return self::fail('Invalid or missing internal status', ['internal' => $internal]);
        }

        $source = $opts['source'] ?? TransactionLogs::SOURCE_SYSTEM;
        if (!array_key_exists($source, TransactionLogs::optsSource())) {
            return self::fail('Invalid source', ['source' => $source]);
        }

        // Normalize requestJson to string for storage
        $reqJson = $opts['requestJson'] ?? null;

        $comment   = $opts['comment'] ?? null;
        $createdAt = date('Y-m-d H:i:s');

        $db = Yii::$app->db;
        $tx = $db->beginTransaction();
        try {
            // 1) Insert transaction log
            $log = new TransactionLogs();
            $log->TransactionID          = $txn->TransactionID;
            $log->TransactionStatus      = $statusId;
            $log->InternalSatus          = $internal;
            $log->Source                 = $source;
            $log->Comment                = $comment;
            $log->ProviderRawJsonRequest = $reqJson;
            $log->CreatedAt              = $createdAt;

            if (!$log->save()) {
                $tx->rollBack();
                return self::fail('Could not save transaction log', $log->getErrors());
            }

            // 2) Optionally update the transaction’s current status + UpdatedAt
            if ($updateTxnStatus) {
                if ((int)$txn->CurrentStatus !== (int)$statusId) {
                    $txn->CurrentStatus = $statusId;
                    if ($txn->SubmittedAt == null && $opts['statusName'] == "In Progress") {
                        $txn->SubmittedAt = $createdAt;
                    }
                }
                $txn->UpdatedAt = $createdAt;

                if (!$txn->save(false, ['CurrentStatus', 'UpdatedAt', 'SubmittedAt'])) {
                    $tx->rollBack();
                    return self::fail('Could not update transaction status', $txn->getErrors());
                }
            }



            // 3) Optionally save PaymentGatewayTransaction
            $gatewayId = null;
            if (!empty($opts['gateway']) && is_array($opts['gateway'])) {
                $g = $opts['gateway'];

                // Validate minimal required inputs for gateway save
                $reference = $g['reference'] ?? null;
                $gStatus   = $g['status'] ?? null;
                $raw       = $g['raw'] ?? null;

                if (!$reference || !$gStatus || $raw === null) {
                    $tx->rollBack();
                    return self::fail('Missing required gateway fields (reference, status, raw)', [
                        'reference' => (bool)$reference,
                        'status'    => (bool)$gStatus,
                        'raw'       => $raw !== null
                    ]);
                }

                // Compute checksum if not provided
                //$checksum = $g['checksum'] ?? hash('sha256', $raw);

                // Amount default: use provided amount, else try txn Amount (if you have a different field name, adjust here)
                $amount = isset($g['amount']) ? (float)$g['amount'] : (float)($txn->transactionDetails->CollectedAmount ?? 0);

                $message = $g['message'] ?? '';

                $doUpsert = array_key_exists('upsert', $g) ? (bool)$g['upsert'] : true;

                $pgModel = null;
                if ($doUpsert) {
                    $pgModel = PaymentGatewayTransaction::find()
                        ->where(['TransactionId' => $txn->TransactionID, 'GatewayReference' => $reference])
                        ->one();
                }
                if (!$pgModel) {
                    $pgModel = new PaymentGatewayTransaction();
                    $pgModel->CreatedAt = $createdAt;
                }

                $pgModel->TransactionId   = $txn->TransactionID;
                $pgModel->GatewayReference = $reference;
                $pgModel->GatewayStatus    = $gStatus;
                $pgModel->Amount           = $amount;
                $pgModel->GatewayMessage   = $message;
                $pgModel->RawResponseJson  = $raw;
                $pgModel->PayloadChecksum  = null;
                $pgModel->UpdatedAt        = $createdAt;

                if (!$pgModel->save()) {
                    $tx->rollBack();
                    return self::fail('Could not save PaymentGatewayTransaction', $pgModel->getErrors());
                }

                $gatewayId = (int)$pgModel->Id;
            }

            $tx->commit();
            return [
                'ok'             => true,
                'logId'          => (int)$log->ID,
                'transactionId'  => $txn->TransactionID,
                'statusId'       => (int)$statusId,
                'gatewayId'      => $gatewayId,
            ];
        } catch (\Throwable $e) {
            $tx->rollBack();
            return self::fail('Exception while saving log/payment gateway: ' . $e->getMessage());
        }
    }

    public static function saveCancelTransaction($transactionId, $result)
    {
        if ($result == null) {
            return self::fail('Could not cancel the transaction in mastercard', []);
        } else if (isset($result["sucess"]) && $result["sucess"] == true) {

            try {
                $data = $result["data"];
                $saveTrnResult = TransactionsHandler::createOrUpdatePartnerTransaction($transactionId, $data["TfPin"], $data["StatusName"], null, $data);
                if (isset($saveTrnResult["ok"]) && $saveTrnResult["ok"] == true) {
                    $opts = [
                        "statusName" => "Failed",
                        "internal" => TransactionLogs::INTERNALSATUS_CANCEL_IN_MASTERCARD,
                        "source" => TransactionLogs::SOURCE_SYSTEM,
                        "comment" => "transaction was cancelled in mastercard",
                        "updateTransactionStatus" => true,
                    ];
                    TransactionsHandler::logTransaction($transactionId, $opts);
                } else {
                    return self::fail('Could save the cancellation', []);
                }
            } catch (Throwable $e) {
                return self::fail('Could save the cancellation: ' . $e->getMessage(), []);
            }
        } else if (isset($result["sucess"]) && $result["sucess"] == false) {
            return self::fail('Could not cancel the transaction in mastercard', []);
        } else {
            return self::fail('Could not cancel the transaction in mastercard', []);
        }
        return ['ok' => true];
    }
    /**
     * 
     */
    public static function createOrUpdateTransactionCompliance($transactionId, array $opts = []): array
    {

        // $opts will be:
        // {
        //   "reason":"",
        // }
        date_default_timezone_set('Asia/Muscat');
        $timeStamp = date('Y-m-d H:i:s');

        // find transaction
        $txn = Transactions::findOne(['TransactionID' => $transactionId]);
        $txnComplinace = TransactionCompliance::findOne(['TransactionId' => $transactionId]);

        $beneficiary = $txn->beneficiary;

        $status = null;
        $flagType = TransactionCompliance::FLAGTYPE_MANUAL_REVIEW;
        $reason = $opts["reason"] ?? null;

        if ($beneficiary->isStatusActivated()) {
            $status = TransactionCompliance::STATUS_CLEARED;
        } else if ($beneficiary->isStatusBlocked()) {
            $status = TransactionCompliance::STATUS_BLOCKED;
        } else if ($beneficiary->isStatusUnderReview()) {
            $status = TransactionCompliance::STATUS_UNDER_REVIEW;
        }
        if ($txnComplinace === null) {
            // Create new if not exists

            $txnComplinace = new TransactionCompliance();
            $txnComplinace->TransactionId = $transactionId;
            $txnComplinace->FlagType = $flagType;
            $txnComplinace->Status = $status;
            $txnComplinace->ReasonText = $reason;
            $txnComplinace->CreatedAt = $timeStamp;
            $txnComplinace->ClearedAt = $status == TransactionCompliance::STATUS_CLEARED ? $timeStamp : null;
            $txnComplinace->ClearedBy = null;
        }

        //Update only non-empty values
        if ($status != $txnComplinace->Status) {
            $txnComplinace->Status = $status;
            $txnComplinace->ClearedAt = $status == TransactionCompliance::STATUS_CLEARED ? $timeStamp : null;
        }
        if ($reason != $txnComplinace->ReasonText) {
            $txnComplinace->ReasonText = $reason;
        }
        if ($flagType != $txnComplinace->FlagType) {
            $txnComplinace->FlagType = $flagType;
        }

        // $t->UpdatedAt = $timeStamp;
        // TODO: update transaction : REVIEWTHIS
        if (!$txnComplinace->save()) {
            return self::fail('Could not save or update transaction complinace', $txnComplinace->getErrors());
        }
        return [
            'ok' => true
        ];
    }

    private static function calculatePricing(&$trnDetails, array $opts = [])
    {
        // {
        //     "userId": "1",
        //     "beneficiaryId": "116",
        //     "transaction": {
        //       "deliveryMethod": "bank",
        //       "sourceCurrency": "OMR",
        //       "sourceCountryId": "166",
        //       "receivingCurrency": "INR",
        //       "receivingCountryId": "100",
        //       "sendingAmount": "100.000",
        //       "receivingAmount": "260.08",
        //       "transferPurpose": "5",
        //       "sourceOfFunds": "1",
        //       "paymentProfileId": "143",
        //       "rate": "2.60",
        //       "fee": "2.000",
        //       "vat": "0.100",
        //       "finalFee": "2.100",
        //       "finalPrice": "102.100"
        //     }
        //   }


        // partner fee
        // base exchange rate
        // base recieved amount
        // markup percent
        // markup amount
        $details = $opts['transaction'];
        $bankAccount = BeneficiaryBankAccounts::findOne([
            "UserId" => (int)$opts["userId"],
            "BeneficiaryId" => (int)$opts["beneficiaryId"],
            "BeneficiaryBankAccountId" => (int)$details["paymentProfileId"],
            "CountryId" => (int)$details["receivingCountryId"],
        ]);
        $payerId = $bankAccount->branch->MCBankID ?? '';
        $mc = new Mastercard();
        $deliverMethod = DeliveryMethod::fromName($details["deliveryMethod"]);
        $receivingCountry = Countries::findOne(["CountryID" => $details["receivingCountryId"]]);
        $sourceCountry = Countries::findOne(["CountryID" => $details["sourceCountryId"]]);
        $array = $mc->getCalculation($deliverMethod, $details['receivingCurrency'], $receivingCountry->CountryCode, "OMR", $details['sendingAmount'], $payerId);
        if (isset($array["ServiceFee"])) {
            $trnDetails->PartnerFee = (float)($array["ServiceFee"] ?? 0);
        }
        if (isset($array["SettlementRate"])) {
            $trnDetails->BaseExchangeRate = (float)($array["SettlementRate"] ?? 0);
        }
        if (isset($array["ReceiveAmount"])) {
            $trnDetails->BaseReceivedAmount = (float)($array["ReceiveAmount"] ?? 0);
        }
        $rule = MarkupRules::find()->joinWith(["country"])
            ->where(["CurrencyCode" => $details['receivingCurrency'], "DeliveryMethodId" => $deliverMethod->system(), "Countries.CountryID" => $receivingCountry->CountryID])->one();

        if ($rule != null) {
            $trnDetails->FxMarkupPercent  = (float)$rule->MarkupValuePercent;
            $markupAmount = (float)($details['sendingAmount'] * ($trnDetails->FxMarkupPercent / 100));
            $trnDetails->FxMarkupAmount = $markupAmount;
        }
    }
    private static function fail(string $message, array $errors = []): array
    {
        return ['ok' => false, 'message' => $message, 'errors' => $errors];
    }
}
