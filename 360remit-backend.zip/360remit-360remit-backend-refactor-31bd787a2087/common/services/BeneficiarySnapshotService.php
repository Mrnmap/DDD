<?php

namespace common\services;

use Yii;
use common\models\Beneficiaries;
use common\models\BeneficiaryBankAccounts;
use common\models\TransactionBeneficiarySnapshot;
use common\classes\DeliveryMethod;

/**
 * Service for creating beneficiary snapshots at transaction time
 */
class BeneficiarySnapshotService
{
    /**
     * Creates a snapshot of beneficiary information at the time of transaction
     *
     * @param int $transactionId The transaction ID
     * @param int $beneficiaryId The beneficiary ID
     * @param DeliveryMethod $deliveryMethod The delivery method enum
     * @param int|null $paymentProfileId Optional payment profile ID for delivery method details
     * @return array ['ok' => bool, 'message' => string|null, 'errors' => array]
     */
    public static function createSnapshot(int $transactionId, int $beneficiaryId, DeliveryMethod $deliveryMethod, ?int $paymentProfileId = null): array
    {
        try {
            date_default_timezone_set('Asia/Muscat');
            $timestamp = date('Y-m-d H:i:s');

            // Get base beneficiary data
            $beneficiaryData = self::getBeneficiaryData($beneficiaryId);
            if (!$beneficiaryData['ok']) {
                return $beneficiaryData;
            }

            // Create snapshot model
            $snapshot = new TransactionBeneficiarySnapshot();
            $snapshot->transaction_id = $transactionId;
            $snapshot->beneficiary_id = $beneficiaryId;
            $snapshot->first_name_at_time = $beneficiaryData['data']['firstName'];
            $snapshot->last_name_at_time = $beneficiaryData['data']['lastName'];
            $snapshot->phone_at_time = $beneficiaryData['data']['phone'];
            $snapshot->address_at_time = $beneficiaryData['data']['address'];
            $snapshot->snapshot_created_at = $timestamp;

            // Populate delivery method specific fields
            switch ($deliveryMethod) {
                case DeliveryMethod::BankDeposit:
                    $bankData = self::getBankAccountData($beneficiaryId, $paymentProfileId);
                    if ($bankData['ok']) {
                        $snapshot->bank_account_number = $bankData['data']['accountNumber'];
                        $snapshot->bank_name = $bankData['data']['bankName'];
                        $snapshot->bank_branch_code = $bankData['data']['branchCode'];
                    }
                    break;

                case DeliveryMethod::MobileWallet:
                    $walletData = self::getWalletData($beneficiaryId, $paymentProfileId);
                    if ($walletData['ok']) {
                        $snapshot->mobile_wallet_number = $walletData['data']['walletNumber'];
                    }
                    break;

                case DeliveryMethod::CashPickup:
                    $pickupData = self::getPickupData($beneficiaryId, $paymentProfileId);
                    if ($pickupData['ok']) {
                        $snapshot->pickup_location = $pickupData['data']['location'];
                        $snapshot->pickup_reference = $pickupData['data']['reference'];
                    }
                    break;
            }

            // Save snapshot
            if (!$snapshot->save()) {
                return self::fail('Could not save beneficiary snapshot', $snapshot->getErrors());
            }

            return [
                'ok' => true,
                'snapshotId' => $snapshot->id,
            ];
        } catch (\Throwable $e) {
            return self::fail('Exception while creating beneficiary snapshot: ' . $e->getMessage());
        }
    }

    /**
     * Fetches base beneficiary information
     *
     * @param int $beneficiaryId
     * @return array
     */
    private static function getBeneficiaryData(int $beneficiaryId): array
    {
        $beneficiary = Beneficiaries::findOne(['BeneficiaryID' => $beneficiaryId, 'IsDelete' => 0]);
        
        if (!$beneficiary) {
            return self::fail('Beneficiary not found', ['beneficiaryId' => $beneficiaryId]);
        }

        // Construct full address from available fields
        $addressParts = array_filter([
            $beneficiary->House,
            $beneficiary->Street,
            $beneficiary->City,
            $beneficiary->State,
        ]);
        $address = implode(', ', $addressParts);

        return [
            'ok' => true,
            'data' => [
                'firstName' => $beneficiary->FirstName,
                'lastName' => $beneficiary->LastName,
                'phone' => $beneficiary->Phone,
                'address' => $address ?: null,
            ],
        ];
    }

    /**
     * Fetches bank account specific details
     *
     * @param int $beneficiaryId
     * @param int|null $paymentProfileId
     * @return array
     */
    private static function getBankAccountData(int $beneficiaryId, ?int $paymentProfileId): array
    {
        if (!$paymentProfileId) {
            return self::fail('Payment profile ID is required for bank account data');
        }

        $bankAccount = BeneficiaryBankAccounts::findOne([
            'BeneficiaryBankAccountId' => $paymentProfileId,
            'BeneficiaryId' => $beneficiaryId,
            'IsDelete' => 0,
            'Enable' => 1,
        ]);

        if (!$bankAccount) {
            return self::fail('Bank account not found', [
                'paymentProfileId' => $paymentProfileId,
                'beneficiaryId' => $beneficiaryId,
            ]);
        }

        // Get related bank and branch information
        $bankName = $bankAccount->bank ? $bankAccount->bank->Name : null;
        $branchCode = null;
        
        if ($bankAccount->branch) {
            // Use the ID field as requested by user
            $branchCode = $bankAccount->branch->ID;
        }

        return [
            'ok' => true,
            'data' => [
                'accountNumber' => $bankAccount->AccountNumber,
                'bankName' => $bankName,
                'branchCode' => $branchCode,
            ],
        ];
    }

    /**
     * Fetches mobile wallet information
     *
     * @param int $beneficiaryId
     * @param int|null $paymentProfileId
     * @return array
     */
    private static function getWalletData(int $beneficiaryId, ?int $paymentProfileId): array
    {
        // TODO: Implement wallet data retrieval based on your wallet table structure
        // For now, returning a basic structure
        if (!$paymentProfileId) {
            return self::fail('Payment profile ID is required for wallet data');
        }

        // Placeholder: Adjust this based on your actual wallet model/table
        return [
            'ok' => true,
            'data' => [
                'walletNumber' => null, // Implement based on your wallet model
            ],
        ];
    }

    /**
     * Fetches cash pickup information
     *
     * @param int $beneficiaryId
     * @param int|null $paymentProfileId
     * @return array
     */
    private static function getPickupData(int $beneficiaryId, ?int $paymentProfileId): array
    {
        // TODO: Implement pickup data retrieval based on your pickup location table structure
        // For now, returning a basic structure
        if (!$paymentProfileId) {
            return self::fail('Payment profile ID is required for pickup data');
        }

        // Placeholder: Adjust this based on your actual pickup model/table
        return [
            'ok' => true,
            'data' => [
                'location' => null, // Implement based on your pickup model
                'reference' => null,
            ],
        ];
    }

    /**
     * Helper method to return failure response
     *
     * @param string $message
     * @param array $errors
     * @return array
     */
    private static function fail(string $message, array $errors = []): array
    {
        return ['ok' => false, 'message' => $message, 'errors' => $errors];
    }
}


