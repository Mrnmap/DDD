<?php

namespace common\services;

use common\models\CustomerCards;
use common\models\PaymentProviders;
use common\utility\Helpers;
use Symfony\Component\CssSelector\Parser\Handler\WhitespaceHandler;
use Yii;
use yii\db\Query;
use yii\helpers\ArrayHelper;
use DateTime;
use DateTimeZone;

class CardsService
{
    public function getCards($params) {}
    public function getSaveCardLink($userId)
    {
        $omannet = new PaymentProviderProcessor("1");

        $link =  $omannet->getSaveCardLink($userId . "u" . time());
        if (empty(trim($link))) {
            return Helpers::errorResponse(400, "Error in payment gateway", []);
        }
        return $link;
    }
    public function saveCard($userId, $cardToken, $cardType)
    {
        if (!empty(trim($cardToken))) {
            $last4 = substr($cardToken, -4);

            $newCard = new CustomerCards();
            $newCard->CardToken = $cardToken;
            $newCard->CardType = $cardType;
            $newCard->UserID = $userId;
            $newCard->Last4 = $last4;
            // find if this cardtoken is already registered with the same user
            $hasOne = CustomerCards::find()->where(["UserID" => $userId])->one();
            if ($hasOne == null) {
                $newCard->IsDefault = 1;
            }

            if (!$newCard->save()) {
                return Helpers::errorResponse(400, "", $newCard->getErrors());
            }
        } else {
            return Helpers::errorResponse(400, "empty card token!", []);
        }
        return "";
    }

    public function deleteCard($userId, $cardToken)
    {
        $omannet = new PaymentProviderProcessor("1");

        $link =  $omannet->getSaveCardLink($userId . "u" . time());
        if (empty(trim($link))) {
            return Helpers::errorResponse(400, "Error in payment gateway", []);
        }
        return $link;
    }
}
