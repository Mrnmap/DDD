<?php

namespace common\services;

use Yii;
use yii\db\Query;
use yii\helpers\ArrayHelper;
use api\models\CountriesSearch;
use api\models\BanksSearch;
use api\models\BanksBranchesSearch;
use api\models\SourceOfFundSearch;
use common\models\Countries;
use common\models\Cities;
use common\models\States;
use common\models\Relations;
use common\models\Occupation;
use common\models\TransferPurposes;
use common\utility\Helpers;
use common\models\Banks;
use common\models\BanksBranches;

class ListingsService
{

    public function getCountries($params)
    {
        $sort = $params['sort'] ?? null;
        $page = intval($params['page']);
        $page = $page > 0 ? $page - 1 : 0;
        $limit = intval($params['limit']);

        if ($limit <= 0) {
            $limit = false;
        }
        $params = [
            "pageSize" => $limit,
        ];

        $searchModel = new CountriesSearch();
        $search = $searchModel->search($params);

        $search->pagination->page = $page;
        $countries = $search->getModels();

        $countriesList = [];
        foreach ($countries as $country) {
            $currencies = [];
            foreach ($country->countryCurrencies as $currency) {
                $currencies[] = $currency->CurrencyCode;
            }

            $flagName = strtolower($country->CountryName);
            $flagName = str_replace(' ', '-', $flagName);
            $imagePath = Yii::getAlias('@flagsDirectory') . "/" . $flagName . '.png';
            $imageBase64 = Helpers::imageToBase64($imagePath);
            $patterns = json_decode(
                file_get_contents(Yii::getAlias('@common/utility/BankAccountPatterns.json')),
                true
            );
            // masks
            $availabeMask = "";
            if ($patterns[$country->CountryCode]["localAccount"] != null && $patterns[$country->CountryCode]["iban"] != null) {
                $availabeMask = "mixed";
            } else if ($patterns[$country->CountryCode]["localAccount"] != null && $patterns[$country->CountryCode]["iban"] == null) {
                $availabeMask = "account";
            } else if ($patterns[$country->CountryCode]["localAccount"] == null && $patterns[$country->CountryCode]["iban"] != null) {
                $availabeMask = "iban";
            } else {
                $availabeMask = null;
            }
            $item = [
                'countryId' => $country->CountryID,
                'countryName' => $country->CountryName,
                'currencies' => $currencies,
                'shortName' => $country->CountryCode,
                'phoneCode' => $country->PhoneCode,
                "accountType" => $availabeMask,
                'masks' => [
                    'accountMask' => $patterns[$country->CountryCode]["localAccount"],
                    'ibanMask' => $patterns[$country->CountryCode]["iban"]
                ],
                'flag' => $imageBase64
            ];
            $countriesList[] = $item;
        }
        $pagination = $search->getPagination();


        return [
            "countries" => $countriesList,
            "totalElements" => $search->getTotalCount(),
            "totalPages" => $pagination->getPageCount(),
            "currentPage" => ($pagination->getPage() + 1)
        ];
    }
    public function getOccupations()
    {
        $list = Occupation::find()->select(["OccupationID AS occupationId", "Name AS name"])->asArray()->all();
        return $list;
    }

    public function getDeliveryMethods($countryId)
    {
        return [
            [
                'id' => 1,
                'name' => 'getDeliveryMethods',
            ],
            [
                'id' => 2,
                'name' => 'Bank Manager',
            ],
            [
                'id' => 3,
                'name' => 'Civil Engineer',
            ],
            [
                'id' => 4,
                'name' => 'Doctor',
            ],
            [
                'id' => 5,
                'name' => 'Software Developer',
            ],
        ];
    }

    public function getTransferPurposes()
    {
        $list = TransferPurposes::find()->select(["PurposeID AS purposeId", "Name AS name"])->asArray()->all();
        return $list;
    }


    public function getSourceOfFund($params)
    {
        $searchModel = new SourceOfFundSearch();
        $result = $searchModel->search($params);

        if (is_array($result) && isset($result['error']) && $result['error']) {
            return [
                'errorId' => uniqid(),
                'timestamp' => date('c'),
                'status' => $result['status'],
                'errors' => $result['errors'],
                'type' => 'Bad request',
                'path' => 'uri=/api/listings/funding-sources',
                'message' => $result['errors'][0] ?? 'Invalid request parameters'
            ];
        }

        $models = $result->getModels();
        $pagination = $result->getPagination();

        $sourcesOfFunds = [];
        foreach ($models as $model) {
            $sourcesOfFunds[] = [
                'id' => (string)$model['SourceID'],
                'name' => $model['Description']
            ];
        }

        return [
            'sourcesOfFunds' => $sourcesOfFunds,
            'totalElements' => $result->getTotalCount(),
            'totalPages' => $pagination->getPageCount(),
            'currentPage' => $params['page'] ?? 1
        ];
    }
    public function getIdTypes()
    {
        return [
            [
                'id' => 1,
                'name' => 'getIdTypes',
            ]
        ];
    }
    public function getBanks($params)
    {
        $page = isset($params['page']) ?  intval($params['page']) : null;
        if ($page > 0) {
            $page = $page > 0 ? $page - 1 : 0;
        }

        // make default as all list
        $limit = isset($params['limit']) ? intval($params['limit']) : null;

        $countryId = isset($params['countryId']) ? intval($params['countryId']) : 0;


        if ($countryId == 0) {
            return Helpers::errorResponse(404, "Country not found", []);
        }

        $params = [
            "page" => $page,
            "pageSize" => $limit,
            "countryId" => $countryId

        ];
        $searchModel = new \api\models\BanksSearch();
        $dataProvider = $searchModel->search($params);
        return [
            'banks' => $dataProvider->getModels(),
            'totalElements”' => $dataProvider->getTotalCount(),
            //'pageSize' => $dataProvider->getPagination()->pageSize,
            'totalPages' => $dataProvider->getPagination()->getPageCount(),
            'currentPage”' => $params['page'] ?? 1,
        ];
    }

    public function getBankBranches($params)
    {
        $searchModel = new \api\models\BanksBranchesSearch();

        $page = isset($params['page']) ?  intval($params['page']) : null;
        if ($page > 0) {
            $page = $page > 0 ? $page - 1 : 0;
        }

        // make default as all list
        $limit = isset($params['limit']) ? intval($params['limit']) : null;

        $bankId = isset($params['bankId']) ? intval($params['bankId']) : 0;

        if ($bankId == 0) {
            return Helpers::errorResponse(404, "Bank not found", []);
        }

        $params = [
            "page" => $page,
            "pageSize" => $limit,
            "bankId" => $bankId,

        ];

        $dataProvider = $searchModel->search($params);

        return [
            'bankBranches' => $dataProvider->getModels(),
            'totalElements”' => $dataProvider->getTotalCount(),
            //'pageSize' => $dataProvider->getPagination()->pageSize,
            'totalPages' => $dataProvider->getPagination()->getPageCount(),
            'currentPage' => $dataProvider->getPagination()->getPage() + 1,
        ];
    }

    /**
     * Get banks with pagination for /api/user/bank/list endpoint
     */
    // public function getBanksWithPagination($countryId, $page, $limit)
    // {
    //     try {
    //         // Calculate offset
    //         $offset = ($page - 1) * $limit;

    //         // Get total count
    //         $totalElements = Banks::find()
    //             ->innerJoin('Countries', 'Banks.CountryID = Countries.CountryID')
    //             ->where([
    //                 'Countries.CountryID' => $countryId,
    //                 'Countries.Enable' => 1,
    //                 'Banks.Enable' => 1,
    //                 'Banks.IsDelete' => 0
    //             ])
    //             ->count();

    //         // Get banks with pagination
    //         $banks = Banks::find()
    //             ->select(['BankID AS bankId', 'Name AS bankName'])
    //             ->innerJoin('Countries', 'Banks.CountryID = Countries.CountryID')
    //             ->where([
    //                 'Countries.CountryID' => $countryId,
    //                 'Countries.Enable' => 1,
    //                 'Banks.Enable' => 1,
    //                 'Banks.IsDelete' => 0
    //             ])
    //             ->offset($offset)
    //             ->limit($limit)
    //             ->asArray()
    //             ->all();

    //         // Calculate pagination info
    //         $totalPages = ceil($totalElements / $limit);

    //         return [
    //             'banks' => $banks,
    //             'totalElements' => $totalElements,
    //             'totalPages' => $totalPages,
    //             'currentPage' => $page
    //         ];
    //     } catch (\Exception $e) {
    //         return [
    //             'error' => true,
    //             'status' => 500,
    //             'message' => 'Internal server error'
    //         ];
    //     }
    // }


    public function getStates($countryId)
    {
        $list = States::find()->select(["StateID AS stateId", "StateName AS stateName"])->joinWith('country', false)->where(["States.CountryID" => $countryId, "Countries.Enable" => 1])->asArray()->all();
        return $list;
    }
    public function getCities($countryId, $stateId)
    {
        // Check if the country is Oman, automatically set state to OMA if it is Oman
        $country = Countries::find()
            ->where(['CountryID' => $countryId])
            ->one();

        $isOman = false;
        if ($country && (strtolower($country->CountryName) === 'oman' || strtoupper($country->CountryCode) === 'OM')) {
            $isOman = true;
            $omaState = States::find()
                ->where(['CountryID' => $countryId, 'IsDelete' => 0])
                ->andWhere(['or', ['StateName' => 'OMA'], ['MCStatID' => 'OMA']])
                ->one();

            if ($omaState) {
                $stateId = $omaState->StateID;
            }
        }

        $query = Cities::find()
            ->select(["CityID AS cityId", "CityName AS cityName"])
            ->joinWith('country', false)
            ->where(["StateID" => $stateId, "Cities.CountryID" => $countryId]);

        if (!$isOman) {
            $query->andWhere(["Countries.Enable" => 1]);
        }

        $list = $query->asArray()->all();
        return $list;
    }


    public function getRelations()
    {
        $list = Relations::find()->select(["RelationID AS relationId", "RelationName AS relationName"])->asArray()->all();
        return $list;
    }
    public function getCashPickupPoints($countryId, $cityId, $receiveCurrencyCode)
    {
        return [
            [
                'id' => 1,
                'name' => 'getCashPickupPoints',
            ],
            [
                'id' => 2,
                'name' => 'Bank Manager',
            ],
            [
                'id' => 3,
                'name' => 'Civil Engineer',
            ],
            [
                'id' => 4,
                'name' => 'Doctor',
            ],
            [
                'id' => 5,
                'name' => 'Software Developer',
            ],
        ];
    }
    public function getWalletProviders($countryId)
    {
        return [
            [
                'id' => 1,
                'name' => 'getWalletProviders',
            ],
            [
                'id' => 2,
                'name' => 'Bank Manager',
            ],
            [
                'id' => 3,
                'name' => 'Civil Engineer',
            ],
            [
                'id' => 4,
                'name' => 'Doctor',
            ],
            [
                'id' => 5,
                'name' => 'Software Developer',
            ],
        ];
    }

    public function getNationality($params)
    {
        $sort = $params['sort'] ?? null;
        $page = intval($params['page']);
        $page = $page > 0 ? $page - 1 : 0;
        $limit = intval($params['limit']);

        if ($limit <= 0) {
            $limit = false;
        }
        $params = [
            "pageSize" => $limit,
        ];
        $searchModel = new \api\models\NationalitySearch();
        $dataProvider = $searchModel->search(array_merge($params));

        $models = $dataProvider->getModels();

        $nationalities = [];
        foreach ($models as $model) {
            $nationalities[] = [
                'nationalityId' => (int)$model->CountryID,
                'nationality' => $model->Nationality,
            ];
        }

        return [
            'nationality' => $nationalities,
            'pagination' => [
                'total' => $dataProvider->getTotalCount(),
                'page' => $params['page'] ?? 1,
                'pageSize' => $dataProvider->getPagination()->pageSize,
                'pageCount' => $dataProvider->getPagination()->getPageCount(),
            ],
        ];
    }
}
