<?php

namespace common\services;

use yii\validators\Validator;
use enum;
use common\models;
use common\models\Banks;
use common\models\Countries;

/**
 * CountryAccountValidator
 *
 * Validates TransactionInfo.Account according to the receiving country’s rules,
 * focusing on bank account number vs IBAN format.
 */
class BankAccountValidator extends Validator
{
    public $bankIdAttribute = '';
    public $branchIdAttribute = '';
    public $accountNumberAttribute = '';
    public $bankingIdentifierAttribute = '';
    public $countryIdAttribute = '';

    public $countryName = '';
    public $countryCode = '';
    public $countryId = '';
    public $bankingIdentifier = '';

    function ibanPatternMap(): array
    {
        return [
            'BH' => '/^BH[0-9]{2}[A-Z]{4}[A-Z0-9]{14}$/',        // length 22
            'EG' => '/^EG[0-9]{2}[0-9]{4}[0-9]{4}[0-9]{17}$/',   // length 29
            'JO' => '/^JO[0-9]{2}[A-Z]{4}[0-9]{22}$/',           // length 30
            'KW' => '/^KW[0-9]{2}[A-Z]{4}[A-Z0-9]{22}$/',        // length 30
            'PK' => '/^PK[0-9]{2}[A-Z]{4}[A-Z0-9]{16}$/',        // length 24
            'SA' => '/^SA[0-9]{2}[0-9]{2}[A-Z0-9]{18}$/',        // length 24
            'AE' => '/^AE[0-9]{2}[0-9]{3}[0-9]{16}$/',           // length 23
        ];
    }

    function accountPatternMap(): array
    {
        return [
            'BD' => '/^[0-9]{14,17}$/',   // length up to 17
            'IN' => '/^[0-9]{9,18}$/',    // length up to 18
            'PK' => '/^[0-9]{6,20}$/',    // length up to 20
            'PH' => '/^[0-9]{7,15}$/',    // length up to 15
        ];
    }



    public function validateAttribute($model, $attribute)
    {
        //$bankId = trim((string)$model->{$this->bankIdAttribute});
        $countryId = trim((string)$model->{$this->countryIdAttribute});
        $accountNumber = trim((string)$model->{$this->accountNumberAttribute});

        if (empty($countryName)) {
            // get country by bank
            // $bank = Banks::find()->where(["BankID" => $bankId])->one();
            // if ($bank == null) {
            //     $this->addError($model, $attribute, "Invalid Bank");
            //     return;
            // }
            //$countryId = $bank->CountryID;
            $country = Countries::find()->where(["CountryID" => $countryId])->one();
            if ($country == null) {
                $this->addError($model, $attribute, "Invalid Country");
                return;
            }
            $this->countryCode = $country->CountryCode;
            $this->countryName = $country->CountryName;

            $this->bankingIdentifier = BankingIdentifier::tryFrom(trim((string)$model->{$this->bankingIdentifierAttribute}));
        }


        $hasAccount = $accountNumber !== '';
        if (!$hasAccount) {
            $this->addError($model, $this->accountNumberAttribute, 'Provide Account Number !');
            return;
        }

        $this->requireAccount($model, $attribute, $accountNumber, $this->countryCode);
        return;
    }

    private function requireAccount($model, $attribute, $value, $countryCode)
    {
        if ($this->bankingIdentifier == BankingIdentifier::ACCOUNT || $this->bankingIdentifier == null) {
            if (!$this->accountFormatIsValid($value, $countryCode)) {
                $this->addError($model, $attribute, "$this->countryName  require a valid Account Number.");
            }
        } else if ($this->bankingIdentifier == BankingIdentifier::IBAN) {
            if (!$this->ibanFormatIsValid($value, $countryCode)) {
                $this->addError($model, $attribute, "$this->countryName require a valid IBAN.");
            }
        }
    }

    function ibanFormatIsValid(string $iban, string $countryIso): bool
    {
        $iban = strtoupper(preg_replace('/\s+/', '', $iban));
        $map  = $this->ibanPatternMap();

        if (!isset($map[$countryIso])) {
            return false;
        }

        return (bool)preg_match($map[$countryIso], $iban);
    }

    function accountFormatIsValid(string $account, string $countryIso): bool
    {
        $accountNumber = strtoupper(preg_replace('/\s+/', '', $account));
        $map  = $this->accountPatternMap();

        if (!isset($map[$countryIso])) {
            return false;
        }

        return (bool)preg_match($map[$countryIso], $accountNumber);
    }
}

enum BankingIdentifier: string
{
    case ACCOUNT = 'account';
    case IBAN    = 'iban';
    case UPI     = 'upi';
}
