<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',
    'user.passwordResetTokenExpire' => 3600,
    'user.passwordMinLength' => 8,
    'vatRate' => "0.05",
    // SMPP Configuration for Tamimah
    'smpp' => [
        'system_type' => 'SMS',
        'source_address_ton' => 5,
        'source_address_npi' => 0,
        'dest_address_ton'   => 2,
        'dest_address_npi'   => 1,
        'enable_delivery_receipts' => true,
        'timeout' => 30,
        'data_coding' => \Smpp\Smpp::DATA_CODING_DEFAULT,
        'validity_period' => 86400,
    ],
    'sms' => [
        'default_country_code' => '+968',
    ],
];
