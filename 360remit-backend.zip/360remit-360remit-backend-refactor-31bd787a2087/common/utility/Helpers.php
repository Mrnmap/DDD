<?php

namespace common\utility;

use Yii;
use Exception;
use yii\db\Query;
use yii\helpers\ArrayHelper;

class Helpers
{

    public static function logCall(
        string $userId,
        string $endpoint,
        $requestData = null,
        ?int $responseCode = null,
        $responseData = null,
        ?string $errorMessage = null
    ): void {
        $logData = [
            'userId'       => $userId,
            'endpoint'     => $endpoint,
            'requestData'  => $requestData,
            'responseCode' => $responseCode,
            'responseData' => $responseData,
            'errorMessage' => $errorMessage,
            'timestamp'    => date('Y-m-d H:i:s'),
            'ip'           => Yii::$app->request->userIP,
        ];

        Yii::info(json_encode($logData), 'api_calls');
    }
    public static function logErorr(
        string $userId,
        $requestData = null,
        ?int $responseCode = null,
        $responseData = null,
        ?string $errorMessage = null
    ): void {
        $logData = [
            'userId'       => $userId,
            'errorMessage' => $errorMessage,
            'timestamp'    => date('Y-m-d H:i:s'),
        ];

        Yii::info(json_encode($logData), 'api_calls');
    }

    public static function errorResponse(
        int $status,
        string $message,
        array $errors = [],
        string|null $remainingAttempts = null
    ): array {
        Yii::$app->response->statusCode = $status;

        // Map status codes to error types
        $errorTypes = [
            400 => 'Bad Request',
            401 => 'Unauthorized',
            402 => 'Payment Required',
            403 => 'Forbidden',
            404 => 'Not Found',
            405 => 'Method Not Allowed',
            406 => 'Not Acceptable',
            408 => 'Request Timeout',
            409 => 'Conflict',
            410 => 'Gone',
            411 => 'Length Required',
            412 => 'Precondition Failed',
            413 => 'Payload Too Large',
            414 => 'URI Too Long',
            415 => 'Unsupported Media Type',
            416 => 'Range Not Satisfiable',
            417 => 'Expectation Failed',
            422 => 'Unprocessable Entity',
            423 => 'Locked',
            429 => 'Too Many Requests',

            // 5xx Server Errors
            500 => 'Internal Server Error',
            501 => 'Not Implemented',
            502 => 'Bad Gateway',
            503 => 'Service Unavailable',
            504 => 'Gateway Timeout',
            505 => 'HTTP Version Not Supported'
        ];
        date_default_timezone_set('Asia/Muscat');
        $errorData = [
            'errorId' => self::generateUuidV4(),
            'timestamp' => date("Y-m-d\TH:i:s.u\Z"),
            'status' => $status,
            'errors' => $errors,
            'type' => $errorTypes[$status] ?? 'Unknown error',
            'path' => 'uri=' . Yii::$app->request->getUrl(),
            'message' => $message,
        ];
        if ($remainingAttempts != null) {
            $errorData["remainingAttempts"] = $remainingAttempts;
        }
        Yii::error(json_encode($errorData), 'api_errors');
        return $errorData;
    }

    public static function imageToBase64($imagePath)
    {
        // Check if file exists
        if (!file_exists($imagePath)) {
            return null;
        }
        $imageData = file_get_contents($imagePath);
        $base64 = base64_encode($imageData);
        return $base64;
    }

    public static function getCredentialsValue($keyName, $data)
    {
        $result = '';
        foreach ($data as $value) {
            if ($value->KeyName == $keyName) {
                $result = $value->KeyValue;
            }
        }
        return $result;
    }

    //this function to create unique error id for http response
    private static function generateUuidV4(): string
    {
        // Simple UUID v4 generator

        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // version 4
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // variant

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    static function  jsonToSha256($json)
    {
        // Decode JSON string into PHP array
        $data = json_decode($json, true);

        if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON input: " . json_last_error_msg());
        }

        // Recursively sort array by keys
        $sorted = self::sortRecursive($data);

        // Encode it back to JSON (no spaces, consistent ordering)
        $canonical = json_encode($sorted, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        // Return SHA-256 hash
        return hash('sha256', $canonical);
    }

    static function sortRecursive($data)
    {
        if (is_array($data)) {
            ksort($data); // sort by key
            foreach ($data as &$value) {
                $value = self::sortRecursive($value);
            }
        }
        return $data;
    }
}
