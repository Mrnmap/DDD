<?php

declare(strict_types=1);

use common\services\TransactionsService;

ini_set('display_errors', '1');
error_reporting(E_ALL);


require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../vendor/yiisoft/yii2/Yii.php';

/**
 * IMPORTANT: bring in bootstrap files so aliases like @api / @common are set.
 * If these files don't exist in your template, keep the fallback aliases below.
 */
$commonBootstrap = __DIR__ . '/../common/config/bootstrap.php';
$apiBootstrap    = __DIR__ . '/../api/config/bootstrap.php';
if (file_exists($commonBootstrap)) require $commonBootstrap;
if (file_exists($apiBootstrap))    require $apiBootstrap;

/** Fallbacks in case bootstraps didn’t define them */
if (Yii::getAlias('@common', false) === false) {
    Yii::setAlias('@common', __DIR__ . '/../common');
}
if (Yii::getAlias('@api', false) === false) {
    Yii::setAlias('@api', __DIR__ . '/../api');               // <-- fixes "Invalid path alias: @api/…"
}
if (Yii::getAlias('@runtime', false) === false) {
    Yii::setAlias('@runtime', __DIR__ . '/../api/runtime');   // ensure @runtime points to API runtime
}

// Use the real API app config (has 'id', 'basePath', log targets, etc.)
$config = require __DIR__ . '/../api/config/main.php';

// Keep consistent timestamps
date_default_timezone_set('Asia/Muscat');

// Make sure runtime/logs exists (avoids log file errors)
$logDir = Yii::getAlias('@runtime') . '/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0775, true);
}

Yii::$app = new yii\web\Application($config);
file_put_contents(__DIR__ . '/last_run.txt', date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);

try {
    $svc = new TransactionsService();
    // If your original method is private, call a public wrapper e.g. cronProcessTransaction()
    $svc->runProcessTransaction(); // or $svc->runProcessTransaction() if public
    echo "✅ Executed at " . date('c') . PHP_EOL;
} catch (Throwable $e) {
    Yii::error($e->getMessage(), 'cron_calls');
    http_response_code(500);
    echo "❌ " . $e->getMessage() . PHP_EOL;
    exit(1);
}
