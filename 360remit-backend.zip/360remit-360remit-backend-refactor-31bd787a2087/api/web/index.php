<?php

use Dotenv\Dotenv;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../../vendor/autoload.php';
require __DIR__ . '/../../vendor/yiisoft/yii2/Yii.php';

// load .env; 1. first get the general .env
$dotenv = Dotenv::createImmutable(__DIR__ . '/../../', '.env'); // the location of the .env is on the root directory
$dotenv->safeLoad();
// 2. get the required .env file
$env = $_ENV['APP_ENV'] ?? 'dev';
$envFile = '.env.' . $env;
if (is_file(__DIR__ . '/../../' . $envFile)) {
    // createMutable allows overriding values from the first load
    $dotenvEnv = Dotenv::createMutable(__DIR__ . '/../../', $envFile);
    $dotenvEnv->safeLoad();
}


defined('YII_DEBUG') or define('YII_DEBUG', ($_ENV['APP_DEBUG'] ?? 'false') === 'true');
defined('YII_ENV') or define('YII_ENV', $_ENV['APP_ENV']);
// define global value for env
define('APP_DEV', ($_ENV['APP_ENV'] === "dev"));
define('APP_PROD', ($_ENV['APP_ENV'] === "prod"));

require __DIR__ . '/../../common/config/bootstrap.php';
require __DIR__ . '/../config/bootstrap.php';

$config = yii\helpers\ArrayHelper::merge(
    require __DIR__ . '/../../common/config/main.php',
    require __DIR__ . '/../../common/config/main-local.php',
    require __DIR__ . '/../config/main.php',
    require __DIR__ . '/../config/main-local.php'
);

(new yii\web\Application($config))->run();
