<?php

namespace api\controllers;

use Yii;
use api\controllers\AuthController;
use common\classes\Mastercard;
use common\utility\Helpers;
use yii\web\NotFoundHttpException;
use function PHPUnit\Framework\throwException;

class TransactionsController extends AuthController
{
    public function actionIndex($transactionCode = null)
    {
        if (Yii::$app->request->isPost) {
            $data = Yii::$app->request->post();
            return [
                [
                    'id' => 1,
                    'name' => $data,
                ]
            ];
        } else if (Yii::$app->request->isGet) {
            if ($transactionCode != null) {
                return [
                    [
                        'id' => 1,
                        'name' => 'transactionCode',
                    ]
                ];
            } else {
                return [
                    [
                        'id' => 1,
                        'name' => 'group',
                    ]
                ];
            }
        }
    }
    /**
     * 
     * This function handles transactions\list endpoint.
     * Params:sort,date_from,date_to,page,limit
     * 
     */
    public function actionList()
    {
        if (Yii::$app->request->isGet) {
            $params = Yii::$app->request->get();
            return $this->asJson(
                $this->getTransactionsService()->getTransactions($params)
            );
        }
    }


    public function actionValidation()
    {
        if (Yii::$app->request->isPost) {
            $params = Yii::$app->request->post();
            return $this->asJson(
                $this->getTransactionsService()->validateTransaction($params)
            );
        }
    }

    public function actionStatus($transactionId)
    {
        if (Yii::$app->request->isGet) {
            $params = Yii::$app->request->get();
            return $this->asJson(
                $this->getTransactionsService()->checkPaymentStatus($transactionId)
            );
        }
    }

    /**
     * Submit a validated transaction to get payment URL
     * GET /transactions/submit?transactionId
     */
    public function actionSubmit()
    {
        if (Yii::$app->request->isGet) {
            $transactionId = Yii::$app->request->get('transactionId');

            if (empty($transactionId)) {
                return $this->asJson(
                    \common\utility\Helpers::errorResponse(400, "Validation failed: transactionId is required.")
                );
            }

            return $this->asJson(
                $this->getTransactionsService()->submitTransaction($transactionId)
            );
        }
    }
    public function getTransactionsService(): \common\services\TransactionsService
    {
        return Yii::$app->TransactionsService;
    }
}
