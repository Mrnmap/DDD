<?php

namespace api\controllers;

use Yii;
use yii\rest\Controller;
use yii\web\Response;
use common\services\SmppService;
use common\classes\Tamimah;

/**
 * SMS Controller for testing and managing SMS functionality
 */
class SmsController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        $behaviors = parent::behaviors();

        // Add CORS support
        $behaviors['corsFilter'] = [
            'class' => \yii\filters\Cors::class,
            'cors' => [
                'Origin' => ['*'],
                'Access-Control-Request-Method' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'],
                'Access-Control-Request-Headers' => ['*'],
                'Access-Control-Allow-Credentials' => true,
                'Access-Control-Max-Age' => 86400,
            ],
        ];

        return $behaviors;
    }

    /**
     * Test SMPP connection
     * 
     * @return array
     */
    public function actionTestConnection()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        try {
            $smppService = Yii::$app->smppService;
            $connected = $smppService->connect();

            return [
                'success' => $connected,
                'message' => $connected ? 'SMPP connection successful' : 'SMPP connection failed',
                'host' => $smppService->host,
                'port' => $smppService->port,
                'username' => $smppService->username,
                'is_connected' => $smppService->isConnected()
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Connection test failed: ' . $e->getMessage(),
                'host' => Yii::$app->params['smpp']['host'] ?? 'unknown',
                'port' => Yii::$app->params['smpp']['port'] ?? 'unknown'
            ];
        }
    }

    /**
     * Send test SMS via SMPP
     * 
     * @return array
     */
    public function actionSendTest()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        $phoneNumber = Yii::$app->request->post('phone');
        $message = Yii::$app->request->post('message', 'Test SMS from 360Remit API');

        if (empty($phoneNumber)) {
            return [
                'success' => false,
                'message' => 'Phone number is required'
            ];
        }

        try {
            $smppService = Yii::$app->smppService;
            $result = $smppService->sendSms($phoneNumber, $message);

            return [
                'success' => $result['success'],
                'message' => $result['message'],
                'message_id' => $result['message_id'],
                'partner_reference' => $result['partner_reference']
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'SMS sending failed: ' . $e->getMessage()
            ];
        }
    }
}
