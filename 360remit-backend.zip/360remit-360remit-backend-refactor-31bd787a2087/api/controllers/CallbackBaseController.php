<?php

namespace api\controllers;

use Yii;
use yii\rest\Controller;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\filters\Cors;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use common\models\User;
use app\components\JwtHelper;
use common\utility\Helpers;

class CallbackBaseController extends Controller
{
    public $user = null;

    public function init()
    {
        parent::init();
        Yii::$app->user->enableSession = false;
        $this->enableCsrfValidation = false;
        Yii::$app->response->format = Response::FORMAT_JSON;
    }
    public function actions()
    {
        return [
            // This will automatically reply to OPTIONS requests
            'options' => [
                'class' => 'yii\rest\OptionsAction',
            ],
        ];
    }

    // Optional: Allow CORS for APIs
    public function behaviors()
    {
        $behaviors = parent::behaviors();

        // Remove default behaviors that might interfere
        unset($behaviors['authenticator']);
        unset($behaviors['rateLimiter']);

        $behaviors['verbs'] = [
            'class' => VerbFilter::class,
            'actions' => [
                '*' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
            ],
        ];

        $behaviors['corsFilter'] = [
            'class' => Cors::class,
            'cors' => [
                'Origin' => ['*'],
                'Access-Control-Request-Method' => ['POST', 'GET', 'HEAD', 'OPTIONS', 'PUT', 'DELETE'],
                'Access-Control-Request-Headers' => ['*'],
                'Access-Control-Allow-Origin' => ['*'],
                'Access-Control-Allow-Methods' => ['POST', 'GET', 'OPTIONS', 'HEAD', 'PUT', 'DELETE'],
                'Access-Control-Allow-Headers' => ['*'],
                'Access-Control-Allow-Credentials' => false,
                'Access-Control-Max-Age' => 86400,
            ],
        ];

        return $behaviors;
    }
    /**
     * Authentication check for all inherited controllers
     */
    public function beforeAction($action)
    {
        // $userID = Yii::$app->request->get('user_id') ?? null;
        // if ($userID == null || !$this->IsValidUser($userID)) {
        //     Yii::$app->response->data = Helpers::errorResponse(401, "Invalid User!", ["user_id does not match"]);
        //     return false;
        // }

        // $authHeader = Yii::$app->request->getHeaders()->get('Authorization');
        // if (!$authHeader || !preg_match('/^Bearer\s+(.*)$/i', $authHeader, $matches)) {
        //     Yii::$app->response->statusCode = 401;
        //     echo json_encode(['error' => 'Authorization token required']);
        //     return false;
        // }

        // try {
        //     $decoded = JwtHelper::decodeToken($matches[1]);
        //     $user = User::findOne($decoded->sub);

        //     if (!$user) {
        //         Yii::$app->response->statusCode = 401;
        //         echo json_encode(['error' => 'Invalid user']);
        //         return false;
        //     }

        //     $this->user = $user;
        //     Yii::$app->user->identity = $user;
        // } catch (\Throwable $e) {
        //     Yii::$app->response->statusCode = 401;
        //     echo json_encode(['error' => 'Token invalid or expired']);
        //     return false;
        // }

        return parent::beforeAction($action);
    }
    /**
     * Login action to generate JWT
     */

    public static function IsValidUser($userID)
    {

        if ($userID != null || !empty($userID)) {
            // validate user with their token;
            return $userID == "1" || "2";
        } else {
            return false;
        }
    }
}
