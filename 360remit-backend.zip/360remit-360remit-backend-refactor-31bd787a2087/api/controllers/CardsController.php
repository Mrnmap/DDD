<?php

namespace api\controllers;

use Yii;
use api\controllers\AuthController;
use yii\web\NotFoundHttpException;
use function PHPUnit\Framework\throwException;

class CardsController extends AuthController
{
    public function actionIndex()
    {
        if (Yii::$app->request->isPost) {
            //save card
            $data = Yii::$app->request->post();
            return [
                [
                    'id' => 1,
                    'name' => $data,
                ]
            ];
        } else if (Yii::$app->request->isGet) {
            // get saved cards token
            $userID = Yii::$app->request->get('user_id') ?? null;
            return Yii::$app->CardsService->getSaveCardLink($userID);
        } else if (Yii::$app->request->isDelete) {
            // delete card
            return [
                [
                    'id' => 1,
                    'name' => 'group',
                ]
            ];
        }
    }
}
