<?php

namespace api\controllers;

use Yii;
use api\controllers\AuthController;
use common\utility\Helpers;
use yii\web\NotFoundHttpException;
use function PHPUnit\Framework\throwException;

class BeneficiariesController extends AuthController
{
    public function actionIndex($beneficiaryId = null)
    {
        if (Yii::$app->request->isPost) {
            $data = Yii::$app->request->post();
            $userID = Yii::$app->request->get('user_id') ?? null;
            return Yii::$app->BeneficiariesService->addBeneficiary($userID, $data);
        } else if (Yii::$app->request->isGet) {
            $userID = Yii::$app->request->get('user_id') ?? null;
            $beneficiaryId = Yii::$app->request->get('id') ?? null;
            
            if ($beneficiaryId) {
                // Return detailed beneficiary information
                $userID = Yii::$app->request->get('user_id') ?? null;
                $beneficiary = $this->getBeneficiariesService()->getBeneficiaryDetails($beneficiaryId, $userID);
                if (!$beneficiary) {
                    return Helpers::errorResponse(404, "Beneficiary not found", []);
                }
                return $this->asJson($beneficiary);
            } else {
                // Return list of beneficiaries (for when no specific ID is provided)
                $params = Yii::$app->request->get();
                return $this->getBeneficiariesService()->getBeneficiaries($params);
            }
        } else if (Yii::$app->request->isPut) {
            $data = Yii::$app->request->post();
            $userID = Yii::$app->request->get('user_id') ?? null;
            $beneficiaryId = Yii::$app->request->get('id') ?? null;
            return Yii::$app->BeneficiariesService->updateBeneficiary($userID, $beneficiaryId, $data);
        } else if (Yii::$app->request->isDelete) {
            $data = Yii::$app->request->post();
            $userID = Yii::$app->request->get('user_id') ?? null;
            $beneficiaryId = Yii::$app->request->get('id') ?? null;
            return Yii::$app->BeneficiariesService->deleteBeneficiary($userID, $beneficiaryId, $data);
        }
    }

    public function actionList()
    {
        $params = Yii::$app->request->get();
        return $this->getBeneficiariesService()->getBeneficiaries($params);
    }
    public function actionBankAccounts()
    {
        $userID = Yii::$app->request->get('user_id') ?? null;
        $beneficiaryId = Yii::$app->request->get('beneficiaryId') ?? null;
        $bankAccountId = Yii::$app->request->get('bankAccountId') ?? null;
        if (Yii::$app->request->isPost) {
            $data = Yii::$app->request->post();
            if ($beneficiaryId == null) {
                return Helpers::errorResponse(400, "Beneficiary not found", ["Id is required"]);
            }
            return $this->getBeneficiariesService()->addBankAccount($userID, $beneficiaryId, $data);
        } else if (Yii::$app->request->isGet) {
            if ($beneficiaryId == null) {
                throw new NotFoundHttpException("Beneficiary not found");
            }
            if ($bankAccountId != null) {
                return [
                    [
                        'id' => 1,
                        'name' => 'one',
                    ]
                ];
            } else {
                return [
                    [
                        'id' => 1,
                        'name' => 'Accountant',
                    ],
                    [
                        'id' => 2,
                        'name' => 'Bank Manager',
                    ],
                    [
                        'id' => 3,
                        'name' => 'Civil Engineer',
                    ],
                    [
                        'id' => 4,
                        'name' => 'Doctor',
                    ],
                    [
                        'id' => 5,
                        'name' => 'Software Developer',
                    ],
                ];
            }
        } else if (Yii::$app->request->isPut) {
            $data = Yii::$app->request->post();
            if ($beneficiaryId == null) {
                return Helpers::errorResponse(400, "Beneficiary not found", ["Id is required"]);
            }
            if ($bankAccountId == null) {
                return Helpers::errorResponse(400, "Bank Account not found", ["Bank Account is required"]);
            }
            return $this->getBeneficiariesService()->updateBankAccount($userID, $beneficiaryId, $bankAccountId, $data);
        } else if (Yii::$app->request->isDelete) {
            if ($beneficiaryId == null) {
                return Helpers::errorResponse(400, "Beneficiary not found", ["Id is required"]);
            }
            if ($bankAccountId == null) {
                return Helpers::errorResponse(400, "Bank Account not found", ["Bank Account is required"]);
            }
            return $this->getBeneficiariesService()->deleteBankAccount($userID, $beneficiaryId, $bankAccountId);
        }
    }

    public function actionWallets($beneficiaryId = null, $walletId = null)
    {
        if (Yii::$app->request->isPost) {
            $data = Yii::$app->request->post();
            return [
                [
                    'id' => 1,
                    'name' => $data,
                ]
            ];
        } else if (Yii::$app->request->isGet) {
            if ($beneficiaryId == null) {
                throw new NotFoundHttpException("Beneficiary not found");
            }
            if ($walletId != null) {
                return [
                    [
                        'id' => 1,
                        'name' => 'one',
                    ]
                ];
            } else {
                return [
                    [
                        'id' => 1,
                        'name' => 'Accountant',
                    ],
                    [
                        'id' => 2,
                        'name' => 'Bank Manager',
                    ],
                    [
                        'id' => 3,
                        'name' => 'Civil Engineer',
                    ],
                    [
                        'id' => 4,
                        'name' => 'Doctor',
                    ],
                    [
                        'id' => 5,
                        'name' => 'Software Developer',
                    ],
                ];
            }
        } else if (Yii::$app->request->isPut) {
            $data = Yii::$app->request->post();
            return [
                [
                    'id' => 1,
                    'edit' => $data,
                ]
            ];
        } else if (Yii::$app->request->isDelete) {
            $data = Yii::$app->request->post();
            return [
                [
                    'id' => 1,
                    'delete' => $data,
                ]
            ];
        }
    }

    public function actionTransactions()
    {
        if (Yii::$app->request->isGet) {
            return [
                [
                    'id' => 1,
                    'name' => 'Accountant',
                ],
                [
                    'id' => 2,
                    'name' => 'Bank Manager',
                ],
                [
                    'id' => 3,
                    'name' => 'Civil Engineer',
                ],
                [
                    'id' => 4,
                    'name' => 'Doctor',
                ],
                [
                    'id' => 5,
                    'name' => 'Software Developer',
                ],
            ];
        }
    }

    public function getBeneficiariesService(): \common\services\BeneficiariesService
    {
        return Yii::$app->BeneficiariesService;
    }


}
