<?php

namespace api\controllers;

use Yii;
use api\controllers\AuthController;
use common\utility\Helpers;
use api\models\NationalitySearch;

class ListingsController extends AuthController
{
    public function actionCountries()
    {
        $params = Yii::$app->request->get();

        return Yii::$app->ListingsService->getCountries($params);
    }
    public function actionOccupations()
    {
        return $this->asJson([
            'occupations' => Yii::$app->ListingsService->getOccupations()
        ]);
    }

    public function actionTransferPurposes()
    {
        return $this->asJson([
            'transferPurposes' => Yii::$app->ListingsService->getTransferPurposes()
        ]);
    }

    public function actionSourceOfFunds()
    {
        $params = Yii::$app->request->get();
        $result = Yii::$app->ListingsService->getSourceOfFund($params);

        return $this->asJson($result);
    }


    public function actionStates($countryId)
    {
        return $this->asJson([
            'states' => Yii::$app->ListingsService->getStates($countryId)
        ]);
    }

    public function actionCities($countryId, $stateId)
    {
        return $this->asJson([
            'cities' => Yii::$app->ListingsService->getCities($countryId, $stateId)
        ]);
    }
    public function actionRelations()
    {
        return $this->asJson([
            'relations' => Yii::$app->ListingsService->getRelations()
        ]);
    }

    public function actionIdTypes()
    {
        return $this->asJson([
            'idTypes' => Yii::$app->ListingsService->getIdTypes()
        ]);
    }

    public function actionDeliveryMethods($countryId)
    {
        return $this->asJson([
            'deliveryMethods' => Yii::$app->ListingsService->getDeliveryMethods($countryId)
        ]);
    }

    public function actionCashPickupPoints($countryId, $cityId, $receiveCurrencyCode)
    {
        return $this->asJson([
            'cashPickupPoints' => Yii::$app->ListingsService->getCashPickupPoints($countryId, $cityId, $receiveCurrencyCode)
        ]);
    }
    public function actionWalletProviders($countryId)
    {
        return $this->asJson([
            'walletProviders' => Yii::$app->ListingsService->getWalletProviders($countryId)
        ]);
    }

    /**
     * GET /api/user/bank/list
     * Purpose: Provide a list of banks from Mastercard, sorted by the selected country.
     * This endpoint follows the GOOD document requirements with proper validation and pagination.
     */
    public function actionBankList()
    {
        $params = Yii::$app->request->get();  // collects page, pageSize, countryId, Name etc.
        $result = Yii::$app->ListingsService->getBanks($params);

        return $this->asJson($result);
    }


    /**
     * GET /api/listings/BankBranches
     * Purpose: Provide a list of bank branches from Mastercard, sorted by the selected bank.
     * This endpoint follows the GOOD document requirements with proper validation and pagination.
     */
    public function actionBankBranches()
    {
        $params = Yii::$app->request->get();
        $result = Yii::$app->ListingsService->getBankBranches($params);

        return $this->asJson($result);
    }

    /**
     * GET /api/listings/nationality/list
     * Purpose: Provide a list of nationalities with pagination.
     * This endpoint follows the GOOD document requirements with proper validation and pagination.
     */
    public function actionNationalities()
    {
        $params = Yii::$app->request->get();
        $result = Yii::$app->ListingsService->getNationality($params);

        return $this->asJson($result);
    }
}
