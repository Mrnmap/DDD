<?php

namespace api\controllers;

use Yii;
use yii\rest\Controller;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\filters\Cors;
use yii\db\Transaction;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Throwable;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

use common\models\Users;
use common\services\AuthService;
use app\components\JwtHelper;
use common\utility\Helpers;

class AuthController extends Controller
{
    public $user = null;

    public function init()
    {
        parent::init();
        Yii::$app->user->enableSession = false;
        $this->enableCsrfValidation = false;
        Yii::$app->response->format = Response::FORMAT_JSON;
    }

    public function actions()
    {
        return [
            'options' => [
                'class' => 'yii\rest\OptionsAction',
            ],
        ];
    }

    // CORS + verbs
    public function behaviors()
    {
        $behaviors = parent::behaviors();

        unset($behaviors['authenticator'], $behaviors['rateLimiter']);

        $behaviors['verbs'] = [
            'class' => VerbFilter::class,
            'actions' => [
                '*' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
            ],
        ];

        $behaviors['corsFilter'] = [
            'class' => Cors::class,
            'cors' => [
                'Origin' => ['*'],
                'Access-Control-Request-Method' => ['POST', 'GET', 'HEAD', 'OPTIONS', 'PUT', 'DELETE'],
                'Access-Control-Request-Headers' => ['*'],
                'Access-Control-Allow-Origin' => ['*'],
                'Access-Control-Allow-Methods' => ['POST', 'GET', 'OPTIONS', 'HEAD', 'PUT', 'DELETE'],
                'Access-Control-Allow-Headers' => ['*'],
                'Access-Control-Allow-Credentials' => false,
                'Access-Control-Max-Age' => 86400,
            ],
        ];

        return $behaviors;
    }

    /**
     * Gatekeeper: bypass for auth/OTP endpoints; require basic user check otherwise (temporary until JWT is enabled)
     */
    public function beforeAction($action)
    {
        $bypass = ['login', 'token', 'send-otp', 'verify-otp'];
        if (in_array($action->id, $bypass, true)) {
            return parent::beforeAction($action);
        }

        // TODO: replace with JWT check later. For now use ?user_id=
        $userID = Yii::$app->request->get('user_id') ?? null;
        if ($userID === null || !$this->IsValidUser($userID)) {
            Yii::$app->response->data = Helpers::errorResponse(401, "Invalid User!", ["user_id does not match"]);
            return false;
        }

        return parent::beforeAction($action);
    }

    /**
     * Login stub
     */
    public function actionLogin()
    {
        $data = Yii::$app->request->post();
        return [
            'success' => true,
            'message' => 'POST request successful',
            'received' => $data,
        ];
    }

    public function actionToken()
    {
        $data = Yii::$app->request->post();
        return [
            'success' => true,
            'message' => 'POST request token',
            'received' => $data,
        ];
    }

    /**
     * Send OTP (delegates to AuthService)
     */
    public function actionSendOtp()
    {
        $data = Yii::$app->request->post();
        $d = AuthService::sendOtp($data);
        return $this->asJson($d);
    }

    /**
     * Verify OTP — full flow with validation, expiry & attempts handling
     */
    public function actionVerifyOtp()
    {
        $requestData = Yii::$app->request->post();

        $result = AuthService::verifyOtp($requestData);
        return $this->asJson($result);
    }


    /**
     * Create PIN endpoint: POST /api/auth/pin
     */
    public function actionPin()
    {
        // POST only
        if (!Yii::$app->request->isPost) {
            Yii::$app->response->statusCode = 405;
            return Helpers::errorResponse(405, 'Method not allowed', ['Only POST method is allowed']);
        }

        $data = Yii::$app->request->post();
        $pin  = $data['pin'] ?? null;

        // TODO: switch to JWT when ready
        $userId = Yii::$app->request->get('user_id') ?? null;

        if ($userId === null) {
            Yii::$app->response->statusCode = 401;
            return Helpers::errorResponse(401, 'Session has expired. Please log in again.', ['Invalid or missing user identifier']);
        }

        // TODO: switch to JWT when ready
        if (!$this->IsValidUser($userId)) {
            Yii::$app->response->statusCode = 401;
            return Helpers::errorResponse(401, 'Session has expired. Please log in again.', ['Invalid user']);
        }

        $result = AuthService::createPin($userId, $pin);

        if (!$result['success']) {
            Yii::$app->response->statusCode = $result['status'];
            $errorMessage = 'Missing or invalid pin.';

            if (!empty($result['message']) && $result['status'] === 400) {
                $errorMessage = $result['message'];
            } elseif ($result['status'] === 401) {
                $errorMessage = 'Session has expired. Please log in again.';
            } elseif ($result['status'] === 409) {
                $errorMessage = 'Pin already set for this user.';
            } elseif (isset($result['error']) && $result['status'] !== 400) {
                $errorMessage = $result['error'];
            }

            return Helpers::errorResponse($result['status'], $errorMessage, [$errorMessage]);
        }

        Yii::$app->response->statusCode = 201;
        return [
            'userId'  => $result['userId'],
            'message' => $result['message'],
        ];
    }

    /**
     * Verify PIN endpoint: POST /api/auth/verify-pin
     * 
     * Verifies a user's PIN for authentication or transaction confirmation.
     * Returns success if PIN is correct, error if incorrect.
     */
    public function actionVerifyPin()
    {
        // Only handle POST requests
        if (!Yii::$app->request->isPost) {
            Yii::$app->response->statusCode = 405;
            return Helpers::errorResponse(405, 'Method not allowed', ['Only POST method is allowed']);
        }

        // Get request data
        $data = Yii::$app->request->post();
        $pin = $data['pin'] ?? null;

        // Validate JWT token (commented out for now)
        // TODO: Uncomment when JWT authentication is implemented
        /*
        $authHeader = Yii::$app->request->getHeaders()->get('Authorization');
        $tokenValidation = AuthService::validateJwtToken($authHeader);
        
        if ($tokenValidation === null) {
            Yii::$app->response->statusCode = 401;
            return Helpers::errorResponse(401, 'Session has expired. Please log in again.', ['Session validation failed']);
        }
        
        $userId = $tokenValidation['user_id'];
        */


        $userId = Yii::$app->request->get('user_id') ?? null;
        // TODO: to be removed when JWT is used
        // Validate user exists
        if ($userId === null) {
            Yii::$app->response->statusCode = 401;
            return Helpers::errorResponse(401, 'Session has expired. Please log in again.', ['Invalid or missing user identifier']);
        }
        // TODO: switch to JWT when ready
        // Verify user is valid
        if (!$this->IsValidUser($userId)) {
            Yii::$app->response->statusCode = 401;
            return Helpers::errorResponse(401, 'Session has expired. Please log in again.', ['Invalid user']);
        }


        // Validate PIN format
        $formatError = AuthService::validatePinFormat($pin);
        if ($formatError !== null) {
            Yii::$app->response->statusCode = 400;
            return Helpers::errorResponse(400, $formatError['message'], [$formatError['error']]);
        }

        // Verify the PIN
        $result = AuthService::verifyUserPin($userId, $pin);

        if ($result['success'] == false) {
            $responseCode = $result['code'] ?? 400; //default error code
            $remainingAttempts = $result['remainingAttempts'] ?? null; //default error code
            Yii::$app->response->statusCode = $responseCode;
            $errorMessage = $result['message'] ?? 'Invalid PIN.';
            return Helpers::errorResponse($responseCode, $errorMessage, [$result['error'] ?? 'PIN verification failed'], $remainingAttempts);
        }

        // Success response
        Yii::$app->response->statusCode = 200;
        return [
            'userId' => (string)$userId,
            'message' => $result['message'],
            'pinLockStatus' => $result['pinLockStatus']
        ];
    }


    public static function IsValidUser($userID): bool
    {
        if ($userID === null || $userID === '') {
            return false;
        }
        // TODO: fixed logic
        //return in_array((string)$userID, ['1', '2'], true);
        return true;
    }
}
