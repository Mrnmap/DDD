<?php

namespace api\controllers;

use Yii;
use api\controllers\AuthController;
use yii\web\BadRequestHttpException;

class PricingController extends AuthController
{
    public function actionCalculations()
    {
        // sending country, receiveing contry, sending currency, receiveing currency
        if (!Yii::$app->request->isGet) {
            throw new BadRequestHttpException('Only GET requests are allowed.');
        }

        $params = Yii::$app->request->get();
        return $this->asJson(
            Yii::$app->PricingService->getPricingCalculations($params)
        );
    }

    public function actionExchangeRate()
    {
        if (!Yii::$app->request->isGet) {
            throw new BadRequestHttpException('Only GET requests are allowed.');
        }

        $params = Yii::$app->request->get();
        return $this->asJson(
            Yii::$app->PricingService->getExchangeRate($params)
        );
    }
}
