<?php

namespace api\controllers;

use Yii;
use yii\rest\Controller;
use yii\web\Response;
use yii\web\UnauthorizedHttpException;
use yii\filters\VerbFilter;
use yii\filters\ContentNegotiator;

class CronController extends Controller
{
    public function behaviors()
    {
        $b = parent::behaviors();

        // Always return JSON responses
        $b['contentNegotiator'] = [
            'class'   => ContentNegotiator::class,
            'formats' => ['application/json' => Response::FORMAT_JSON],
        ];

        // Optionally restrict HTTP verbs
        $b['verbs'] = [
            'class'   => VerbFilter::class,
            'actions' => [
                '*' => ['GET', 'POST'], // or GET, depending on your use
            ],
        ];

        return $b;
    }

    /**
     * This runs before any action and validates the Bearer token.
     */
    public function beforeAction($action)
    {
        if (!parent::beforeAction($action)) {
            return false;
        }

        $this->validateAuthorization();
        return true;
    }

    /**
     * Example endpoint: POST /cron/my-function
     */
    public function actionProcessTransaction()
    {

        Yii::$app->ProcessTransaction->process();
        return [
            'ok' => true,
            'message' => 'Authorized. my-function executed successfully.',
            'timestamp' => date('Y-m-d H:i:s'),
        ];
    }

    /* ----------------- helpers ----------------- */

    private function validateAuthorization(): void
    {
        $headers = Yii::$app->request->getHeaders();
        $provided = $headers->get('X-Api-Key') ?? Yii::$app->request->get('key');

        $expected = (string)(Yii::$app->params['cronSecret'] ?? '');

        if ($expected === '' || !hash_equals($expected, (string)$provided)) {
            throw new \yii\web\UnauthorizedHttpException('Invalid or missing API key.');
        }
    }
}
