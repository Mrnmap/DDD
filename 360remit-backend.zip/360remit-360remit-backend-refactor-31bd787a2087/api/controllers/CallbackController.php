<?php

namespace api\controllers;

use Yii;
use api\controllers\AuthController;
use common\utility\Helpers;
use SebastianBergmann\Type\FalseType;
use yii\web\NotFoundHttpException;
use function PHPUnit\Framework\throwException;

class CallbackController extends CallbackBaseController
{
    // function to receive updates from paymentgatway

    public function actionPayment()
    {

        // to update payment status
        if (!Yii::$app->request->isPost) {
            return ['error' => 'request is not valid'];
        }
        $postBody = Yii::$app->request->bodyParams;
        // Extract Mastercard callback data
        $paymentId = Yii::$app->request->post('Payment_ID', '');
        $status = Yii::$app->request->post('PG_Transaction_Status', '');
        $reference = Yii::$app->request->post('Transaction_Ref_ID', ''); // if the transaction ref id is empty means it is a card registery
        $transactionCode = Yii::$app->request->post('TransactionCode', ''); // in card registery the transactionCode is the user id
        $transactionID = Yii::$app->request->post('Transaction_ID', '');
        $amount = Yii::$app->request->post('Amount', '');
        $cardToken = Yii::$app->request->post('Card_Token', '');
        $cardType = Yii::$app->request->post('Card_Type', '');
        $errorMsg = Yii::$app->request->post('Error_Text', '');
        $requestType = Yii::$app->request->post('Request_type', ''); // requesttype can be saveCard, deleteCard, transactionToken, transaction


        if (!empty(trim($transactionCode))) {
            // save card
            $index = strpos($transactionCode, "u");
            if ($index !== false) {
                $userId = substr($transactionCode, 0, $index);
                $service = $this->getCardsService();
                return $service->saveCard($userId, $cardToken, $cardType);
            }
        }
        // - update status transacation payment with tokenized card
        // - update satatus
    }
    // function to receive update from transaction cuirer
    public function actionTransaction() {}

    public function getCardsService(): \common\services\CardsService
    {
        return Yii::$app->CardsService;
    }
}
