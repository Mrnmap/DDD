<?php

namespace api\controllers;

use common\models\Customers;
use Yii;
use yii\rest\Controller;
use yii\web\Response;
use yii\web\UnauthorizedHttpException;
use yii\filters\VerbFilter;
use yii\filters\ContentNegotiator;
use common\utility\Helpers;

class AdminController extends Controller
{
    public function behaviors()
    {
        $b = parent::behaviors();

        // Always return JSON responses
        $b['contentNegotiator'] = [
            'class'   => ContentNegotiator::class,
            'formats' => ['application/json' => Response::FORMAT_JSON],
        ];

        // Optionally restrict HTTP verbs
        $b['verbs'] = [
            'class'   => VerbFilter::class,
            'actions' => [
                '*' => ['GET', 'POST'], // or GET, depending on your use
            ],
        ];

        return $b;
    }

    /**
     * This runs before any action and validates the Bearer token.
     */
    public function beforeAction($action)
    {
        if (!parent::beforeAction($action)) {
            return false;
        }

        $this->validateAuthorization();
        return true;
    }

    /**
     * Example endpoint: POST 
     */
    public function actionNotifyCustomer()
    {
        // send sms to customer
        //data = {userId:"1",message="you'r account is active now"}

        $data = Yii::$app->request->post();
        $errors = $this->validatePayload($data);
        if (Count($errors) > 0) {
            return Helpers::errorResponse(400, 'validation error', $errors);
        }
        //validate data in the post method
        $smpp = Yii::$container->get('smpp');
        if ($smpp == null) {
            return Helpers::errorResponse(400, 'SMS connection Provider error');
        }
        $customer = Customers::findOne(['UserID' => $data["userId"]]);
        if ($customer == null) {
            return Helpers::errorResponse(404, 'Customer not found!');
        }
        $result = $smpp->sendSms($customer->MobileNo, $data["message"]);
        return $result;
    }

    /* ----------------- helpers ----------------- */

    private function validateAuthorization(): void
    {
        $headers = Yii::$app->request->getHeaders();
        $provided = $headers->get('X-Api-Key') ?? Yii::$app->request->get('key');

        $expected = (string)(Yii::$app->params['cronSecret'] ?? '');

        if ($expected === '' || !hash_equals($expected, (string)$provided)) {
            throw new \yii\web\UnauthorizedHttpException('Invalid or missing API key.');
        }
    }

    public function validatePayload(array $data): array
    {
        $errors = [];

        // Check required fields
        if (!isset($data['userId']) || $data['userId'] === '') {
            $errors['userId'][] = 'userId is required.';
        }

        if (!isset($data['message']) || trim($data['message']) === '') {
            $errors['message'][] = 'message is required.';
        }

        // Validate userId
        if (isset($data['userId']) && !ctype_digit((string)$data['userId'])) {
            $errors['userId'][] = 'userId must be an integer.';
        }

        // Validate message length
        if (isset($data['message']) && strlen($data['message']) > 255) {
            $errors['message'][] = 'message cannot exceed 255 characters.';
        }

        return $errors; // empty = valid
    }
}
