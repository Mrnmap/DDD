<?php

namespace api\controllers;

use Yii;
use api\controllers\AuthController;
use common\services\OnboardingService;
use common\utility\Helpers;
use yii\web\NotFoundHttpException;
use function PHPUnit\Framework\throwException;

class UserController extends AuthController
{
    public function actionIndex() {}

    public function actionEkycSubmit()
    {
        $reportId = trim((string)(Yii::$app->request->post('reportId') ?? ''));
        if ($reportId === '') {
            return Helpers::errorResponse(400, 'reportId is required', []);
        }

        try {
            $userId = Yii::$app->request->get('user_id') ?? null;
            //TODO: define user here assumes auth; adjust if anonymous flow
            //$userId = (int)Yii::$app->user->id; // assumes auth; adjust if anonymous flow
            $svc = new OnboardingService();
            $result = $svc->processReport($reportId, $userId);

            if ($result["sucess"] == true && $result["isReportPassed"] == true) {
                //get all the report information
                return ["reportId" => $result["reportId"], "data" => $result["data"]];
            } else if ($result["sucess"] == true && $result["isReportPassed"] == false) {
                // get the reason why not sucessfull or not passed
                return Helpers::errorResponse(400, "Onboarding Failed!", [$result["reasons"]]);
            } else {
                return Helpers::errorResponse(500, "Onboarding Failed!", [$result["reasons"]]);
            }
        } catch (\RuntimeException $e) {
            Yii::error(['ekyc_submit_error' => $e->getMessage()], __METHOD__);
            return Helpers::errorResponse(404, $e->getMessage(), []);
        } catch (\Throwable $e) {
            Yii::error(['ekyc_submit_error' => $e->getMessage()], __METHOD__);
            return Helpers::errorResponse(500, $e->getMessage(), []);
        }
    }

    public function actionProfile()
    {
        $userId = Yii::$app->request->get('user_id') ?? null;
        $params = Yii::$app->request->bodyParams;
        $svc = new OnboardingService();
        return $svc->updateProfile($userId, $params);
    }
}
