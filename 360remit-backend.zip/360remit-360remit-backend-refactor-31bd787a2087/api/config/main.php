<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

return [
    'id' => 'app-api',
    'basePath' => dirname(__DIR__),
    'controllerNamespace' => 'api\controllers',
    'bootstrap' => ['log'],
    'timeZone' => 'Asia/Muscat',
    'components' => [
        'request' => [
            'csrfParam' => '_csrf-api',
            'enableCookieValidation' => false,
            'enableCsrfValidation' => false,
            'cookieValidationKey' => 'CHANGE-THIS-TO-RANDOM-32-CHAR-STRING',
            'parsers' => [
                'application/json' => 'yii\web\JsonParser',
            ]
        ],
        'response' => [
            'format' => yii\web\Response::FORMAT_JSON,
            'charset' => 'UTF-8',
        ],
        'user' => [
            'class' => 'yii\web\User',
            'identityClass' => 'common\models\User',
            'enableAutoLogin' => false,
            'enableSession' => false,
            'loginUrl' => null,
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                    'logFile' => '@api/runtime/logs/api.log',
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info'],
                    'categories' => ['api_calls'],
                    'logFile' => '@api/runtime/logs/api_calls.log',
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error'],
                    'categories' => ['api_errors'],
                    'logFile' => '@api/runtime/logs/api_errors.log',
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info'],
                    'categories' => ['sent_requests_to_mastercard'],
                    'logFile' => '@api/runtime/logs/sent_requests_to_mastercard.log',
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info'],
                    'categories' => ['mastercard_respond'],
                    'logFile' => '@api/runtime/logs/mastercard_respond.log',
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info', 'warning'],
                    'categories' => ['cron_calls'],
                    'logFile' => '@api/runtime/logs/cron_calls.log',
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info'],
                    'categories' => ['cron_result'],
                    'logFile' => '@api/runtime/logs/cron_result.log',
                    'logVars' => [],
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info'],
                    'categories' => ['process_transaction_result'],
                    'logFile' => '@api/runtime/logs/process_transaction_result.log',
                    'logVars' => [],
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info'],
                    'categories' => ['release_to_mastercard'],
                    'logFile' => '@api/runtime/logs/release_to_mastercard.log'
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info'],
                    'categories' => ['discontinued_transaction_result'],
                    'logFile' => '@api/runtime/logs/discontinued_transaction_result.log',
                    'logVars' => [],
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['info'],
                    'categories' => ['otp'],
                    'logFile' => '@otp/runtime/logs/otp.log',
                    'logVars' => [],
                ],
            ],
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'enableStrictParsing' => false,
            'showScriptName' => false,
            'rules' => [],
        ],
        'errorHandler' => [
            'class' => 'yii\console\ErrorHandler',
        ],
        'ListingsService' => [
            'class' => 'common\services\ListingsService',
        ],
        'PricingService' => [
            'class' => 'common\services\PricingService',
        ],
        'BeneficiariesService' => [
            'class' => 'common\services\BeneficiariesService',
        ],
        'TransactionsService' => [
            'class' => 'common\services\TransactionsService',
        ],
        'CardsService' => [
            'class' => 'common\services\CardsService',
        ],
        'BankAccountService' => [
            'class' => 'common\services\BankAccountService',
        ],
        'ProcessTransaction' => [
            'class' => 'common\services\ProcessTransaction',
        ],
        'ScreeningService' => [
            'class' => 'common\services\ScreeningService',
        ],
        'smppService' => [
            'class' => 'common\services\SmppService',
        ],
        'AuthService' => [
            'class' => 'common\services\AuthService',
        ],
    ],
    'params' => $params,
];
