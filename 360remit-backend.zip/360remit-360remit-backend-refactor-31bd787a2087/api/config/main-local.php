<?php
return [
    'components' => [
        'db' => [
            'class' => \yii\db\Connection::class,
            'dsn' => $_ENV["DB_DSN"],
            'username' => $_ENV["DB_USER"],
            'password' => $_ENV["DB_PASS"],
        ],
        'request' => [
            // Add any local request settings
        ],
    ],
];
