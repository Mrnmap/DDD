<?php
Yii::setAlias('@api', dirname(__DIR__));
Yii::setAlias('@otp', dirname(__DIR__, 2) . '/otp');
Yii::setAlias('@flagsDirectory', dirname(__DIR__) . "/assets/flags");
Yii::$container->setSingleton('smpp', function () {
    $service = new \common\services\SmppService();
    $connection = $service->connect();
    if ($connection == false) {
        return null;
    }
    return $service;
});
