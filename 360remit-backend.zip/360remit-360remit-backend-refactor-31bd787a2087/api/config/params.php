<?php
return [
    'adminEmail' => 'admin@example.com',
    'jwt' => [
        'issuer' => 'your-api-domain.com',
        'audience' => 'your-api-domain.com',
        'id' => 'your-unique-id',
        'expire' => 3600, // 1 hour
    ],
    'cronSecret' => '9f4a5c3b8b1d77a0d3342e456ff09dc6b9134d54013d30252ce4225cc46b0d42',
];
