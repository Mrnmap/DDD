<?php

namespace api\models; // or common\models

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Countries;

class NationalitySearch extends Countries
{
    // Add any extra public properties for filtering if needed
    // public $someFilter;
    public $selectColumns = ['CountryID', 'CountryName', 'PhoneCode', 'CountryCode', 'Nationality'];
    public function rules()
    {
        return [
            [['CountryCode', 'CountryName', 'Nationality'], 'safe'],
            [['PhoneCode', 'PaymentProviderID', 'DeliveryPartnerID', 'IsIDMandatory', 'IsSpecificPayer', 'Enable', 'IsDelete', 'CreateUID', 'UpdateUID'], 'integer'],
            [['OnDate', 'UpdatedDate'], 'safe'],
        ];
    }

    public function scenarios()
    {
        // bypass parent scenarios to use default implementation
        return Model::scenarios();
    }

    public function search($params)
    {

        $query = Countries::find()->select($this->selectColumns)
            ->where(['!=', 'Nationality', ''])
            ->where(['IsNationalityEnabled' => 1])
            ->andWhere(['not', ['Nationality' => null]])
            ->groupBy('Nationality')
            ->orderBy('Nationality ASC');


        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => $params['pageSize'] ?? 10,
            ],
            'sort' => [
                'defaultOrder' => [
                    'CountryName' => SORT_ASC,
                ],
            ],
        ]);

        // Load the search parameters into the model
        $this->load($params);

        if (!$this->validate()) {
            // optionally return empty data when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // Add filtering conditions:
        $query->andFilterWhere(['CountryCode' => $this->CountryCode]);
        $query->andFilterWhere(['like', 'CountryName', $this->CountryName]);
        $query->andFilterWhere(['PhoneCode' => $this->PhoneCode]);
        $query->andFilterWhere(['like', 'Nationality', $this->Nationality]);

        // add more filters as needed...

        return $dataProvider;
    }
}
