<?php

namespace api\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Beneficiaries;

class BeneficiariesSearch extends Beneficiaries
{
    public function rules()
    {
        return [
            // add rules for searchable attributes
            [['BeneficiaryID', 'UserID', 'IsDelete'], 'integer'],
            [['FirstName', 'MiddleName', 'LastName', 'Status', 'Email', 'Phone', 'House', 'Street', 'State', 'City', 'Nationality', 'Gender', 'IDTypeID', 'IDNo', 'DocExpiry', 'OnDate', 'UpdatedDate'], 'safe'],
        ];
    }

    public function search($params)
    {
        $query = Beneficiaries::find()->where(["IsDelete" => 0])->with("nationality");
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => $params['pageSize'] ?? 10,
            ],
            'sort' => [
                'defaultOrder' => [
                    'BeneficiaryID' => SORT_ASC,
                ],
            ],
        ]);
        $this->load($params);

        if (!$this->validate()) {
            // uncomment this line if you want to return no records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        // add filtering conditions here, example:
        $query->andFilterWhere([
            'BeneficiaryID' => $this->BeneficiaryID,
            'UserID' => $this->UserID,
            'State' => $this->State,
            'City' => $this->City,
            'IsDelete' => $this->IsDelete,
            'Status' => $this->Status,
            'DocExpiry' => $this->DocExpiry,
            'OnDate' => $this->OnDate,
            'UpdatedDate' => $this->UpdatedDate,
        ]);

        $query->andFilterWhere(['like', 'FirstName', $this->FirstName])
            ->andFilterWhere(['like', 'LastName', $this->LastName])
            ->andFilterWhere(['like', 'Email', $this->Email])
            ->andFilterWhere(['like', 'Phone', $this->Phone])
            ->andFilterWhere(['like', 'Nationality', $this->Nationality])
            ->andFilterWhere(['like', 'Gender', $this->Gender])
            ->andFilterWhere(['like', 'IDTypeID', $this->IDTypeID])
            ->andFilterWhere(['like', 'IDNo', $this->IDNo]);

        return $dataProvider;
    }
}
