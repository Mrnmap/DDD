<?php

namespace api\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\BanksBranches;

class BanksBranchesSearch extends BanksBranches
{
    // Selected columns for API output with camelCase aliases
    public $selectColumns = [
        'BanksBranches.BranchID AS branchId',
        //'BanksBranches.BankID AS bankId',
        'BanksBranches.ID AS branchCode',
        'BanksBranches.Branch AS branchName'
    ];

    public $BankID;      // used for filtering
    public $Branch;      // used for filtering

    public function rules()
    {
        return [
            [['BankID'], 'integer'],
            [['Branch'], 'safe'],
        ];
    }

    public function scenarios()
    {
        return Model::scenarios();
    }

    public function search($params)
    {
        // Validate required parameters
        if (empty($params['bankId'])) {
            throw new \yii\web\BadRequestHttpException('Bank ID is required. Please provide BankID parameter.');
        }

        // Validate BankID is numeric
        if (!is_numeric($params['bankId'])) {
            throw new \yii\web\BadRequestHttpException('Bank ID must be a valid number.');
        }

        // Build query
        $query = BanksBranches::find()
            ->select($this->selectColumns)
            ->where(['BanksBranches.Enable' => 1])
            ->andWhere([
                'AND',
                ['IS NOT', 'BanksBranches.MCBankID', null],
                ['!=', 'BanksBranches.MCBankID', '']
            ])
            ->orderBy(['BanksBranches.Branch' => SORT_ASC])
            ->asArray();

        // Data provider with pagination and sorting
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'key' => 'branchId', // Use the alias as the key field
            'pagination' => [
                'pageSize' => $params['pageSize'] ?? false,
                'page' => $params['page'], // Yii pagination is 0-indexed
            ],
            'sort' => false, // Disable sorting to avoid column name issues
        ]);

        // Load filter params
        $this->load($params, '');

        if (!$this->validate()) {
            $errors = $this->getErrors();
            $errorMessage = 'Validation failed: ' . implode(', ', array_map(function ($field, $messages) {
                return $field . ': ' . implode(', ', $messages);
            }, array_keys($errors), $errors));
            throw new \yii\web\BadRequestHttpException($errorMessage);
        }

        // Filter by bank ID
        if (isset($params['bankId']) && !empty($params['bankId'])) {
            $query->andWhere(['BanksBranches.BankID' => $params['bankId']]);
        }

        // // Filter by branch name
        // if (!empty($this->Branch)) {
        //     $query->andFilterWhere(['like', 'BanksBranches.Branch', $this->Branch]);
        // }

        return $dataProvider;
    }
}
