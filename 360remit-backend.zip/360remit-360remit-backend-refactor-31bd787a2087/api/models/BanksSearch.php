<?php

namespace api\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Banks;

class BanksSearch extends Banks
{

    public $selectColumns = [
        'Banks.BankID AS bankId',
        'Banks.Name AS bankName'
    ];

    public $Name;
    public $countryId;

    public function rules()
    {
        return [
            [['countryId'], 'integer'],
            [['Name'], 'safe'],
        ];
    }

    public function scenarios()
    {
        return Model::scenarios();
    }

    public function search($params)
    {
        // Validate required parameters
        if (empty($params['countryId'])) {
            throw new \yii\web\BadRequestHttpException('Country ID is required. Please provide countryId parameter.');
        }

        // Validate countryId is numeric
        if (!is_numeric($params['countryId'])) {
            throw new \yii\web\BadRequestHttpException('Country ID must be a valid number.');
        }

        // Build query
        $query = Banks::find()
            ->select($this->selectColumns)
            ->distinct() // avoid duplicate banks when they have multiple branches
            ->joinWith('country', false) // joins Countries table via relation
            ->innerJoin('BanksBranches', 'Banks.BankID = BanksBranches.BankID') // must have at least 1 branch
            ->where([
                'Banks.Enable'     => 1,
                'Countries.Enable' => 1,
            ])
            // MCBankID NOT NULL and NOT empty
            ->andWhere(['IS NOT', 'BanksBranches.MCBankID', null])
            ->andWhere(['!=', 'BanksBranches.MCBankID', ''])
            ->asArray();


        // Data provider with pagination and sorting
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'key' => 'bankId', // Use the alias as the key field
            'pagination' => [
                'pageSize' => $params['pageSize'] ?? false,
                'page' => ($params['page'] ?? 1) - 1, // Yii pagination is 0-indexed
            ],
            'sort' => [
                'defaultOrder' => [
                    'Name' => SORT_ASC, // match alias
                ],
            ],
        ]);

        // Load filter params
        $this->load($params, '');

        if (!$this->validate()) {
            $errors = $this->getErrors();
            $errorMessage = 'Validation failed: ' . implode(', ', array_map(function ($field, $messages) {
                return $field . ': ' . implode(', ', $messages);
            }, array_keys($errors), $errors));
            throw new \yii\web\BadRequestHttpException($errorMessage);
        }

        // Filter by country
        if (!empty($this->countryId)) {
            $query->andWhere(['Banks.CountryID' => $this->countryId]);
        }


        // Filter by bank name
        if (!empty($this->Name)) {
            $query->andFilterWhere(['like', 'Banks.Name', $this->Name]);
        }

        return $dataProvider;
    }
}
