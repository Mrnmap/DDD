<?php

namespace api\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\SourceOfFund;

class SourceOfFundSearch extends SourceOfFund
{
    public $selectColumns = [
        'SourceOfFund.SourceID AS id',
        'SourceOfFund.Description AS name',
    ];

    public function rules()
    {
        return [
            [['id'], 'integer'],
            [['name'], 'safe'],
        ];
    }

    public function scenarios()
    {
        return Model::scenarios();
    }

    public function search($params)
    {
        // Validate required parameters
        if (!isset($params['limit']) || $params['limit'] == 0) {
            return [
                'error' => true,
                'errors' => ['Value in parameter %limit% must not be 0'],
                'status' => 400
            ];
        }
        
        if (!isset($params['page']) || !is_numeric($params['page'])) {
            return [
                'error' => true,
                'errors' => ['Page parameter must be a number'],
                'status' => 400
            ];
        }
        
        // Validate limit is a 2-digit number
        if (!preg_match('/^\d{1,2}$/', $params['limit'])) {
            return [
                'error' => true,
                'errors' => ['Limit must be a 2-digit number'],
                'status' => 400
            ];
        }

        $page = intval($params['page']);
        $limit = intval($params['limit']);

        $query = SourceOfFund::find()
            ->where(['IsDelete' => 0]) // only active sources
            ->asArray();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => $limit,
                'page' => $page - 1,
            ],
            'sort' => [
                'defaultOrder' => [
                    'Description' => SORT_ASC,
                ],
            ],
        ]);

        return $dataProvider;
    }
}