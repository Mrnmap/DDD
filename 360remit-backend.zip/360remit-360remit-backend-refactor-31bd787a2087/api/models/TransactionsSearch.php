<?php

namespace api\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Transactions;
use common\models\TransactionStatus;
use DateTime;

class TransactionsSearch extends Transactions
{
    public $date_from; // Y-m-d
    public $date_to;   // Y-m-d

    public function rules()
    {
        return [
            // integers
            [[
                'TransactionID',
                'UserID',
                'OrginalTransactionId',
                'BeneficiaryId',
                'CurrentStatus',
            ], 'integer'],

            // enum string (Direction) + date fields are safe
            [[
                'Direction',
                'CreatedAt',
                'SubmittedAt',
                'UpdatedAt',
                'date_from',
                'date_to',
            ], 'safe'],
        ];
    }

    public function scenarios()
    {
        return Model::scenarios();
    }

    public function search($params)
    {
        // If you want eager loading for details:
        $query = Transactions::find()->joinWith(['transactionDetails', 'beneficiary', 'transactionStatus']);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => (isset($params['pageSize']) && (int)$params['pageSize'] > 0) ? (int)$params['pageSize'] : false,
            ],
            'sort' => [
                'defaultOrder' => [
                    'CreatedAt' => SORT_DESC,
                ],
            ],
        ]);

        $this->load($params);
        // get transaction statuses ids we want to display to customer
        $statuses = TransactionStatus::find()->select('Id')->where(['in', 'Name', ['Failed', 'New']])->column();

        if (!$this->validate()) {
            $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'Transactions.UserID' => $params['userId']
        ]);
        $query->andFilterWhere(['not in', 'CurrentStatus', $statuses]);

        // Date range on CreatedAt
        if (!empty($this->date_from)) {
            $from = DateTime::createFromFormat('Y-m-d', $this->date_from);
            if ($from) {
                $query->andWhere(['>=', 'CreatedAt', $from->format('Y-m-d 00:00:00')]);
            }
        }

        if (!empty($this->date_to)) {
            $to = DateTime::createFromFormat('Y-m-d', $this->date_to);
            if ($to) {
                $query->andWhere(['<=', 'CreatedAt', $to->format('Y-m-d 23:59:59')]);
            }
        }

        // Optional: guard against swapped dates (from > to)
        if (!empty($this->date_from) && !empty($this->date_to)) {
            $from = DateTime::createFromFormat('Y-m-d', $this->date_from);
            $to   = DateTime::createFromFormat('Y-m-d', $this->date_to);
            if ($from && $to && $from > $to) {
                // Swap silently
                $query->andWhere([
                    'between',
                    'CreatedAt',
                    $to->format('Y-m-d 00:00:00'),
                    $from->format('Y-m-d 23:59:59')
                ]);
            }
        }

        return $dataProvider;
    }
}
