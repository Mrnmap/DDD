<?php

declare(strict_types=1);
session_start();

/** ===== CONFIG ===== */
$ADMIN_USER = 'admin';
// Generate your own hash with: password_hash('YourStrongPassword', PASSWORD_DEFAULT)
$ADMIN_PASS_HASH = '$2y$10$bjHluQbF2Z5E9687ZbXVhuOEyZw6UfG/0uZJ3BK3ytAyomUmL4vo6'; // example
$LOG_FILE = __DIR__ . '/../runtime/logs/otp.txt';   // adjust if needed
$DEFAULT_TAIL_LINES = 500;                          // show last 500 lines
//echo password_hash('', PASSWORD_DEFAULT);
/** ===== HELPERS ===== */
function is_logged_in(): bool
{
    return !empty($_SESSION['otp_viewer_auth']) && $_SESSION['otp_viewer_auth'] === true;
}
function ensure_csrf_token(): void
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
}
function check_csrf(string $token = null): bool
{
    return isset($_SESSION['csrf']) && $token && hash_equals($_SESSION['csrf'], $token);
}
function tail_file(string $filepath, int $lines = 200): string
{
    clearstatcache(true, $filepath);
    if (!is_readable($filepath)) return '';

    // Prefer SplFileObject: stable and memory-light.
    try {
        $f = new SplFileObject($filepath, 'r');
        $f->seek(PHP_INT_MAX);                 // jump to end
        $lastLine = $f->key();                 // last line index (0-based)
        if ($lastLine === 0) {                 // file has 0 or 1 line
            $f->rewind();
            $content = $f->fgets();
            return rtrim((string)$content, "\r\n");
        }

        $start = max(0, $lastLine - $lines + 1);
        $result = [];
        $f->seek($start);
        while (!$f->eof()) {
            $result[] = rtrim((string)$f->fgets(), "\r\n");
        }
        // Keep only the last $lines lines (in case eof read added an extra)
        if (count($result) > $lines) {
            $result = array_slice($result, -$lines);
        }
        return implode("\n", $result);
    } catch (Throwable $e) {
        // Fallback: last N bytes (good when SplFileObject fails under some handlers)
        $bytesPerLineGuess = 200;                 // tune if your lines are longer/shorter
        $budget = max(8192, $lines * $bytesPerLineGuess);
        $size = @filesize($filepath);
        if ($size === false) return '';

        $offset = max(0, $size - $budget);
        $h = @fopen($filepath, 'rb');
        if (!$h) return '';
        if ($offset > 0) fseek($h, $offset);
        $chunk = stream_get_contents($h);
        fclose($h);
        if ($chunk === false) return '';

        // Normalize newlines and extract last $lines lines
        $chunk = str_replace("\r\n", "\n", $chunk);
        $arr = explode("\n", $chunk);
        if (count($arr) > $lines) $arr = array_slice($arr, -$lines);
        return implode("\n", $arr);
    }
}

function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

/** ===== LOGOUT ===== */
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && ($_POST['action'] ?? '') === 'logout') {
    if (check_csrf($_POST['csrf'] ?? '')) {
        $_SESSION = [];
        session_destroy();
        header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
        exit;
    }
}

/** ===== LOGIN ===== */
ensure_csrf_token();
if (!is_logged_in() && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && ($_POST['action'] ?? '') === 'login') {
    if (!check_csrf($_POST['csrf'] ?? '')) {
        $error = 'Invalid session. Please refresh and try again.';
    } else {
        $user = trim((string)($_POST['username'] ?? ''));
        $pass = (string)($_POST['password'] ?? '');
        if ($user === $ADMIN_USER && password_verify($pass, $ADMIN_PASS_HASH)) {
            $_SESSION['otp_viewer_auth'] = true;
            header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
            exit;
        } else {
            $error = 'Invalid credentials.';
        }
    }
}

/** ===== READ LOG ===== */
$lines = (int)($_GET['n'] ?? $DEFAULT_TAIL_LINES);
if ($lines <= 0 || $lines > 5000) $lines = $DEFAULT_TAIL_LINES;

$logPreview = '';
if (is_logged_in()) {
    if (is_readable($LOG_FILE)) {
        $raw = tail_file($LOG_FILE);
        $logPreview = $raw !== '' ? $raw : '[Log file is empty]';
    } else {
        $logPreview = '[Log file not found or not readable: ' . e($LOG_FILE) . ']';
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OTP Log Viewer</title>
    <?php if (!is_logged_in()): ?>
        <style>
            :root {
                color-scheme: light dark;
            }

            * {
                box-sizing: border-box;
            }

            body {
                margin: 0;
                font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
                min-height: 100vh;
                display: grid;
                place-items: center;
                background: rgba(0, 0, 0, .03);
            }

            .login-card {
                width: min(420px, 92vw);
                background: #fff;
                border: 1px solid rgba(0, 0, 0, .12);
                border-radius: 14px;
                padding: 22px 20px;
                box-shadow: 0 10px 24px rgba(0, 0, 0, .06);
            }

            .login-title {
                margin: 0 0 4px;
                font-size: 20px;
                font-weight: 700;
            }

            .login-subtitle {
                margin: 0 0 18px;
                color: #6b7280;
                font-size: 13px;
            }

            .field {
                margin-bottom: 14px;
            }

            .label {
                display: block;
                font-size: 13px;
                margin-bottom: 6px;
                color: #374151;
            }

            .input {
                width: 100%;
                padding: 11px 12px;
                font-size: 14px;
                border: 1px solid rgba(0, 0, 0, .2);
                border-radius: 10px;
                outline: none;
            }

            .input:focus {
                border-color: #3b82f6;
                box-shadow: 0 0 0 3px rgba(59, 130, 246, .15);
            }

            .password-row {
                display: flex;
                gap: 10px;
                align-items: center;
            }

            .show-toggle {
                white-space: nowrap;
                font-size: 12px;
                color: #374151;
            }

            .btn {
                width: 100%;
                padding: 11px 14px;
                border: 0;
                border-radius: 10px;
                background: #3b82f6;
                color: #fff;
                font-weight: 600;
                cursor: pointer;
            }

            .btn:active {
                transform: translateY(1px);
            }

            .error {
                color: #dc2626;
                background: #fee2e2;
                border: 1px solid #fecaca;
                padding: 10px;
                border-radius: 10px;
                margin-bottom: 12px;
                font-size: 13px;
            }

            .helper {
                margin-top: 10px;
                font-size: 12px;
                color: #6b7280;
                text-align: center;
            }
        </style>
    <?php else: ?>
        <style>
            body {
                font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
                margin: 24px;
                background: #fafafa;
            }

            .card {
                border: 1px solid rgba(0, 0, 0, .12);
                border-radius: 12px;
                padding: 20px;
                max-width: 980px;
                margin: 0 auto;
                background: #fff;
                box-shadow: 0 4px 12px rgba(0, 0, 0, .06);
            }

            h2 {
                margin-top: 0;
            }

            input[type=number] {
                width: 80px;
                padding: 6px 8px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }

            button {
                padding: 7px 10px;
                border: 0;
                border-radius: 6px;
                cursor: pointer;
                background: #3b82f6;
                color: #fff;
            }

            .btn.secondary {
                background: #6b7280;
            }

            pre {
                white-space: pre-wrap;
                word-break: break-word;
                background: #f3f4f6;
                padding: 12px;
                border-radius: 8px;
                max-height: 80vh;
                overflow: auto;
                font-family: monospace;
                font-size: 13px;
            }

            .muted {
                color: #6b7280;
                font-size: 13px;
                margin-bottom: 8px;
            }

            .topbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 16px;
            }
        </style>
    <?php endif; ?>
</head>

<body>

    <?php if (!is_logged_in()): ?>
        <div class="login-card">
            <h1 class="login-title">Sign in</h1>
            <p class="login-subtitle">Enter your admin credentials to view OTP logs.</p>
            <?php if (!empty($error)): ?><div class="error"><?= e($error) ?></div><?php endif; ?>
            <form method="post" autocomplete="off">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                <div class="field">
                    <label class="label" for="user">Username</label>
                    <input class="input" id="user" type="text" name="username" required autofocus>
                </div>
                <div class="field">
                    <label class="label" for="pass">Password</label>
                    <div class="password-row">
                        <input class="input" id="pass" type="password" name="password" required>
                        <label class="show-toggle"><input type="checkbox" id="togglePass"> Show</label>
                    </div>
                </div>
                <button class="btn" type="submit">Sign in</button>
                <div class="helper">Protected area • Authorized access only</div>
            </form>
        </div>
        <script>
            (function() {
                var pass = document.getElementById('pass'),
                    tgl = document.getElementById('togglePass');
                if (pass && tgl) {
                    tgl.addEventListener('change', () => {
                        pass.type = tgl.checked ? 'text' : 'password';
                    });
                }
            })();
        </script>

    <?php else: ?>
        <div class="card">
            <div class="topbar">
                <h2>OTP Log Viewer</h2>
                <form method="post" style="margin:0;">
                    <input type="hidden" name="action" value="logout">
                    <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                    <button class="btn secondary" type="submit">Logout</button>
                </form>
            </div>

            <form method="get" style="margin-bottom:12px;">
                <button type="submit">Refresh</button>
            </form>

            <pre><?= e($logPreview) ?></pre>
        </div>
    <?php endif; ?>

</body>

</html>