<?php

declare(strict_types=1);

namespace console\controllers;

use Yii;
use yii\console\Controller;
use yii\db\ActiveQueryInterface;
use yii\db\ActiveRecord;
use yii\helpers\FileHelper;
use ReflectionClass;
use ReflectionMethod;

final class MetaController extends Controller
{
    /**
     * php yii meta/generate-model-docs @app/common/models
     */
    public function actionGenerateModelDocs(string $modelsPath = '@common/models'): int
    {
        $basePath = Yii::getAlias($modelsPath);
        $files = FileHelper::findFiles($basePath, ['only' => ['*.php']]);

        foreach ($files as $file) {
            $code = file_get_contents($file);
            if ($code === false) {
                $this->stderr("Cannot read $file\n");
                continue;
            }

            // Infer FQCN from file path + PSR-4; adjust this to your autoloading if needed
            $fqcn = $this->classFromFile($file);
            if (!$fqcn || !class_exists($fqcn)) {
                require_once $file; // load once more just in case
            }
            if (!$fqcn || !class_exists($fqcn)) {
                $this->stderr("Skip (no class): $file\n");
                continue;
            }

            if (!is_subclass_of($fqcn, ActiveRecord::class)) {
                continue; // we only annotate AR models
            }

            /** @var class-string<ActiveRecord> $fqcn */
            $doc = $this->buildModelDocblock($fqcn);

            // Replace or insert the class docblock just before `class ...`
            $updated = preg_replace(
                '/^\s*\/\*\*.*?\*\/\s*class\s+' . preg_quote((new ReflectionClass($fqcn))->getShortName(), '/') . '\b/s',
                $doc . "\n" . 'class ' . (new ReflectionClass($fqcn))->getShortName(),
                $code,
                1,
                $count
            );

            if ($count === 0) {
                // No previous docblock — insert one
                $updated = preg_replace(
                    '/(^\s*class\s+' . preg_quote((new ReflectionClass($fqcn))->getShortName(), '/') . '\b)/m',
                    $doc . "\n" . '$1',
                    $code,
                    1
                );
            }

            if ($updated !== null && $updated !== $code) {
                file_put_contents($file, $updated);
                $this->stdout("Updated: $fqcn\n");
            } else {
                $this->stdout("No change: $fqcn\n");
            }
        }

        $this->stdout("Done.\n");
        return self::EXIT_CODE_NORMAL;
    }

    private function buildModelDocblock(string $modelClass): string
    {
        /** @var ActiveRecord $model */
        $model = new $modelClass();
        $schema = $model::getTableSchema();
        $rc = new ReflectionClass($modelClass);

        $props = [];
        foreach ($schema->columns as $col) {
            $type = $this->phpType($col->phpType, $col->allowNull);
            $props[] = sprintf(" * @property %s $%s", $type, $col->name);
        }

        // Relations: methods named getXxx() returning ActiveQueryInterface
        foreach ($rc->getMethods(ReflectionMethod::IS_PUBLIC) as $m) {
            if ($m->isStatic() || $m->getNumberOfRequiredParameters() > 0) {
                continue;
            }
            $name = $m->getName();
            if (strpos($name, 'get') !== 0 || $name === 'getAttribute' || $name === 'getOldAttribute') {
                continue;
            }
            try {
                $result = $m->invoke($model);
            } catch (\Throwable $e) {
                continue;
            }
            if ($result instanceof ActiveQueryInterface) {
                $relName = lcfirst(substr($name, 3));
                $arClass = $result->modelClass;
                $isMany = method_exists($result, 'multiple') ? $result->multiple : false;
                $type = $isMany ? $arClass . '[]' : $arClass;
                $props[] = sprintf(" * @property-read %s $%s", $type, $relName);
            }
        }

        $doc = "/**\n";
        $doc .= " * This file is auto-annotated. Do not edit property lines manually.\n";
        foreach ($props as $p) {
            $doc .= $p . "\n";
        }
        $doc .= " */";

        return $doc;
    }

    private function phpType(string $phpType, bool $nullable): string
    {
        $map = [
            'integer' => 'int',
            'string'  => 'string',
            'boolean' => 'bool',
            'double'  => 'float',
        ];
        $t = $map[$phpType] ?? 'mixed';
        return $nullable ? ($t . '|null') : $t;
    }

    /**
     * Derive FQCN from file path via composer PSR-4. If your autoload differs,
     * hardcode the namespace resolution here.
     */
    private function classFromFile(string $file): ?string
    {
        $code = file_get_contents($file);
        if ($code === false) return null;

        $ns = null;
        if (preg_match('/namespace\s+([^;]+);/m', $code, $m)) {
            $ns = trim($m[1]);
        }
        if (preg_match('/class\s+([A-Za-z0-9_]+)/', $code, $m)) {
            $cls = trim($m[1]);
            return $ns ? $ns . '\\' . $cls : $cls;
        }
        return null;
    }
}
