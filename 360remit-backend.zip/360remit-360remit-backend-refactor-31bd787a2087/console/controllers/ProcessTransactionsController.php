<?php

namespace console\controllers;

use yii\console\Controller;
use common\models\Transactions;

class ProcessTransactionsController extends Controller
{
    /**
     * Example: php yii cron/process-transactions
     */
    public function actionIndex()
    {
        echo "Cron started at " . date('Y-m-d H:i:s') . PHP_EOL;
        $this->stdout("Processing transactions...\n");
        // Example logic — process pending transactions
        $transactions = Transactions::find()->where(['CurrentStatus' => '1'])->all();
        foreach ($transactions as $t) {
            //$t->Status = 'Completed';
            //$t->save(false);
            echo "Processed Transaction ID: {$t->TransactionID}" . PHP_EOL;
        }

        echo "Cron finished at " . date('Y-m-d H:i:s') . PHP_EOL;
    }
}
